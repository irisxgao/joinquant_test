# 第 4 课：SQLite 从安装到项目数据模型

## 本课目标

从完全没接触过 SQLite 开始，知道它是什么、是否必须安装、如何用 GUI 查看，以及本项目三张表如何工作。

## 开课前检查 1：Python 是否自带 sqlite3

先运行：

```bat
.venv\Scripts\python.exe -c "import sqlite3; print('Python sqlite3 可用'); print('SQLite 版本:', sqlite3.sqlite_version)"
```

如果成功，**项目运行已经不需要额外安装 SQLite**。Python 的 `sqlite3` 模块可以直接创建和读写数据库文件。

如果报 `ModuleNotFoundError: sqlite3`，通常是 Python 安装不完整或使用了非标准发行版。最稳妥的方法是卸载并重装官方 64 位 Python 3.11，而不是随意安装同名第三方包。

## SQLite 到底是什么

SQLite 是嵌入式数据库：

- 不需要安装数据库服务器。
- 不需要启动 Windows 服务。
- 不需要用户名、密码和端口。
- 整个数据库通常就是一个普通文件。

本项目的数据库文件是：

```text
data\photos.db
```

程序调用 Python `sqlite3.connect(...)` 时，如果文件不存在就创建；如果存在就打开。

它和 MySQL/SQL Server 的差别在于，后两者通常有独立服务器进程，而 SQLite 直接在应用进程里读写文件。

## 开课前检查 2：是否安装可视化工具

在开始菜单搜索：

```text
DB Browser for SQLite
```

或者在 CMD：

```bat
where sqlite3
```

这两者都是**学习和查看数据库的辅助工具**，项目本身并不依赖它们。

## 安装 DB Browser for SQLite（推荐初学者）

1. 访问官方 DB Browser for SQLite 下载页。
2. 选择 Windows 64-bit Standard Installer。
3. 下载 MSI 并安装。
4. 从开始菜单启动。
5. 点击 `Open Database`。
6. 选择项目中的 `data\photos.db`。

如果数据库还不存在，先启动项目一次，或者运行：

```bat
.venv\Scripts\python.exe -c "import db; db.init_db(); print('数据库已创建')"
```

## 可选：安装 SQLite 命令行工具

1. 从 SQLite 官方 Download 页面下载 Windows x64 的 tools ZIP。
2. 解压到 `C:\sqlite`。
3. 将 `C:\sqlite` 加入用户 PATH。
4. 关闭并重新打开 CMD。
5. 验证：

```bat
sqlite3 --version
```

打开本项目数据库：

```bat
cd /d D:amily_photo_nicegui_v2_windows
sqlite3 data\photos.db
```

在 `sqlite>` 后输入：

```sql
.tables
.schema person
SELECT * FROM person;
.quit
```

以点开头的是 SQLite CLI 命令，不是普通 SQL。

## 数据库基础词汇

- Database：数据库，本项目中是 `photos.db` 文件。
- Table：表，类似一个有固定列定义的工作表。
- Row：行，一条记录。
- Column：列，一个字段。
- Primary Key：主键，唯一标识一行。
- Foreign Key：外键，指向另一张表的主键。
- Index：索引，用额外空间换查询速度。
- SQL：操作关系型数据库的语言。

## 本项目的三张表

### person

保存“有哪些已知人物”：

```text
id          人物唯一编号
name        显示姓名
embedding   多张参考照合成的人脸向量二进制数据
```

### photo

保存“扫描过哪些照片”：

```text
id              照片唯一编号
path            原图绝对路径
thumbnail_path  缩略图路径
file_mtime      文件修改时间，用于增量扫描
taken_at        当前版本用于排序的时间
```

### face

保存“一张照片中的一张脸”：

```text
id          人脸记录编号
photo_id    属于哪张照片
person_id   机器或人工认为是谁；未知时为 NULL
similarity  机器相似度
bbox        人脸框坐标 x1,y1,x2,y2
crop_path   人脸裁剪图
status      suggested 或 confirmed
```

## 建表 SQL 怎么读

以人物表为例：

```sql
CREATE TABLE person (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    embedding BLOB NOT NULL
);
```

- `INTEGER`：整数。
- `TEXT`：文本。
- `BLOB`：二进制数据。
- `PRIMARY KEY`：主键。
- `AUTOINCREMENT`：新增时自动分配编号。
- `UNIQUE`：姓名不能重复。
- `NOT NULL`：不允许空值。

## Python 如何操作 SQLite

```python
import sqlite3

connection = sqlite3.connect('demo.db')
connection.execute('CREATE TABLE IF NOT EXISTS person(id INTEGER PRIMARY KEY, name TEXT)')
connection.execute('INSERT INTO person(name) VALUES (?)', ('张三',))
rows = connection.execute('SELECT id, name FROM person').fetchall()
connection.commit()
connection.close()
```

`?` 是参数占位符。不要用字符串拼接把用户输入塞进 SQL。

## 动手实验

在项目目录运行：

```bat
.venv\Scripts\python.exe -c "import db; db.init_db(); print(db.stats())"
```

然后用 DB Browser 打开数据库：

1. `Database Structure` 查看三张表。
2. `Browse Data` 选择 `person`。
3. `Execute SQL` 执行：

```sql
SELECT name FROM sqlite_master WHERE type='table';
```

## 为什么 AND 筛选要 GROUP BY

选择两个人时：

```sql
SELECT photo_id
FROM face
WHERE person_id IN (?, ?)
GROUP BY photo_id
HAVING COUNT(DISTINCT person_id) = 2;
```

逐句解释：

1. `WHERE ... IN` 只保留选中人物的脸。
2. `GROUP BY photo_id` 按照片分组。
3. `COUNT(DISTINCT person_id)` 数每张照片命中了几个不同人物。
4. 等于 2 表示两个人都出现。

## 数据库安全操作

- 打开 DB Browser 前最好关闭本项目，避免写入冲突。
- 修改前复制备份 `photos.db`。
- 不要手工修改 embedding。
- 数据库损坏或想重建，可使用项目的重置脚本；原始照片不会被删除。

## 验收清单

- 能解释为什么项目不需要 SQLite 服务器。
- 能运行 Python sqlite3 检查。
- 能安装并打开 DB Browser。
- 能找到三张表。
- 能区分 `suggested` 和 `confirmed`。
- 能解释 AND SQL 的四个步骤。
