# 第 2 课：Windows 安装 Python 与虚拟环境

## 本课目标

从没有 Python 开始，安装并验证 Python 3.11，理解 pip 和 `.venv`。

## 开课前检查

打开 CMD：

```bat
py -3.11 --version
python --version
```

任一命令显示 Python 3.11.x，说明解释器基本可用。再检查位数：

```bat
py -3.11 -c "import platform; print(platform.architecture())"
```

应显示 `64bit`。

## 未安装时怎么做

建议安装 Python 3.11.9 64 位。Python 3.11 后期安全版本可能只提供源码，不一定提供 Windows 安装器，因此不要只盯着最新的 3.11.x。

安装界面：

1. 勾选 `Add python.exe to PATH`。
2. 选择 `Install Now`。
3. 安装完关闭所有 CMD，再开新 CMD。
4. 重新运行检查命令。

## 什么是 Python、pip 和 venv

- Python：运行 `.py` 源码的解释器。
- pip：安装第三方库的工具。
- venv：为当前项目创建隔离环境。
- requirements.txt：项目依赖清单。

项目使用虚拟环境后，实际解释器是：

```text
项目目录\.venv\Scripts\python.exe
```

## 手工创建虚拟环境

```bat
cd /d D:amily_photo_nicegui_v2_windows
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

这里故意直接调用 `.venv` 的 Python，不依赖 PowerShell 激活策略。

## 检查依赖

```bat
.venv\Scripts\python.exe -c "import nicegui, cv2, numpy, PIL, sqlite3; print('基础依赖 OK'); print(sqlite3.sqlite_version)"
.venv\Scripts\python.exe -c "import insightface, onnxruntime; print('AI 依赖 OK')"
```

## 常见错误

### `py` 不是内部或外部命令

Python Launcher 没装。重新运行 Python 安装器并启用 launcher，或用完整的 `python.exe` 路径。

### pip 下载超时

先确认浏览器可访问 PyPI；重试安装。不要从陌生网站下载 `.whl` 文件。

### PowerShell 禁止激活

本课程命令不要求激活，直接使用 `.venv\Scripts\python.exe`。

## 验收

```bat
.venv\Scripts\python.exe -c "import sys; print(sys.version); print(sys.executable)"
```

必须显示 3.11.x 和当前项目的 `.venv` 路径。
