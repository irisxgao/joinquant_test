# 第 3 课：NiceGUI 从安装到第一个页面

## 开课前检查

```bat
.venv\Scripts\python.exe -c "import nicegui; print(nicegui.__version__)"
```

失败时安装：

```bat
.venv\Scripts\python.exe -m pip install "nicegui>=3.0,<4"
```

## NiceGUI 是什么

NiceGUI 是用 Python 编写、在浏览器显示的 UI 框架。Python 程序启动本地 Web 服务，浏览器负责显示；按钮事件仍由 Python 函数处理。我们的家庭单机工具因此不必额外写 React。

## 第一个页面

新建 `hello.py`：

```python
from nicegui import ui

ui.label('你好，家庭相册')
ui.button('测试按钮', on_click=lambda: ui.notify('按钮工作正常'))
ui.run(host='127.0.0.1', port=8090)
```

运行：

```bat
.venv\Scripts\python.exe hello.py
```

打开 `http://127.0.0.1:8090`。

## 关键概念

- `ui.label` 创建文本组件。
- `ui.button` 创建按钮。
- `on_click` 注册事件。
- `ui.notify` 显示提示。
- `127.0.0.1` 表示只接受本机访问。
- 端口是应用在本机使用的入口编号。

## 对应项目源码

`app.py` 的 `@ui.page('/')` 定义主页；`ui.left_drawer` 是侧栏；`ui.dialog` 是人物管理和纠错弹窗；`render()` 根据数据库结果重建照片墙。

## 验收

- 页面能打开。
- 点击按钮能看到提示。
- 关闭 CMD 后页面无法访问，理解浏览器不是独立应用。
