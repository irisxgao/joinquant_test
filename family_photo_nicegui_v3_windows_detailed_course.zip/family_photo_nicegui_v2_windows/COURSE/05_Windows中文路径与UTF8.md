# 第 5 课：Windows 中文路径与 UTF-8

## 开课前检查

```bat
chcp
.venv\Scripts\python.exe -X utf8 -c "import sys,locale; print(sys.flags.utf8_mode); print(locale.getpreferredencoding(False))"
```

再确认批处理文件存在：

```bat
dir start_windows.bat
```

## 三种不同的编码问题

1. CMD 显示乱码：控制台代码页问题。
2. 文本文件乱码：读写时没有指定编码。
3. OpenCV 中文路径失败：图片库路径 API 兼容问题。

项目分别处理：

```bat
chcp 65001
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
```

Python 文件操作明确写 `encoding='utf-8'`。`image_io.py` 不直接调用 `cv2.imread(中文路径)`，而使用字节读取和解码。

## 动手检查中文路径

创建目录并放一张图片：

```bat
mkdir D:\测试照片
```

假设图片名为 `家庭合照.jpg`：

```bat
.venv\Scripts\python.exe -X utf8 -c "from image_io import cv_imread; x=cv_imread(r'D:\测试照片\家庭合照.jpg'); print(x.shape)"
```

## 日志检查

启动并制造一个错误后，用记事本或 VS Code 以 UTF-8 打开：

```text
logspp.log
```

## 验收

- 中文目录图片可读取。
- 网页显示中文正常。
- 日志能看到完整中文路径。
