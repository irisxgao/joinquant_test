﻿@echo off
setlocal
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title Family Photo Organizer

echo [1/4] Checking Python 3.11...
py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python 3.11 64-bit was not found.
  echo Install Python 3.11 and select Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo [2/4] Creating virtual environment...
  py -3.11 -m venv .venv
  if errorlevel 1 goto :failed
) else echo [2/4] Virtual environment already exists.
echo [3/4] Installing or checking dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :failed
echo [4/4] Starting http://127.0.0.1:8080
".venv\Scripts\python.exe" -X utf8 app.py
if errorlevel 1 goto :failed
exit /b 0
:failed
echo Startup failed. See logs\app.log when available.
pause
exit /b 1
