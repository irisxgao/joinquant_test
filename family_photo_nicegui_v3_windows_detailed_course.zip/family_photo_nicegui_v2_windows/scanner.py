from pathlib import Path
from datetime import datetime
import hashlib,logging
from PIL import Image,ImageOps
import db
from image_io import cv_imread,cv_imwrite
from face_engine import recognize
EXT={'.jpg','.jpeg','.png','.webp','.bmp','.tif','.tiff'};BASE=Path(__file__).parent;TH=BASE/'data/thumbnails';CROPS=BASE/'data/face_crops';log=logging.getLogger(__name__)
def thumbnail(path,size):
 key=hashlib.sha1(str(path).encode('utf-8')).hexdigest();target=TH/f'{key}.jpg'
 if not target.exists() or target.stat().st_mtime<path.stat().st_mtime:
  with Image.open(path) as source:
   image=ImageOps.exif_transpose(source).convert('RGB');image.thumbnail((size,size));image.save(target,'JPEG',quality=85)
 return target,key
def scan_directory(root,threshold=.45,size=480,progress=None):
 root=Path(root).expanduser().resolve()
 if not root.is_dir():raise ValueError(r'照片目录不存在，例如 D:\家庭照片。')
 files=[p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in EXT];known=db.known_people();result={'processed':0,'skipped':0,'errors':0,'faces':0}
 for number,path in enumerate(files,1):
  try:
   thumb,key=thumbnail(path,size);photo_id,changed=db.upsert_photo(str(path),str(thumb),path.stat().st_mtime,datetime.fromtimestamp(path.stat().st_mtime).isoformat())
   if not changed or db.has_confirmed(photo_id):result['skipped']+=1
   else:
    image=cv_imread(path)
    for index,(person,score,bbox) in enumerate(recognize(image,known,threshold)):
     h,w=image.shape[:2];x1,y1,x2,y2=bbox;pad=int(max(x2-x1,y2-y1)*.25);x1=max(0,x1-pad);y1=max(0,y1-pad);x2=min(w,x2+pad);y2=min(h,y2+pad);crop=CROPS/f'{key}_{index}.jpg';cv_imwrite(crop,image[y1:y2,x1:x2]);db.add_face(photo_id,person,score,','.join(map(str,bbox)),str(crop));result['faces']+=1
    result['processed']+=1
  except Exception:log.exception('处理失败：%s',path);result['errors']+=1
  if progress:progress(number/max(len(files),1),f'{number}/{len(files)} {path.name}')
 return result
