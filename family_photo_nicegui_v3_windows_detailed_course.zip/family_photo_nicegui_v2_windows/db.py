import sqlite3
from pathlib import Path
DB_PATH=Path(__file__).parent/'data'/'photos.db'
def connect():
 c=sqlite3.connect(DB_PATH,timeout=30);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c
def init_db():
 with connect() as c:c.executescript('''CREATE TABLE IF NOT EXISTS person(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,embedding BLOB NOT NULL);CREATE TABLE IF NOT EXISTS photo(id INTEGER PRIMARY KEY AUTOINCREMENT,path TEXT UNIQUE NOT NULL,thumbnail_path TEXT NOT NULL,file_mtime REAL NOT NULL,taken_at TEXT);CREATE TABLE IF NOT EXISTS face(id INTEGER PRIMARY KEY AUTOINCREMENT,photo_id INTEGER NOT NULL,person_id INTEGER,similarity REAL,bbox TEXT NOT NULL,crop_path TEXT,status TEXT NOT NULL DEFAULT 'suggested',FOREIGN KEY(photo_id) REFERENCES photo(id) ON DELETE CASCADE,FOREIGN KEY(person_id) REFERENCES person(id) ON DELETE SET NULL);CREATE INDEX IF NOT EXISTS idx_face_person ON face(person_id);CREATE INDEX IF NOT EXISTS idx_face_photo ON face(photo_id);''')
def list_people():
 with connect() as c:return [dict(x) for x in c.execute('SELECT id,name FROM person ORDER BY name COLLATE NOCASE')]
def known_people():
 with connect() as c:return [dict(x) for x in c.execute('SELECT id,name,embedding FROM person')]
def add_person(name,embedding):
 name=name.strip()
 if not name:raise ValueError('人物姓名不能为空。')
 with connect() as c:c.execute('INSERT INTO person(name,embedding) VALUES(?,?)',(name,embedding))
def delete_person(pid):
 with connect() as c:c.execute('DELETE FROM person WHERE id=?',(pid,))
def upsert_photo(path,thumb,mtime,taken):
 with connect() as c:
  x=c.execute('SELECT id,file_mtime FROM photo WHERE path=?',(path,)).fetchone()
  if x and abs(x['file_mtime']-mtime)<.001:return x['id'],False
  if x:c.execute("DELETE FROM face WHERE photo_id=? AND status!='confirmed'",(x['id'],));c.execute('UPDATE photo SET thumbnail_path=?,file_mtime=?,taken_at=? WHERE id=?',(thumb,mtime,taken,x['id']));return x['id'],True
  return c.execute('INSERT INTO photo(path,thumbnail_path,file_mtime,taken_at) VALUES(?,?,?,?)',(path,thumb,mtime,taken)).lastrowid,True
def has_confirmed(photo_id):
 with connect() as c:return c.execute("SELECT COUNT(*) FROM face WHERE photo_id=? AND status='confirmed'",(photo_id,)).fetchone()[0]>0
def add_face(photo_id,person_id,score,bbox,crop):
 with connect() as c:c.execute("INSERT INTO face(photo_id,person_id,similarity,bbox,crop_path,status) VALUES(?,?,?,?,?,'suggested')",(photo_id,person_id,score,bbox,crop))
def photo_faces(photo_id):
 with connect() as c:return [dict(x) for x in c.execute('SELECT f.*,p.name person_name FROM face f LEFT JOIN person p ON p.id=f.person_id WHERE f.photo_id=? ORDER BY f.id',(photo_id,))]
def correct_face(face_id,person_id):
 with connect() as c:c.execute("UPDATE face SET person_id=?,status='confirmed' WHERE id=?",(person_id,face_id))
def mark_unknown(face_id):
 with connect() as c:c.execute("UPDATE face SET person_id=NULL,status='confirmed' WHERE id=?",(face_id,))
def get_photo(photo_id):
 with connect() as c:
  x=c.execute('SELECT * FROM photo WHERE id=?',(photo_id,)).fetchone();return dict(x) if x else None
def query_photos(ids,mode,limit,offset,review_only=False):
 ids=[int(i) for i in (ids or [])];filters=[];args=[]
 if review_only:filters.append("EXISTS(SELECT 1 FROM face z WHERE z.photo_id=p.id AND z.status='suggested')")
 if ids:
  marks=','.join('?' for _ in ids);op='=' if mode=='all' else '>=';need=len(ids) if mode=='all' else 1
  filters.append(f'p.id IN(SELECT photo_id FROM face WHERE person_id IN({marks}) GROUP BY photo_id HAVING COUNT(DISTINCT person_id){op}?)');args.extend(ids+[need])
 where='WHERE '+' AND '.join(filters) if filters else ''
 sql=f'''SELECT p.*,GROUP_CONCAT(DISTINCT n.name) people,SUM(CASE WHEN f.status='suggested' THEN 1 ELSE 0 END) pending_count FROM photo p LEFT JOIN face f ON f.photo_id=p.id LEFT JOIN person n ON n.id=f.person_id {where} GROUP BY p.id ORDER BY COALESCE(p.taken_at,p.path) DESC LIMIT ? OFFSET ?''';args.extend([limit,offset])
 with connect() as c:return [dict(x) for x in c.execute(sql,args)]
def stats():
 with connect() as c:return (c.execute('SELECT COUNT(*) FROM photo').fetchone()[0],c.execute('SELECT COUNT(*) FROM person').fetchone()[0],c.execute('SELECT COUNT(*) FROM face').fetchone()[0],c.execute("SELECT COUNT(*) FROM face WHERE status='confirmed'").fetchone()[0])
