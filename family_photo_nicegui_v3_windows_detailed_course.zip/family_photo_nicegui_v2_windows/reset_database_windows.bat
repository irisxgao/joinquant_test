﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo This removes generated indexes only. Original photos are not deleted.
choice /M "Continue"
if errorlevel 2 exit /b 0
if exist "data\photos.db" del /q "data\photos.db"
if exist "data\photos.db-wal" del /q "data\photos.db-wal"
if exist "data\photos.db-shm" del /q "data\photos.db-shm"
del /q "data\thumbnails\*.jpg" 2>nul
del /q "data\face_crops\*.jpg" 2>nul
echo Reset complete.
pause
