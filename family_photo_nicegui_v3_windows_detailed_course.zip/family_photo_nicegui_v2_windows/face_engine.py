import numpy as np
from image_io import cv_imread
_engine=None
def engine():
 global _engine
 if _engine is None:
  from insightface.app import FaceAnalysis
  _engine=FaceAnalysis(name='buffalo_l',providers=['CPUExecutionProvider']);_engine.prepare(ctx_id=-1,det_size=(640,640))
 return _engine
def norm(v):
 v=np.asarray(v,dtype=np.float32);n=np.linalg.norm(v);return v/n if n else v
def build_reference(paths):
 vectors=[]
 for path in paths:
  faces=engine().get(cv_imread(path))
  if len(faces)==1:vectors.append(norm(faces[0].embedding))
 if not vectors:raise ValueError('参考照片中没有找到恰好一张清晰人脸，请换成单人正脸照片。')
 return norm(np.mean(vectors,axis=0)).astype(np.float32).tobytes(),len(vectors)
def recognize(image,people,threshold):
 refs=[(p['id'],np.frombuffer(p['embedding'],np.float32)) for p in people];out=[]
 for f in engine().get(image):
  e=norm(f.embedding);score,pid=max([(float(np.dot(e,v)),i) for i,v in refs],default=(-1,None));bbox=[int(x) for x in f.bbox]
  out.append((pid if score>=threshold else None,score if refs else None,bbox))
 return out
