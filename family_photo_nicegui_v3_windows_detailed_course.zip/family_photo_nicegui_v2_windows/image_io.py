from pathlib import Path
import cv2,numpy as np
def cv_imread(path):
 data=np.fromfile(str(Path(path)),dtype=np.uint8);image=cv2.imdecode(data,cv2.IMREAD_COLOR)
 if image is None:raise ValueError(f'无法读取图片：{path}')
 return image
def cv_imwrite(path,image):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);ok,data=cv2.imencode('.jpg',image,[cv2.IMWRITE_JPEG_QUALITY,90])
 if not ok:raise ValueError(f'无法保存图片：{path}')
 data.tofile(str(path))
