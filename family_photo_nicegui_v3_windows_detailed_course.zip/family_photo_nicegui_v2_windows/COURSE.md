# 课程目录（详细版）

请按编号学习。每课都以安装和环境检查开始。

- [课程使用说明](COURSE/00_课程使用说明.md)
- [需求拆解与项目地图](COURSE/01_需求拆解与项目地图.md)
- [Windows安装Python与虚拟环境](COURSE/02_Windows安装Python与虚拟环境.md)
- [NiceGUI从安装到第一个页面](COURSE/03_NiceGUI从安装到第一个页面.md)
- [SQLite从安装到数据模型](COURSE/04_SQLite从安装到数据模型.md)
- [Windows中文路径与UTF8](COURSE/05_Windows中文路径与UTF8.md)
- [人脸识别原理与安装检查](COURSE/06_人脸识别原理与安装检查.md)
- [照片扫描缩略图与增量索引](COURSE/07_照片扫描缩略图与增量索引.md)
- [分面筛选与AND_OR_SQL](COURSE/08_分面筛选与AND_OR_SQL.md)
- [人工确认与纠错](COURSE/09_人工确认与纠错.md)
- [日志排错隐私与备份](COURSE/10_日志排错隐私与备份.md)
- [源码调用链逐步阅读](COURSE/11_源码调用链逐步阅读.md)
- [结课项目与扩展路线](COURSE/12_结课项目与扩展路线.md)
