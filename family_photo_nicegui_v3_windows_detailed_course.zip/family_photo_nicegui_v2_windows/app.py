import json,logging,os,shutil,sys
from pathlib import Path
from nicegui import app,ui,run
import db
from face_engine import build_reference
from scanner import scan_directory
BASE=Path(__file__).parent;DATA=BASE/'data';REF=DATA/'references';TH=DATA/'thumbnails';CROPS=DATA/'face_crops';CONFIG=BASE/'config.json';LOG=BASE/'logs/app.log'
logging.basicConfig(filename=LOG,level=logging.INFO,encoding='utf-8',format='%(asctime)s %(levelname)s %(message)s');logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
app.add_static_files('/thumbs',TH);app.add_static_files('/crops',CROPS);db.init_db()
def load_config():return json.loads(CONFIG.read_text(encoding='utf-8-sig'))
def save_config(v):CONFIG.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
@ui.page('/',title='家庭照片整理器')
def page():
 config=load_config();state={'page':0,'photo_id':None};ui.colors(primary='#2563eb');ui.query('body').classes('bg-slate-50')
 with ui.header().classes('bg-white text-slate-800 shadow-sm justify-between'):
  ui.label('家庭照片整理器').classes('text-xl font-bold');stats=ui.label().classes('text-sm text-slate-500')
 with ui.left_drawer(value=True).classes('bg-white p-4'):
  ui.label('扫描设置').classes('font-bold');root=ui.input('照片目录',value=config.get('photo_root',''),placeholder=r'D:\家庭照片').props('outlined dense').classes('w-full');threshold=ui.number('识别阈值',value=config.get('match_threshold',.45),min=.1,max=.9,step=.01).classes('w-full');bar=ui.linear_progress(value=0);progress_label=ui.label('尚未扫描').classes('text-xs')
  async def start_scan():
   config.update(photo_root=(root.value or '').strip(),match_threshold=float(threshold.value));save_config(config);scan_button.disable()
   def report(v,t):bar.value=v;progress_label.set_text(t)
   try:
    x=await run.io_bound(scan_directory,config['photo_root'],config['match_threshold'],int(config.get('thumbnail_size',480)),report);ui.notify(f"完成：处理 {x['processed']}，跳过 {x['skipped']}，错误 {x['errors']}",type='positive');render()
   except Exception as e:logging.exception('扫描失败');ui.notify(str(e),type='negative',timeout=10000)
   finally:scan_button.enable()
  scan_button=ui.button('扫描照片',icon='document_scanner',on_click=start_scan).classes('w-full');ui.separator();ui.label('筛选').classes('font-bold');person_filter=ui.select({},label='人物',multiple=True,with_input=True,on_change=lambda _:reset()).props('outlined dense use-chips clearable').classes('w-full');mode=ui.radio({'all':'同时出现全部人物','any':'出现任意人物'},value='all',on_change=lambda _:reset()).props('dense');review_only=ui.checkbox('只看待确认照片',on_change=lambda _:reset());ui.button('人物管理',icon='group',on_click=lambda:person_dialog.open()).props('flat').classes('w-full')
 with ui.column().classes('w-full p-4'):
  result_label=ui.label().classes('text-sm text-slate-500');gallery=ui.element('div').classes('grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 w-full')
  with ui.row().classes('w-full justify-center items-center'):
   previous=ui.button('上一页',on_click=lambda:move(-1)).props('outline');page_label=ui.label();following=ui.button('下一页',on_click=lambda:move(1)).props('outline')
 with ui.dialog() as person_dialog,ui.card().classes('w-[700px] max-w-full'):
  ui.label('人物管理').classes('text-xl font-bold');ui.label('先输入姓名，再上传 5-10 张只有该人物的清晰正脸照。').classes('text-sm text-slate-500');name=ui.input('姓名').props('outlined').classes('w-full')
  async def upload(e):
   person=(name.value or '').strip()
   if not person:ui.notify('请先输入姓名，再选择照片。',type='warning');return
   folder=REF/person;folder.mkdir(parents=True,exist_ok=True);target=folder/Path(e.file.name).name;target.write_bytes(await e.file.read());ui.notify(f'已接收：{target.name}')
  ui.upload(label='参考照片',multiple=True,auto_upload=True,on_upload=upload).props('accept=image/*').classes('w-full')
  async def create_person():
   person=(name.value or '').strip()
   if not person:ui.notify('请输入姓名。',type='warning');return
   try:
    blob,used=await run.io_bound(build_reference,list((REF/person).glob('*')));db.add_person(person,blob);ui.notify(f'{person} 创建成功，采用 {used} 张照片。',type='positive');name.value='';refresh_people();render_people()
   except Exception as e:logging.exception('创建人物失败');ui.notify(str(e),type='negative',timeout=10000)
  ui.button('创建人物并提取特征',icon='person_add',on_click=create_person);people_list=ui.column().classes('w-full');ui.button('关闭',on_click=person_dialog.close).props('flat')
 with ui.dialog() as review_dialog,ui.card().classes('w-[900px] max-w-full'):
  review_title=ui.label('人工确认与纠错').classes('text-xl font-bold');review_photo=ui.image().classes('w-full max-h-[420px] object-contain bg-slate-100');ui.label('逐张脸选择正确人物并保存；未知人物表示暂不命名。').classes('text-sm text-slate-500');face_list=ui.column().classes('w-full');ui.button('关闭',on_click=review_dialog.close).props('flat')
 def render_people():
  people_list.clear()
  with people_list:
   for p in db.list_people():
    with ui.row().classes('w-full justify-between items-center'):
     ui.label(p['name']);ui.button(icon='delete',on_click=lambda _,x=p:remove_person(x)).props('flat round color=negative')
 def remove_person(p):db.delete_person(p['id']);shutil.rmtree(REF/p['name'],ignore_errors=True);refresh_people();render_people();render();ui.notify(f"已删除：{p['name']}")
 def refresh_people():
  options={p['id']:p['name'] for p in db.list_people()};person_filter.set_options(options);person_filter.value=[x for x in (person_filter.value or []) if x in options]
 def reset():state['page']=0;render()
 def move(d):state['page']=max(0,state['page']+d);render()
 def save_face(face_id,selector):
  value=selector.value
  if value in (0,None):db.mark_unknown(face_id)
  else:db.correct_face(face_id,int(value))
  ui.notify('人工确认已保存。',type='positive');open_review(state['photo_id']);render()
 def open_review(photo_id):
  state['photo_id']=photo_id;photo=db.get_photo(photo_id)
  if not photo:return
  review_title.set_text('人工确认：'+Path(photo['path']).name);review_photo.set_source('/thumbs/'+Path(photo['thumbnail_path']).name);face_list.clear();options={0:'未知人物 / 暂不命名',**{p['id']:p['name'] for p in db.list_people()}}
  with face_list:
   faces=db.photo_faces(photo_id)
   if not faces:ui.label('没有检测到人脸。').classes('text-slate-500')
   for i,face in enumerate(faces,1):
    with ui.card().classes('w-full'):
     with ui.row().classes('w-full items-center no-wrap'):
      if face.get('crop_path'):ui.image('/crops/'+Path(face['crop_path']).name).classes('w-24 h-24 object-cover rounded')
      with ui.column().classes('grow gap-1'):
       status='已人工确认' if face['status']=='confirmed' else '机器建议，待确认';score='无匹配分数' if face['similarity'] is None else f"相似度 {face['similarity']:.3f}";ui.label(f'人脸 {i} · {status} · {score}').classes('text-sm');selector=ui.select(options,value=face['person_id'] or 0,label='这个人是谁？').props('outlined dense').classes('w-full');ui.button('保存确认',icon='check',on_click=lambda _,fid=face['id'],s=selector:save_face(fid,s))
  review_dialog.open()
 def render():
  size=int(config.get('page_size',40));rows=db.query_photos(person_filter.value or [],mode.value,size,state['page']*size,review_only.value);gallery.clear()
  with gallery:
   for photo in rows:
    with ui.card().classes('p-0 overflow-hidden hover:shadow-lg'):
     ui.image('/thumbs/'+Path(photo['thumbnail_path']).name).classes('w-full aspect-square object-cover cursor-pointer').on('click',lambda _,pid=photo['id']:open_review(pid))
     with ui.column().classes('p-2 gap-1'):
      ui.label(Path(photo['path']).name).classes('text-sm font-medium truncate w-full');ui.label(photo.get('people') or '未识别人物').classes('text-xs text-slate-500');pending=int(photo.get('pending_count') or 0);ui.badge(f'{pending} 张脸待确认',color='orange' if pending else 'green');ui.button('确认/纠错',icon='face',on_click=lambda _,pid=photo['id']:open_review(pid)).props('flat dense');ui.button('打开原图',icon='open_in_new',on_click=lambda _,p=photo['path']:os.startfile(p)).props('flat dense')
  result_label.set_text(f'本页 {len(rows)} 张');page_label.set_text(f"第 {state['page']+1} 页");previous.set_enabled(state['page']>0);following.set_enabled(len(rows)==size);a,b,c,d=db.stats();stats.set_text(f'{a} 张照片 · {b} 个人物 · {c} 张脸 · {d} 已确认')
 refresh_people();render_people();render()
if __name__ in {'__main__','__mp_main__'}:ui.run(host='127.0.0.1',port=8080,title='家庭照片整理器',language='zh-CN',reload=False,show=True)
