# Final：完整项目

- 双击 `直接打开看效果.html` → 离线演示（内置模拟后端）
- `mvn spring-boot:run` → 打开 http://localhost:8080 （后台账号 admin / admin123）

详细教学内容见上级目录 `README.md`。
