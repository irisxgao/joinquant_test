package com.example.restaurant.order;

import com.example.restaurant.common.ApiException;
import com.example.restaurant.dish.DishRepository;
import com.example.restaurant.inventory.IngredientRepository;
import com.example.restaurant.order.OrderDtos.OrderView;
import com.example.restaurant.order.OrderDtos.PlaceOrderRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** 第 3 课：核心流程测试。@Transactional 让每个测试结束后自动回滚，互不影响。 */
@SpringBootTest
@Transactional
class OrderServiceTest {

    @Autowired OrderService orderService;
    @Autowired DishRepository dishRepo;
    @Autowired IngredientRepository ingredientRepo;
    @Autowired DiningTableRepository tableRepo;

    private Long tableId() {
        return tableRepo.findAll().get(0).id;
    }

    private BigDecimal eggStock() {
        return ingredientRepo.findByName("鸡蛋").orElseThrow().stockQty;
    }

    private PlaceOrderRequest order(String dish, int qty) {
        Long dishId = dishRepo.findByName(dish).orElseThrow().id;
        return new PlaceOrderRequest(tableId(), List.of(new PlaceOrderRequest.Item(dishId, qty)));
    }

    @Test
    void placeOrderDeductsStockByRecipe() {
        BigDecimal before = eggStock();
        OrderView v = orderService.placeOrder(order("番茄炒蛋", 2));   // 每份 3 个鸡蛋
        assertEquals(0, new BigDecimal("56").compareTo(v.totalAmount()));
        assertEquals(0, before.subtract(new BigDecimal("6")).compareTo(eggStock()));
    }

    @Test
    void insufficientStockRejectsWholeOrder() {
        BigDecimal before = eggStock();
        assertThrows(ApiException.class, () -> orderService.placeOrder(order("番茄炒蛋", 99)));
        assertEquals(0, before.compareTo(eggStock()));
    }

    @Test
    void cancelRestoresStock() {
        BigDecimal before = eggStock();
        OrderView v = orderService.placeOrder(order("番茄炒蛋", 1));
        orderService.cancel(v.id());
        assertEquals(0, before.compareTo(eggStock()));
    }

    @Test
    void cannotPayBeforeServe() {
        OrderView v = orderService.placeOrder(order("白米饭", 1));
        assertThrows(ApiException.class, () -> orderService.pay(v.id()));
    }
}
