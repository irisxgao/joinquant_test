package com.example.restaurant.order;

import com.example.restaurant.common.ApiException;
import com.example.restaurant.dish.Dish;
import com.example.restaurant.dish.DishRepository;
import com.example.restaurant.inventory.InventoryService;
import com.example.restaurant.inventory.StockMovement;
import com.example.restaurant.inventory.StockMovementRepository;
import com.example.restaurant.order.OrderDtos.OrderView;
import com.example.restaurant.order.OrderDtos.PlaceOrderRequest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 点菜主流程：下单(扣库存) → 出餐 → 结账(记收入) / 取消(退库存) */
@Service
public class OrderService {

    private final CustomerOrderRepository orderRepo;
    private final OrderItemRepository itemRepo;
    private final DiningTableRepository tableRepo;
    private final DishRepository dishRepo;
    private final DishRecipeRepository recipeRepo;
    private final InventoryService inventoryService;
    private final StockMovementRepository movementRepo;
    private final ApplicationEventPublisher publisher;

    public OrderService(CustomerOrderRepository orderRepo, OrderItemRepository itemRepo,
                        DiningTableRepository tableRepo, DishRepository dishRepo,
                        DishRecipeRepository recipeRepo, InventoryService inventoryService,
                        StockMovementRepository movementRepo, ApplicationEventPublisher publisher) {
        this.orderRepo = orderRepo;
        this.itemRepo = itemRepo;
        this.tableRepo = tableRepo;
        this.dishRepo = dishRepo;
        this.recipeRepo = recipeRepo;
        this.inventoryService = inventoryService;
        this.movementRepo = movementRepo;
        this.publisher = publisher;
    }

    /**
     * 下单。一个事务内完成：校验 → 算金额 → 保存订单 → 按配方扣库存。
     * 任何一种食材不够都会抛异常，订单和已扣的库存全部回滚。
     */
    @Transactional
    public OrderView placeOrder(PlaceOrderRequest req) {
        DiningTable table = tableRepo.findById(req.tableId())
                .orElseThrow(() -> ApiException.badRequest("餐桌不存在"));

        BigDecimal total = BigDecimal.ZERO;
        List<OrderItem> items = new ArrayList<>();
        // 同一种食材可能被多道菜使用，先汇总再一次性扣减
        Map<Long, BigDecimal> need = new LinkedHashMap<>();

        for (PlaceOrderRequest.Item line : req.items()) {
            Dish dish = dishRepo.findById(line.dishId())
                    .orElseThrow(() -> ApiException.badRequest("菜品不存在: " + line.dishId()));
            if (!dish.onSale) {
                throw ApiException.badRequest("【" + dish.name + "】已下架");
            }
            BigDecimal qty = BigDecimal.valueOf(line.qty());
            total = total.add(dish.price.multiply(qty));

            OrderItem oi = new OrderItem();
            oi.dishId = dish.id;
            oi.dishName = dish.name;
            oi.qty = line.qty();
            oi.unitPrice = dish.price;
            items.add(oi);

            for (DishRecipe r : recipeRepo.findByDishId(dish.id)) {
                need.merge(r.ingredientId, r.qty.multiply(qty), BigDecimal::add);
            }
        }

        CustomerOrder order = new CustomerOrder();
        order.tableId = table.id;
        order.status = CustomerOrder.PENDING;
        order.totalAmount = total;
        order.createdAt = LocalDateTime.now();
        orderRepo.save(order);

        for (OrderItem oi : items) {
            oi.orderId = order.id;
            itemRepo.save(oi);
        }

        // 扣库存放在最后：失败时抛异常，前面保存的订单也会一起回滚
        need.forEach((ingredientId, qty) -> inventoryService.deduct(ingredientId, qty, "ORDER", order.id));

        return new OrderView(order.id, table.id, table.code, order.status, order.totalAmount,
                order.createdAt, order.paidAt, items);
    }

    /** 厨房出餐 */
    @Transactional
    public OrderView serve(Long id) {
        CustomerOrder o = get(id);
        requireStatus(o, CustomerOrder.PENDING, "只有待出餐的订单才能出餐");
        o.status = CustomerOrder.SERVED;
        orderRepo.save(o);
        return view(o);
    }

    /** 结账：模拟收款成功，发布 OrderPaidEvent（财务模块监听后记收入） */
    @Transactional
    public OrderView pay(Long id) {
        CustomerOrder o = get(id);
        requireStatus(o, CustomerOrder.SERVED, "请先出餐再结账");
        o.status = CustomerOrder.PAID;
        o.paidAt = LocalDateTime.now();
        orderRepo.save(o);
        publisher.publishEvent(new OrderPaidEvent(o.id, o.totalAmount));
        return view(o);
    }

    /** 取消：只能取消待出餐订单，按出库流水原样退回库存 */
    @Transactional
    public OrderView cancel(Long id) {
        CustomerOrder o = get(id);
        requireStatus(o, CustomerOrder.PENDING, "已出餐的订单不能取消");
        o.status = CustomerOrder.CANCELLED;
        orderRepo.save(o);
        OrderView result = view(o);
        for (StockMovement m : movementRepo.findByRefTypeAndRefIdAndType("ORDER", id, StockMovement.OUT)) {
            inventoryService.restore(m.ingredientId, m.qty, m.unitCost, "ORDER", id);
        }
        return result;
    }

    public OrderView find(Long id) {
        return view(get(id));
    }

    public List<OrderView> list(String status) {
        List<CustomerOrder> orders = (status == null || status.isBlank())
                ? orderRepo.findTop200ByOrderByIdDesc()
                : orderRepo.findByStatusOrderByIdDesc(status);
        return orders.stream().map(this::view).toList();
    }

    private CustomerOrder get(Long id) {
        return orderRepo.findById(id).orElseThrow(() -> ApiException.notFound("订单不存在"));
    }

    private void requireStatus(CustomerOrder o, String expected, String msg) {
        if (!expected.equals(o.status)) {
            throw ApiException.badRequest(msg);
        }
    }

    private OrderView view(CustomerOrder o) {
        String code = tableRepo.findById(o.tableId).map(t -> t.code).orElse("?");
        return new OrderView(o.id, o.tableId, code, o.status, o.totalAmount, o.createdAt, o.paidAt,
                itemRepo.findByOrderId(o.id));
    }
}
