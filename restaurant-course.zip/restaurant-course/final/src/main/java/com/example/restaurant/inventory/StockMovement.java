package com.example.restaurant.inventory;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 库存流水：每一次库存变化都记一条，只增不改。
 * type：IN 采购入库 / OUT 消耗出库 / RETURN 取消退回 / ADJUST 盘点调整
 * refType + refId：这条流水由哪张单据产生（PURCHASE / ORDER / ADJUST）
 */
@Entity
public class StockMovement {
    public static final String IN = "IN";
    public static final String OUT = "OUT";
    public static final String RETURN = "RETURN";
    public static final String ADJUST = "ADJUST";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public Long ingredientId;

    @Column(nullable = false)
    public String type;

    /** 数量。ADJUST 可为负数 */
    @Column(nullable = false, precision = 14, scale = 3)
    public BigDecimal qty;

    /** 发生时的单位成本快照，用于计算食材成本 */
    @Column(nullable = false, precision = 14, scale = 2)
    public BigDecimal unitCost = BigDecimal.ZERO;

    public String refType;
    public Long refId;

    @Column(nullable = false)
    public LocalDateTime createdAt;
}
