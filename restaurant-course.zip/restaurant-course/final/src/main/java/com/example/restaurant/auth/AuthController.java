package com.example.restaurant.auth;

import com.example.restaurant.common.ApiException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AuthController {

    public record LoginRequest(String username, String password) {
    }

    private final TokenStore tokenStore;
    private final String username;
    private final String password;

    public AuthController(TokenStore tokenStore,
                          @Value("${app.admin.username:admin}") String username,
                          @Value("${app.admin.password:admin123}") String password) {
        this.tokenStore = tokenStore;
        this.username = username;
        this.password = password;
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody LoginRequest req) {
        if (!username.equals(req.username()) || !password.equals(req.password())) {
            throw ApiException.unauthorized("用户名或密码错误");
        }
        return Map.of("token", tokenStore.issue());
    }

    @PostMapping("/logout")
    public void logout(@RequestHeader(value = "X-Token", required = false) String token) {
        tokenStore.revoke(token);
    }
}
