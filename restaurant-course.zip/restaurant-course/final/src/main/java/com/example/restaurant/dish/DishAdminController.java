package com.example.restaurant.dish;

import com.example.restaurant.common.ApiException;
import com.example.restaurant.dish.DishRequests.CategoryRequest;
import com.example.restaurant.dish.DishRequests.DishRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** 后台：分类与菜品管理（增删改查 + 上下架） */
@RestController
@RequestMapping("/api/admin")
public class DishAdminController {

    private final DishCategoryRepository categoryRepo;
    private final DishRepository dishRepo;

    public DishAdminController(DishCategoryRepository categoryRepo, DishRepository dishRepo) {
        this.categoryRepo = categoryRepo;
        this.dishRepo = dishRepo;
    }

    // ---------------- 分类 ----------------

    @GetMapping("/categories")
    public List<DishCategory> listCategories() {
        return categoryRepo.findAll(Sort.by("sort"));
    }

    @PostMapping("/categories")
    public DishCategory createCategory(@Valid @RequestBody CategoryRequest req) {
        DishCategory c = new DishCategory();
        c.name = req.name();
        c.sort = req.sort() == null ? 0 : req.sort();
        return categoryRepo.save(c);
    }

    @PutMapping("/categories/{id}")
    public DishCategory updateCategory(@PathVariable Long id, @Valid @RequestBody CategoryRequest req) {
        DishCategory c = categoryRepo.findById(id).orElseThrow(() -> ApiException.notFound("分类不存在"));
        c.name = req.name();
        if (req.sort() != null) {
            c.sort = req.sort();
        }
        return categoryRepo.save(c);
    }

    @DeleteMapping("/categories/{id}")
    public void deleteCategory(@PathVariable Long id) {
        if (dishRepo.existsByCategoryId(id)) {
            throw ApiException.badRequest("该分类下还有菜品，不能删除");
        }
        categoryRepo.deleteById(id);
    }

    // ---------------- 菜品 ----------------

    @GetMapping("/dishes")
    public List<Dish> listDishes() {
        return dishRepo.findAll(Sort.by("categoryId", "id"));
    }

    @PostMapping("/dishes")
    public Dish createDish(@Valid @RequestBody DishRequest req) {
        Dish d = new Dish();
        apply(d, req);
        return dishRepo.save(d);
    }

    @PutMapping("/dishes/{id}")
    public Dish updateDish(@PathVariable Long id, @Valid @RequestBody DishRequest req) {
        Dish d = dishRepo.findById(id).orElseThrow(() -> ApiException.notFound("菜品不存在"));
        apply(d, req);
        return dishRepo.save(d);
    }

    /** 上架 / 下架。已有订单引用的菜品，建议下架而不是删除。 */
    @PatchMapping("/dishes/{id}/on-sale")
    public Dish setOnSale(@PathVariable Long id, @RequestParam boolean value) {
        Dish d = dishRepo.findById(id).orElseThrow(() -> ApiException.notFound("菜品不存在"));
        d.onSale = value;
        return dishRepo.save(d);
    }

    @DeleteMapping("/dishes/{id}")
    public void deleteDish(@PathVariable Long id) {
        dishRepo.deleteById(id);
    }

    private void apply(Dish d, DishRequest req) {
        if (!categoryRepo.existsById(req.categoryId())) {
            throw ApiException.badRequest("分类不存在");
        }
        d.categoryId = req.categoryId();
        d.name = req.name();
        d.price = req.price();
        if (req.onSale() != null) {
            d.onSale = req.onSale();
        }
    }
}
