package com.example.restaurant.finance;

import com.example.restaurant.finance.FinanceDtos.ExpenseRequest;
import com.example.restaurant.finance.FinanceDtos.Report;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/** 后台：财务流水、手工记支出、经营报表。日期参数格式 yyyy-MM-dd，不传默认今天。 */
@RestController
@RequestMapping("/api/admin/finance")
public class FinanceController {

    private final FinanceService financeService;

    public FinanceController(FinanceService financeService) {
        this.financeService = financeService;
    }

    @GetMapping("/records")
    public List<FinanceRecord> records(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                                       @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        LocalDate f = from == null ? LocalDate.now() : from;
        return financeService.list(f, to == null ? f : to);
    }

    @PostMapping("/expenses")
    public FinanceRecord addExpense(@Valid @RequestBody ExpenseRequest req) {
        return financeService.record(FinanceRecord.EXPENSE, req.category(), req.amount(), "MANUAL", null, req.remark());
    }

    @GetMapping("/report")
    public Report report(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                         @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        LocalDate f = from == null ? LocalDate.now() : from;
        return financeService.report(f, to == null ? f : to);
    }
}
