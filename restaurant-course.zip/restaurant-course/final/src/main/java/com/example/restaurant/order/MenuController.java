package com.example.restaurant.order;

import com.example.restaurant.common.ApiException;
import com.example.restaurant.dish.Dish;
import com.example.restaurant.dish.DishCategory;
import com.example.restaurant.dish.DishCategoryRepository;
import com.example.restaurant.dish.DishRepository;
import com.example.restaurant.inventory.Ingredient;
import com.example.restaurant.inventory.IngredientRepository;
import com.example.restaurant.order.OrderDtos.MenuCategory;
import com.example.restaurant.order.OrderDtos.MenuDish;
import com.example.restaurant.order.OrderDtos.RecipeLine;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/** 客人端菜单（带"售罄"判断）、餐桌列表，以及后台配方设置 */
@RestController
@Validated
public class MenuController {

    private final DishCategoryRepository categoryRepo;
    private final DishRepository dishRepo;
    private final DishRecipeRepository recipeRepo;
    private final IngredientRepository ingredientRepo;
    private final DiningTableRepository tableRepo;

    public MenuController(DishCategoryRepository categoryRepo, DishRepository dishRepo,
                          DishRecipeRepository recipeRepo, IngredientRepository ingredientRepo,
                          DiningTableRepository tableRepo) {
        this.categoryRepo = categoryRepo;
        this.dishRepo = dishRepo;
        this.recipeRepo = recipeRepo;
        this.ingredientRepo = ingredientRepo;
        this.tableRepo = tableRepo;
    }

    @GetMapping("/api/tables")
    public List<DiningTable> tables() {
        return tableRepo.findAll(Sort.by("id"));
    }

    /** 菜单：只返回上架菜品；任意一种食材不够做一份，就标记为售罄 */
    @GetMapping("/api/menu")
    public List<MenuCategory> menu() {
        Map<Long, BigDecimal> stock = ingredientRepo.findAll().stream()
                .collect(Collectors.toMap(i -> i.id, i -> i.stockQty));
        Map<Long, List<DishRecipe>> recipes = recipeRepo.findAll().stream()
                .collect(Collectors.groupingBy(r -> r.dishId));
        Map<Long, List<Dish>> dishesByCat = dishRepo.findByOnSaleTrue().stream()
                .collect(Collectors.groupingBy(d -> d.categoryId));

        List<MenuCategory> result = new ArrayList<>();
        for (DishCategory c : categoryRepo.findAll(Sort.by("sort"))) {
            List<MenuDish> dishes = dishesByCat.getOrDefault(c.id, List.of()).stream()
                    .map(d -> new MenuDish(d.id, d.name, d.price,
                            recipes.getOrDefault(d.id, List.of()).stream()
                                    .anyMatch(r -> stock.getOrDefault(r.ingredientId, BigDecimal.ZERO).compareTo(r.qty) < 0)))
                    .toList();
            if (!dishes.isEmpty()) {
                result.add(new MenuCategory(c.id, c.name, dishes));
            }
        }
        return result;
    }

    // ---------- 后台：配方 ----------

    @GetMapping("/api/admin/dishes/{dishId}/recipe")
    public List<DishRecipe> getRecipe(@PathVariable Long dishId) {
        return recipeRepo.findByDishId(dishId);
    }

    /** 整体替换配方：先删后插 */
    @PutMapping("/api/admin/dishes/{dishId}/recipe")
    @Transactional
    public List<DishRecipe> setRecipe(@PathVariable Long dishId, @RequestBody List<@Valid RecipeLine> lines) {
        if (!dishRepo.existsById(dishId)) {
            throw ApiException.notFound("菜品不存在");
        }
        Map<Long, Ingredient> ings = ingredientRepo.findAll().stream()
                .collect(Collectors.toMap(i -> i.id, Function.identity()));
        recipeRepo.deleteByDishId(dishId);
        recipeRepo.flush();
        List<DishRecipe> saved = new ArrayList<>();
        for (RecipeLine line : lines) {
            if (!ings.containsKey(line.ingredientId())) {
                throw ApiException.badRequest("食材不存在: " + line.ingredientId());
            }
            DishRecipe r = new DishRecipe();
            r.dishId = dishId;
            r.ingredientId = line.ingredientId();
            r.qty = line.qty();
            saved.add(recipeRepo.save(r));
        }
        return saved;
    }
}
