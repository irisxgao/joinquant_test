package com.example.restaurant.finance;

import com.example.restaurant.inventory.PurchaseCreatedEvent;
import com.example.restaurant.order.OrderPaidEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * 自动记账：监听其他模块发布的事件。
 * 用的是 @EventListener（同步、同一事务）：如果记账失败，采购/结账也会一起回滚，账和业务永远一致。
 */
@Component
public class FinanceEventListener {

    private final FinanceService financeService;

    public FinanceEventListener(FinanceService financeService) {
        this.financeService = financeService;
    }

    @EventListener
    public void onOrderPaid(OrderPaidEvent e) {
        financeService.record(FinanceRecord.INCOME, "销售收入", e.amount(), "ORDER", e.orderId(), "订单 #" + e.orderId());
    }

    @EventListener
    public void onPurchase(PurchaseCreatedEvent e) {
        financeService.record(FinanceRecord.EXPENSE, "食材采购", e.totalAmount(), "PURCHASE", e.purchaseId(), "采购单 #" + e.purchaseId());
    }
}
