package com.example.restaurant.order;

import com.example.restaurant.dish.DishRepository;
import com.example.restaurant.inventory.IngredientRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/** 示例餐桌和配方（第 3 课） */
@Component
@Order(3)
public class OrderSeeder implements CommandLineRunner {

    private final DiningTableRepository tableRepo;
    private final DishRecipeRepository recipeRepo;
    private final DishRepository dishRepo;
    private final IngredientRepository ingredientRepo;

    public OrderSeeder(DiningTableRepository tableRepo, DishRecipeRepository recipeRepo,
                       DishRepository dishRepo, IngredientRepository ingredientRepo) {
        this.tableRepo = tableRepo;
        this.recipeRepo = recipeRepo;
        this.dishRepo = dishRepo;
        this.ingredientRepo = ingredientRepo;
    }

    @Override
    public void run(String... args) {
        if (tableRepo.count() > 0) {
            return;
        }
        for (int i = 1; i <= 6; i++) {
            DiningTable t = new DiningTable();
            t.code = "A" + i;
            tableRepo.save(t);
        }
        recipe("番茄炒蛋", "鸡蛋", "3");
        recipe("番茄炒蛋", "番茄", "0.3");
        recipe("宫保鸡丁", "鸡胸肉", "0.3");
        recipe("宫保鸡丁", "花生", "0.05");
        recipe("麻婆豆腐", "豆腐", "1");
        recipe("麻婆豆腐", "猪肉", "0.05");
        recipe("青椒肉丝", "猪肉", "0.25");
        recipe("青椒肉丝", "青椒", "0.2");
        recipe("扬州炒饭", "大米", "0.2");
        recipe("扬州炒饭", "鸡蛋", "1");
        recipe("白米饭", "大米", "0.15");
        recipe("酸辣汤", "豆腐", "0.5");
        recipe("酸辣汤", "鸡蛋", "1");
        recipe("酸梅汤", "酸梅汤原浆", "0.1");
    }

    private void recipe(String dish, String ingredient, String qty) {
        DishRecipe r = new DishRecipe();
        r.dishId = dishRepo.findByName(dish).orElseThrow().id;
        r.ingredientId = ingredientRepo.findByName(ingredient).orElseThrow().id;
        r.qty = new BigDecimal(qty);
        recipeRepo.save(r);
    }
}
