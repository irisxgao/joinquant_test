package com.example.restaurant.inventory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface IngredientRepository extends JpaRepository<Ingredient, Long> {

    Optional<Ingredient> findByName(String name);

    /** 低于安全库存的食材 */
    @Query("select i from Ingredient i where i.stockQty < i.safetyQty")
    List<Ingredient> findLowStock();

    /**
     * 原子扣减库存：只有库存足够时才会更新成功（返回 1），否则返回 0。
     * 这条 SQL 由数据库保证原子性，两个客人同时抢最后一份也不会超卖。
     * flush/clear：执行前先把未提交的修改写入数据库，执行后清空一级缓存，避免读到旧数据。
     */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("update Ingredient i set i.stockQty = i.stockQty - :qty where i.id = :id and i.stockQty >= :qty")
    int deduct(@Param("id") Long id, @Param("qty") BigDecimal qty);

    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("update Ingredient i set i.stockQty = i.stockQty + :qty where i.id = :id")
    int restore(@Param("id") Long id, @Param("qty") BigDecimal qty);
}
