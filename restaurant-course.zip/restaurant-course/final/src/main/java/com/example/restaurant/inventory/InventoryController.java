package com.example.restaurant.inventory;

import com.example.restaurant.common.ApiException;
import com.example.restaurant.inventory.InventoryRequests.AdjustRequest;
import com.example.restaurant.inventory.InventoryRequests.IngredientRequest;
import com.example.restaurant.inventory.InventoryRequests.PurchaseRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** 后台：食材、采购入库、盘点、库存流水、库存预警 */
@RestController
@RequestMapping("/api/admin")
public class InventoryController {

    private final IngredientRepository ingredientRepo;
    private final StockMovementRepository movementRepo;
    private final PurchaseRepository purchaseRepo;
    private final PurchaseItemRepository purchaseItemRepo;
    private final InventoryService inventoryService;

    public InventoryController(IngredientRepository ingredientRepo, StockMovementRepository movementRepo,
                               PurchaseRepository purchaseRepo, PurchaseItemRepository purchaseItemRepo,
                               InventoryService inventoryService) {
        this.ingredientRepo = ingredientRepo;
        this.movementRepo = movementRepo;
        this.purchaseRepo = purchaseRepo;
        this.purchaseItemRepo = purchaseItemRepo;
        this.inventoryService = inventoryService;
    }

    @GetMapping("/ingredients")
    public List<Ingredient> listIngredients() {
        return ingredientRepo.findAll(Sort.by("id"));
    }

    /** 新建食材时库存为 0，库存只能通过采购或盘点改变 */
    @PostMapping("/ingredients")
    public Ingredient createIngredient(@Valid @RequestBody IngredientRequest req) {
        if (ingredientRepo.findByName(req.name()).isPresent()) {
            throw ApiException.badRequest("食材已存在: " + req.name());
        }
        Ingredient i = new Ingredient();
        i.name = req.name();
        i.unit = req.unit();
        i.safetyQty = req.safetyQty();
        return ingredientRepo.save(i);
    }

    @PutMapping("/ingredients/{id}")
    public Ingredient updateIngredient(@PathVariable Long id, @Valid @RequestBody IngredientRequest req) {
        Ingredient i = ingredientRepo.findById(id).orElseThrow(() -> ApiException.notFound("食材不存在"));
        i.name = req.name();
        i.unit = req.unit();
        i.safetyQty = req.safetyQty();
        return ingredientRepo.save(i);
    }

    @PostMapping("/purchases")
    public Purchase purchase(@Valid @RequestBody PurchaseRequest req) {
        return inventoryService.purchase(req);
    }

    @GetMapping("/purchases")
    public List<Purchase> listPurchases() {
        return purchaseRepo.findTop100ByOrderByIdDesc();
    }

    @GetMapping("/purchases/{id}")
    public Map<String, Object> purchaseDetail(@PathVariable Long id) {
        Purchase p = purchaseRepo.findById(id).orElseThrow(() -> ApiException.notFound("采购单不存在"));
        return Map.of("purchase", p, "items", purchaseItemRepo.findByPurchaseId(id));
    }

    @PostMapping("/stock/adjust")
    public Ingredient adjust(@Valid @RequestBody AdjustRequest req) {
        return inventoryService.adjust(req);
    }

    @GetMapping("/stock/alerts")
    public List<Ingredient> alerts() {
        return inventoryService.lowStock();
    }

    @GetMapping("/stock/movements")
    public List<StockMovement> movements(@RequestParam(required = false) Long ingredientId) {
        return ingredientId == null
                ? movementRepo.findTop200ByOrderByIdDesc()
                : movementRepo.findByIngredientIdOrderByIdDesc(ingredientId);
    }
}
