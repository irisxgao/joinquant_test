package com.example.restaurant.order;

import jakarta.persistence.*;

import java.math.BigDecimal;

/** 配方：一份菜品要消耗多少某种食材。它是"菜品"和"库存"之间的桥梁。 */
@Entity
public class DishRecipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public Long dishId;

    @Column(nullable = false)
    public Long ingredientId;

    /** 每份用量 */
    @Column(nullable = false, precision = 14, scale = 3)
    public BigDecimal qty;
}
