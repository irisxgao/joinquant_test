package com.example.restaurant.inventory;

import com.example.restaurant.inventory.InventoryRequests.PurchaseRequest;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** 示例食材 + 一张开业采购单（第 2 课）。库存通过"采购"产生，而不是直接写数字。 */
@Component
@Order(2)
public class InventorySeeder implements CommandLineRunner {

    private final IngredientRepository ingredientRepo;
    private final InventoryService inventoryService;

    public InventorySeeder(IngredientRepository ingredientRepo, InventoryService inventoryService) {
        this.ingredientRepo = ingredientRepo;
        this.inventoryService = inventoryService;
    }

    @Override
    public void run(String... args) {
        if (ingredientRepo.count() > 0) {
            return;
        }
        // 名称, 单位, 安全库存, 首次采购量, 采购单价
        Object[][] data = {
                {"鸡蛋", "个", "20", "100", "1.2"},
                {"番茄", "kg", "3", "10", "8"},
                {"鸡胸肉", "kg", "2", "8", "26"},
                {"花生", "kg", "1", "3", "18"},
                {"豆腐", "块", "5", "30", "3"},
                {"猪肉", "kg", "2", "8", "32"},
                {"青椒", "kg", "1", "5", "9"},
                {"大米", "kg", "5", "25", "6"},
                {"酸梅汤原浆", "L", "1", "5", "20"},
        };
        List<PurchaseRequest.Item> items = new ArrayList<>();
        for (Object[] row : data) {
            Ingredient i = new Ingredient();
            i.name = (String) row[0];
            i.unit = (String) row[1];
            i.safetyQty = new BigDecimal((String) row[2]);
            ingredientRepo.save(i);
            items.add(new PurchaseRequest.Item(i.id, new BigDecimal((String) row[3]), new BigDecimal((String) row[4])));
        }
        inventoryService.purchase(new PurchaseRequest("开业首批采购", items));
    }
}
