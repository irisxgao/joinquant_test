package com.example.restaurant.dish;

import jakarta.persistence.*;

import java.math.BigDecimal;

/** 菜品。只保存 categoryId 而不做 @ManyToOne 关联，避免懒加载和 JSON 循环引用问题。 */
@Entity
public class Dish {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public Long categoryId;

    @Column(nullable = false)
    public String name;

    /** 金额一律用 BigDecimal，不要用 double */
    @Column(nullable = false)
    public BigDecimal price;

    /** 是否上架 */
    public boolean onSale = true;
}
