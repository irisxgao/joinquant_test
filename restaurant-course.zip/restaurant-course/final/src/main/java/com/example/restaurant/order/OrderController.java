package com.example.restaurant.order;

import com.example.restaurant.order.OrderDtos.OrderView;
import com.example.restaurant.order.OrderDtos.PlaceOrderRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** 订单接口：客人端（/api/orders）+ 后台（/api/admin/orders） */
@RestController
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // ---------- 客人端 ----------

    @PostMapping("/api/orders")
    public OrderView place(@Valid @RequestBody PlaceOrderRequest req) {
        return orderService.placeOrder(req);
    }

    @GetMapping("/api/orders/{id}")
    public OrderView get(@PathVariable Long id) {
        return orderService.find(id);
    }

    // ---------- 后台 ----------

    @GetMapping("/api/admin/orders")
    public List<OrderView> list(@RequestParam(required = false) String status) {
        return orderService.list(status);
    }

    @PostMapping("/api/admin/orders/{id}/serve")
    public OrderView serve(@PathVariable Long id) {
        return orderService.serve(id);
    }

    @PostMapping("/api/admin/orders/{id}/pay")
    public OrderView pay(@PathVariable Long id) {
        return orderService.pay(id);
    }

    @PostMapping("/api/admin/orders/{id}/cancel")
    public OrderView cancel(@PathVariable Long id) {
        return orderService.cancel(id);
    }
}
