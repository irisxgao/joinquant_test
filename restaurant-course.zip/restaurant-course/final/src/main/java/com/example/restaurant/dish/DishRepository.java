package com.example.restaurant.dish;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DishRepository extends JpaRepository<Dish, Long> {
    boolean existsByCategoryId(Long categoryId);

    List<Dish> findByOnSaleTrue();

    Optional<Dish> findByName(String name);
}
