package com.example.restaurant.finance;

import com.example.restaurant.finance.FinanceDtos.DailyRow;
import com.example.restaurant.finance.FinanceDtos.Report;
import com.example.restaurant.inventory.StockMovement;
import com.example.restaurant.inventory.StockMovementRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

@Service
public class FinanceService {

    private final FinanceRecordRepository recordRepo;
    private final StockMovementRepository movementRepo;

    public FinanceService(FinanceRecordRepository recordRepo, StockMovementRepository movementRepo) {
        this.recordRepo = recordRepo;
        this.movementRepo = movementRepo;
    }

    @Transactional
    public FinanceRecord record(String type, String category, BigDecimal amount, String refType, Long refId, String remark) {
        FinanceRecord r = new FinanceRecord();
        r.type = type;
        r.category = category;
        r.amount = amount;
        r.refType = refType;
        r.refId = refId;
        r.remark = remark;
        r.createdAt = LocalDateTime.now();
        return recordRepo.save(r);
    }

    public List<FinanceRecord> list(LocalDate from, LocalDate to) {
        return recordRepo.findByCreatedAtBetweenOrderByIdDesc(from.atStartOfDay(), to.atTime(LocalTime.MAX));
    }

    public Report report(LocalDate from, LocalDate to) {
        LocalDateTime start = from.atStartOfDay();
        LocalDateTime end = to.atTime(LocalTime.MAX);
        List<FinanceRecord> records = recordRepo.findByCreatedAtBetweenOrderByIdDesc(start, end);

        BigDecimal sales = BigDecimal.ZERO, income = BigDecimal.ZERO, expense = BigDecimal.ZERO;
        long paidOrders = 0;
        Map<String, BigDecimal> byCategory = new TreeMap<>();
        Map<LocalDate, BigDecimal[]> daily = new TreeMap<>();

        for (FinanceRecord r : records) {
            BigDecimal[] day = daily.computeIfAbsent(r.createdAt.toLocalDate(),
                    d -> new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO});
            if (FinanceRecord.INCOME.equals(r.type)) {
                income = income.add(r.amount);
                day[0] = day[0].add(r.amount);
                if ("ORDER".equals(r.refType)) {
                    sales = sales.add(r.amount);
                    paidOrders++;
                }
            } else {
                expense = expense.add(r.amount);
                day[1] = day[1].add(r.amount);
                byCategory.merge(r.category, r.amount, BigDecimal::add);
            }
        }

        // 食材成本：订单出库 − 取消退回（按出库时的成本价）
        BigDecimal foodCost = BigDecimal.ZERO;
        for (StockMovement m : movementRepo.findByTypeInAndCreatedAtBetween(
                List.of(StockMovement.OUT, StockMovement.RETURN), start, end)) {
            BigDecimal cost = m.qty.multiply(m.unitCost);
            foodCost = StockMovement.OUT.equals(m.type) ? foodCost.add(cost) : foodCost.subtract(cost);
        }
        foodCost = foodCost.setScale(2, RoundingMode.HALF_UP);

        BigDecimal gross = sales.subtract(foodCost);
        String margin = sales.signum() == 0 ? "-"
                : gross.multiply(BigDecimal.valueOf(100)).divide(sales, 1, RoundingMode.HALF_UP) + "%";

        List<DailyRow> rows = new ArrayList<>();
        daily.forEach((d, v) -> rows.add(new DailyRow(d, v[0], v[1], v[0].subtract(v[1]))));

        return new Report(from, to, paidOrders, sales, foodCost, gross, margin,
                income, expense, income.subtract(expense), byCategory, rows);
    }
}
