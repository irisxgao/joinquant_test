package com.example.restaurant.auth;

import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** 最简登录态：内存里存 token。重启即失效；正式项目可换成 JWT 或 Redis。 */
@Component
public class TokenStore {
    private final Set<String> tokens = ConcurrentHashMap.newKeySet();

    public String issue() {
        String t = UUID.randomUUID().toString();
        tokens.add(t);
        return t;
    }

    public boolean valid(String token) {
        return token != null && tokens.contains(token);
    }

    public void revoke(String token) {
        if (token != null) {
            tokens.remove(token);
        }
    }
}
