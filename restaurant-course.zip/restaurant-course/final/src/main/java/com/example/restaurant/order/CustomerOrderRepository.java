package com.example.restaurant.order;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {
    List<CustomerOrder> findTop200ByOrderByIdDesc();

    List<CustomerOrder> findByStatusOrderByIdDesc(String status);
}
