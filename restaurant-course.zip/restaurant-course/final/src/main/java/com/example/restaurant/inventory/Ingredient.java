package com.example.restaurant.inventory;

import jakarta.persistence.*;

import java.math.BigDecimal;

/** 食材（库存商品） */
@Entity
public class Ingredient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false, unique = true)
    public String name;

    /** 单位：个、kg、块、份…… */
    @Column(nullable = false)
    public String unit;

    /** 当前库存数量（冗余字段，真实来源是 StockMovement 流水） */
    @Column(nullable = false, precision = 14, scale = 3)
    public BigDecimal stockQty = BigDecimal.ZERO;

    /** 加权平均成本（每单位） */
    @Column(nullable = false, precision = 14, scale = 2)
    public BigDecimal avgCost = BigDecimal.ZERO;

    /** 安全库存，低于它就预警 */
    @Column(nullable = false, precision = 14, scale = 3)
    public BigDecimal safetyQty = BigDecimal.ZERO;
}
