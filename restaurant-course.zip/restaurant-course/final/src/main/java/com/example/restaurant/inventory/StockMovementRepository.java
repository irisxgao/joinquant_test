package com.example.restaurant.inventory;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {

    List<StockMovement> findTop200ByOrderByIdDesc();

    List<StockMovement> findByIngredientIdOrderByIdDesc(Long ingredientId);

    List<StockMovement> findByRefTypeAndRefIdAndType(String refType, Long refId, String type);

    /** 第 4 课财务报表用：统计时间段内的出库 / 退回流水 */
    List<StockMovement> findByTypeInAndCreatedAtBetween(Collection<String> types, LocalDateTime from, LocalDateTime to);
}
