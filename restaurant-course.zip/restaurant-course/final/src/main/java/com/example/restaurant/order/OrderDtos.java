package com.example.restaurant.order;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public final class OrderDtos {
    private OrderDtos() {
    }

    /** 下单请求 */
    public record PlaceOrderRequest(@NotNull Long tableId, @NotEmpty List<@Valid Item> items) {
        public record Item(@NotNull Long dishId, @NotNull @Min(1) @Max(99) Integer qty) {
        }
    }

    /** 订单返回给前端的视图 */
    public record OrderView(Long id, Long tableId, String tableCode, String status, BigDecimal totalAmount,
                            LocalDateTime createdAt, LocalDateTime paidAt, List<OrderItem> items) {
    }

    /** 客人端菜单 */
    public record MenuCategory(Long id, String name, List<MenuDish> dishes) {
    }

    public record MenuDish(Long id, String name, BigDecimal price, boolean soldOut) {
    }

    /** 配方设置 */
    public record RecipeLine(@NotNull Long ingredientId, @NotNull @Positive BigDecimal qty) {
    }
}
