package com.example.restaurant.inventory;

import jakarta.persistence.*;

import java.math.BigDecimal;

/** 采购单明细（单身） */
@Entity
public class PurchaseItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public Long purchaseId;

    @Column(nullable = false)
    public Long ingredientId;

    @Column(nullable = false, precision = 14, scale = 3)
    public BigDecimal qty;

    @Column(nullable = false, precision = 14, scale = 2)
    public BigDecimal unitPrice;
}
