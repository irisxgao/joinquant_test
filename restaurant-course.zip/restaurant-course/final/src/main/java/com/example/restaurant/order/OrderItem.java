package com.example.restaurant.order;

import jakarta.persistence.*;

import java.math.BigDecimal;

/** 订单明细。菜名和单价存"快照"：以后菜品改价，历史订单金额不受影响。 */
@Entity
public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public Long orderId;

    @Column(nullable = false)
    public Long dishId;

    @Column(nullable = false)
    public String dishName;

    @Column(nullable = false)
    public int qty;

    @Column(nullable = false, precision = 14, scale = 2)
    public BigDecimal unitPrice;
}
