package com.example.restaurant.order;

import jakarta.persistence.*;

/** 餐桌。客人扫码打开 index.html?table=1 即可点菜。 */
@Entity
public class DiningTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false, unique = true)
    public String code;
}
