package com.example.restaurant.dish;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

/** 请求体（DTO）。用 record 定义，不直接把实体暴露为入参，避免客户端篡改 id 等字段。 */
public final class DishRequests {
    private DishRequests() {
    }

    public record CategoryRequest(@NotBlank String name, Integer sort) {
    }

    public record DishRequest(@NotNull Long categoryId,
                              @NotBlank String name,
                              @NotNull @Positive BigDecimal price,
                              Boolean onSale) {
    }
}
