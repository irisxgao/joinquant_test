package com.example.restaurant.inventory;

import com.example.restaurant.common.ApiException;
import com.example.restaurant.inventory.InventoryRequests.AdjustRequest;
import com.example.restaurant.inventory.InventoryRequests.PurchaseRequest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;

/** 进销存核心逻辑：入库、出库、退回、盘点。所有改库存的地方都必须经过这里。 */
@Service
public class InventoryService {

    private final IngredientRepository ingredientRepo;
    private final StockMovementRepository movementRepo;
    private final PurchaseRepository purchaseRepo;
    private final PurchaseItemRepository purchaseItemRepo;
    private final ApplicationEventPublisher publisher;

    public InventoryService(IngredientRepository ingredientRepo, StockMovementRepository movementRepo,
                            PurchaseRepository purchaseRepo, PurchaseItemRepository purchaseItemRepo,
                            ApplicationEventPublisher publisher) {
        this.ingredientRepo = ingredientRepo;
        this.movementRepo = movementRepo;
        this.purchaseRepo = purchaseRepo;
        this.purchaseItemRepo = purchaseItemRepo;
        this.publisher = publisher;
    }

    /** 采购入库：加库存、重算加权平均成本、写 IN 流水、发布事件。整个方法在一个事务里。 */
    @Transactional
    public Purchase purchase(PurchaseRequest req) {
        Purchase p = new Purchase();
        p.remark = req.remark();
        p.createdAt = LocalDateTime.now();
        purchaseRepo.save(p);

        BigDecimal total = BigDecimal.ZERO;
        for (PurchaseRequest.Item item : req.items()) {
            Ingredient ing = getIngredient(item.ingredientId());
            BigDecimal amount = item.qty().multiply(item.unitPrice());

            // 加权平均成本 = (原库存 × 原成本 + 本次金额) / (原库存 + 本次数量)
            BigDecimal oldQty = ing.stockQty.max(BigDecimal.ZERO);
            BigDecimal newQty = oldQty.add(item.qty());
            ing.avgCost = oldQty.multiply(ing.avgCost).add(amount).divide(newQty, 2, RoundingMode.HALF_UP);
            ing.stockQty = ing.stockQty.add(item.qty());
            ingredientRepo.save(ing);

            PurchaseItem pi = new PurchaseItem();
            pi.purchaseId = p.id;
            pi.ingredientId = ing.id;
            pi.qty = item.qty();
            pi.unitPrice = item.unitPrice();
            purchaseItemRepo.save(pi);

            record(ing.id, StockMovement.IN, item.qty(), item.unitPrice(), "PURCHASE", p.id);
            total = total.add(amount);
        }
        p.totalAmount = total.setScale(2, RoundingMode.HALF_UP);
        purchaseRepo.save(p);

        publisher.publishEvent(new PurchaseCreatedEvent(p.id, p.totalAmount));
        return p;
    }

    /** 盘点：把库存改成实际数量，差额记 ADJUST 流水（可正可负）。 */
    @Transactional
    public Ingredient adjust(AdjustRequest req) {
        Ingredient ing = getIngredient(req.ingredientId());
        BigDecimal diff = req.actualQty().subtract(ing.stockQty);
        if (diff.signum() == 0) {
            return ing;
        }
        ing.stockQty = req.actualQty();
        ingredientRepo.save(ing);
        record(ing.id, StockMovement.ADJUST, diff, ing.avgCost, "ADJUST", null);
        return ing;
    }

    /**
     * 消耗出库（下单时调用）。必须在调用方的事务中执行：库存不足抛异常，整个订单回滚。
     */
    @Transactional
    public void deduct(Long ingredientId, BigDecimal qty, String refType, Long refId) {
        Ingredient ing = getIngredient(ingredientId);
        int updated = ingredientRepo.deduct(ingredientId, qty);
        if (updated == 0) {
            throw ApiException.badRequest("食材【" + ing.name + "】库存不足，需要 " + qty.stripTrailingZeros().toPlainString()
                    + ing.unit + "，现有 " + ing.stockQty.stripTrailingZeros().toPlainString() + ing.unit);
        }
        record(ingredientId, StockMovement.OUT, qty, ing.avgCost, refType, refId);
    }

    /** 退回库存（取消订单时调用），成本按出库时的成本退回。 */
    @Transactional
    public void restore(Long ingredientId, BigDecimal qty, BigDecimal unitCost, String refType, Long refId) {
        ingredientRepo.restore(ingredientId, qty);
        record(ingredientId, StockMovement.RETURN, qty, unitCost, refType, refId);
    }

    public List<Ingredient> lowStock() {
        return ingredientRepo.findLowStock();
    }

    private Ingredient getIngredient(Long id) {
        return ingredientRepo.findById(id).orElseThrow(() -> ApiException.notFound("食材不存在: " + id));
    }

    private void record(Long ingredientId, String type, BigDecimal qty, BigDecimal unitCost, String refType, Long refId) {
        StockMovement m = new StockMovement();
        m.ingredientId = ingredientId;
        m.type = type;
        m.qty = qty;
        m.unitCost = unitCost;
        m.refType = refType;
        m.refId = refId;
        m.createdAt = LocalDateTime.now();
        movementRepo.save(m);
    }
}
