package com.example.restaurant.order;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DishRecipeRepository extends JpaRepository<DishRecipe, Long> {
    List<DishRecipe> findByDishId(Long dishId);

    void deleteByDishId(Long dishId);
}
