package com.example.restaurant.finance;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public final class FinanceDtos {
    private FinanceDtos() {
    }

    /** 手工记一笔支出，如房租、人工、水电 */
    public record ExpenseRequest(@NotBlank String category, @NotNull @Positive BigDecimal amount, String remark) {
    }

    public record DailyRow(LocalDate date, BigDecimal income, BigDecimal expense, BigDecimal net) {
    }

    /**
     * 经营报表
     * salesIncome  营业额（销售收入）
     * foodCost     食材成本（实际消耗的食材 = 出库 − 取消退回，按成本价计算）
     * grossProfit  毛利 = 营业额 − 食材成本
     * totalIncome / totalExpense / netCash  现金口径：收入合计、支出合计、净现金流
     */
    public record Report(LocalDate from, LocalDate to, long paidOrders,
                         BigDecimal salesIncome, BigDecimal foodCost, BigDecimal grossProfit, String grossMargin,
                         BigDecimal totalIncome, BigDecimal totalExpense, BigDecimal netCash,
                         Map<String, BigDecimal> expenseByCategory, List<DailyRow> daily) {
    }
}
