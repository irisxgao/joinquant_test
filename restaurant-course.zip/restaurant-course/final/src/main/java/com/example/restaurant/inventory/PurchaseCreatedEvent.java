package com.example.restaurant.inventory;

import java.math.BigDecimal;

/**
 * 领域事件：采购单已创建。
 * 库存模块只负责"发布"，谁关心谁来"监听"（第 4 课财务模块会监听它记一笔支出）。
 * 这样库存模块不需要依赖财务模块。
 */
public record PurchaseCreatedEvent(Long purchaseId, BigDecimal totalAmount) {
}
