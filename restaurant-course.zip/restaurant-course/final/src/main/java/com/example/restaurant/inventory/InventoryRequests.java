package com.example.restaurant.inventory;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.List;

public final class InventoryRequests {
    private InventoryRequests() {
    }

    public record IngredientRequest(@NotBlank String name,
                                    @NotBlank String unit,
                                    @NotNull @PositiveOrZero BigDecimal safetyQty) {
    }

    public record PurchaseRequest(String remark, @NotEmpty List<@Valid Item> items) {
        public record Item(@NotNull Long ingredientId,
                           @NotNull @Positive BigDecimal qty,
                           @NotNull @PositiveOrZero BigDecimal unitPrice) {
        }
    }

    public record AdjustRequest(@NotNull Long ingredientId,
                                @NotNull @PositiveOrZero BigDecimal actualQty,
                                String remark) {
    }
}
