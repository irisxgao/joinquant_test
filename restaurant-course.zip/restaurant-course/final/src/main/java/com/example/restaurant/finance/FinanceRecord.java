package com.example.restaurant.finance;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 财务流水（简化版"日记账"）。
 * type：INCOME 收入 / EXPENSE 支出；amount 永远为正数。
 * category：销售收入 / 食材采购 / 房租 / 人工 / 水电 / 其他
 */
@Entity
public class FinanceRecord {
    public static final String INCOME = "INCOME";
    public static final String EXPENSE = "EXPENSE";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public String type;

    @Column(nullable = false)
    public String category;

    @Column(nullable = false, precision = 14, scale = 2)
    public BigDecimal amount;

    /** 来源单据：ORDER / PURCHASE / MANUAL */
    public String refType;
    public Long refId;
    public String remark;

    @Column(nullable = false)
    public LocalDateTime createdAt;
}
