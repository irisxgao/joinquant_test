package com.example.restaurant.common;

/** 业务异常：携带 HTTP 状态码，由 GlobalExceptionHandler 统一转换为 JSON。 */
public class ApiException extends RuntimeException {
    private final int status;

    public ApiException(int status, String message) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public static ApiException badRequest(String msg) {
        return new ApiException(400, msg);
    }

    public static ApiException notFound(String msg) {
        return new ApiException(404, msg);
    }

    public static ApiException unauthorized(String msg) {
        return new ApiException(401, msg);
    }
}
