package com.example.restaurant.order;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单。表名用 orders，因为 order 是 SQL 关键字。
 * 状态流转：PENDING(待出餐) → SERVED(已出餐) → PAID(已结账)
 *          PENDING → CANCELLED(已取消，库存退回)
 */
@Entity
@Table(name = "orders")
public class CustomerOrder {
    public static final String PENDING = "PENDING";
    public static final String SERVED = "SERVED";
    public static final String PAID = "PAID";
    public static final String CANCELLED = "CANCELLED";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public Long tableId;

    @Column(nullable = false)
    public String status;

    @Column(nullable = false, precision = 14, scale = 2)
    public BigDecimal totalAmount;

    @Column(nullable = false)
    public LocalDateTime createdAt;

    public LocalDateTime paidAt;
}
