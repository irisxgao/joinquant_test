package com.example.restaurant.order;

import java.math.BigDecimal;

/** 领域事件：订单已结账。第 4 课财务模块监听它记一笔收入。 */
public record OrderPaidEvent(Long orderId, BigDecimal amount) {
}
