package com.example.restaurant.inventory;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** 采购单（单头） */
@Entity
public class Purchase {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false, precision = 14, scale = 2)
    public BigDecimal totalAmount = BigDecimal.ZERO;

    public String remark;

    @Column(nullable = false)
    public LocalDateTime createdAt;
}
