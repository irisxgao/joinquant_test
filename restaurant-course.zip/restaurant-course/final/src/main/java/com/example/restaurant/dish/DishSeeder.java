package com.example.restaurant.dish;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/** 启动时写入示例菜单（第 1 课）。@Order(1) 保证它最先执行。 */
@Component
@Order(1)
public class DishSeeder implements CommandLineRunner {

    private final DishCategoryRepository categoryRepo;
    private final DishRepository dishRepo;

    public DishSeeder(DishCategoryRepository categoryRepo, DishRepository dishRepo) {
        this.categoryRepo = categoryRepo;
        this.dishRepo = dishRepo;
    }

    @Override
    public void run(String... args) {
        if (categoryRepo.count() > 0) {
            return;
        }
        Long hot = category("热菜", 1);
        Long staple = category("主食", 2);
        Long soup = category("汤品", 3);
        Long drink = category("饮品", 4);

        dish(hot, "番茄炒蛋", "28");
        dish(hot, "宫保鸡丁", "42");
        dish(hot, "麻婆豆腐", "32");
        dish(hot, "青椒肉丝", "36");
        dish(staple, "扬州炒饭", "25");
        dish(staple, "白米饭", "3");
        dish(soup, "酸辣汤", "18");
        dish(drink, "酸梅汤", "12");
    }

    private Long category(String name, int sort) {
        DishCategory c = new DishCategory();
        c.name = name;
        c.sort = sort;
        return categoryRepo.save(c).id;
    }

    private void dish(Long categoryId, String name, String price) {
        Dish d = new Dish();
        d.categoryId = categoryId;
        d.name = name;
        d.price = new BigDecimal(price);
        dishRepo.save(d);
    }
}
