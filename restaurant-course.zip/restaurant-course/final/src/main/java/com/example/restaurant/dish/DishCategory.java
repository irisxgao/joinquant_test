package com.example.restaurant.dish;

import jakarta.persistence.*;

/** 菜品分类，如：热菜、主食、汤品。为了教学简洁，实体使用 public 字段。 */
@Entity
public class DishCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public String name;

    /** 排序号，越小越靠前 */
    public int sort;
}
