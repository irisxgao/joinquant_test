# 🏮 中餐厅 · 餐厅管理系统（Spring Boot 实战课程）

以综艺《中餐厅》为背景：明星们每天要**定菜单、去市场采购、接待客人点菜、出餐、结账，晚上盘点算账**。
本课程用 5 节课，从零做出一个**最小可用**的餐厅管理系统，覆盖：

| 端 | 功能 |
|---|---|
| 客人端 | 选桌、看菜单（自动显示售罄）、加购物车、下单、查看订单状态 |
| 后台·菜品 | 分类 / 菜品增删改查、上下架、**配方**（每道菜消耗哪些食材） |
| 后台·订单 | 出餐、结账、取消 |
| 后台·进销存 | 食材档案、采购入库、下单自动扣库存、取消退库存、盘点、库存流水、库存预警 |
| 后台·财务 | 自动记账（采购→支出，结账→收入）、手工记支出、营业额 / 食材成本 / 毛利 / 净现金流报表 |

---

## 📦 目录结构

```
restaurant-course/
├── README.md                     ← 本文件：完整教学内容
├── lesson01-skeleton-dish/       ← 第 1 课：项目骨架 + 菜品管理
├── lesson02-inventory/           ← 第 2 课：进销存（采购、盘点、流水、预警）
├── lesson03-order/               ← 第 3 课：配方 + 点菜下单（核心）
├── lesson04-finance/             ← 第 4 课：财务（事件驱动记账 + 报表）
├── lesson05-frontend-auth/       ← 第 5 课：前端页面 + 后台登录
└── final/                        ← 最终完整项目
    └── 直接打开看效果.html        ← 双击即可在浏览器体验全部功能（无需启动后端）
```

**每一课都是一个可以独立运行的完整 Maven 项目**，内容是在上一课基础上**只新增文件**（第 1 课的几个公共文件除外）。你可以对比相邻两课的目录，看清楚每课到底加了什么。

## 🚀 快速体验

**方式一：不装任何东西**
双击 `final/直接打开看效果.html`。页面检测到是 `file://` 打开时，会启用内置的"模拟后端"（JS 实现了相同的业务规则，数据存在浏览器 localStorage），右上角会显示"离线演示模式"。

**方式二：运行真正的 Spring Boot 后端**

```bash
cd final
mvn spring-boot:run
# 浏览器打开 http://localhost:8080
```

后台账号 `admin / admin123`。H2 数据库控制台：http://localhost:8080/h2-console（JDBC URL 填 `jdbc:h2:mem:restaurant`，用户 `sa`，密码空）。

> 也可以用 IntelliJ IDEA 直接打开任意一课的文件夹（识别为 Maven 项目），运行 `RestaurantApplication` 即可。

### 环境要求

- JDK 17+
- Maven 3.8+（或使用 IDEA 自带的 Maven）
- 不需要安装数据库：使用 H2 内存数据库，**每次重启会恢复为示例数据**

---

## 🧭 课前导读：整体设计

### 技术栈

| 层 | 选型 | 为什么 |
|---|---|---|
| 框架 | Spring Boot 3.3 / Java 17 | 业界主流，约定优于配置 |
| Web | Spring MVC（`@RestController`） | 提供 REST 接口 |
| 持久层 | Spring Data JPA + Hibernate | 写接口就能查库，自动建表 |
| 数据库 | H2 内存库 | 零安装；换 MySQL 只需改 `application.yml` 和依赖 |
| 校验 | Bean Validation（`@NotBlank`、`@Positive`…） | 参数校验声明式完成 |
| 前端 | 单个 HTML + 原生 JS | 无需 Node 构建，放进 `static/` 即被 Spring Boot 托管 |

### 分层与包结构（按业务模块分包）

```
com.example.restaurant
├── common/      统一异常、全局异常处理
├── dish/        菜品、分类              —— 第 1 课
├── inventory/   食材、采购、库存流水    —— 第 2 课
├── order/       配方、餐桌、订单、菜单  —— 第 3 课
├── finance/     财务流水、报表          —— 第 4 课
└── auth/        登录、拦截器            —— 第 5 课
```

每个模块内部：`实体(Entity)` → `仓库(Repository)` → `服务(Service，写业务规则和事务)` → `控制器(Controller，只做参数接收和返回)`。

### 核心业务链路

```mermaid
flowchart LR
    A[采购入库] -->|库存+ / 记IN流水| S[(食材库存)]
    A -->|PurchaseCreatedEvent| F[(财务流水)]
    O[客人下单] -->|按配方扣库存 / 记OUT流水| S
    O --> K[厨房出餐]
    K --> P[结账]
    P -->|OrderPaidEvent| F
    O -->|取消| C[退回库存 / 记RETURN流水] --> S
    F --> R[经营报表：营业额·食材成本·毛利·净现金流]
```

### 数据模型（11 张表）

```
dish_category (id, name, sort)
dish          (id, category_id, name, price, on_sale)
ingredient    (id, name, unit, stock_qty, avg_cost, safety_qty)
stock_movement(id, ingredient_id, type, qty, unit_cost, ref_type, ref_id, created_at)
purchase      (id, total_amount, remark, created_at)
purchase_item (id, purchase_id, ingredient_id, qty, unit_price)
dish_recipe   (id, dish_id, ingredient_id, qty)           ← 菜品与库存的桥梁
dining_table  (id, code)
orders        (id, table_id, status, total_amount, created_at, paid_at)
order_item    (id, order_id, dish_id, dish_name, qty, unit_price)
finance_record(id, type, category, amount, ref_type, ref_id, remark, created_at)
```

**三条贯穿全课的设计原则**

1. **金额和数量一律用 `BigDecimal`**，不用 `double`（`0.1 + 0.2 != 0.3`）。
2. **流水只增不改**：库存有 `stock_movement`，资金有 `finance_record`。当前值（`stock_qty`）是冗余，流水才是"真相"，出了问题可以对账追溯。
3. **快照**：订单明细保存下单时的菜名和单价；出库流水保存当时的成本价。之后改价不影响历史数据。

> 💡 为了让初学者把注意力放在业务上，实体类使用 `public` 字段、不引入 Lombok，实体之间只存外键 ID、不用 `@ManyToOne`（避免懒加载异常和 JSON 循环引用）。正式项目中可以改为 private + getter/setter（或 Lombok）。

---

## 第 1 课：项目骨架 + 菜品管理

📁 `lesson01-skeleton-dish/`

### 🎯 本课目标

- 搭起一个能跑的 Spring Boot 项目
- 学会 **Entity → Repository → Controller** 三件套
- 完成分类和菜品的增删改查、上下架
- 建立统一的错误返回格式

### 📚 知识点

`@SpringBootApplication`、`application.yml`、JPA `@Entity` / `@Id` / `@GeneratedValue`、`JpaRepository`、方法名派生查询、`@RestController` / `@GetMapping` / `@PathVariable` / `@RequestBody`、`record` DTO、`@Valid` 参数校验、`@RestControllerAdvice` 全局异常、`CommandLineRunner` 初始化数据。

### 🛠 步骤

**Step 1 — `pom.xml`**

继承 `spring-boot-starter-parent`，引入四个 starter：`web`（REST）、`data-jpa`（ORM）、`validation`（校验）、`h2`（数据库），以及测试用的 `starter-test`。parent 帮我们统一管理了所有依赖的版本号，所以依赖里都不用写 `<version>`。

**Step 2 — `application.yml`**

```yaml
spring:
  datasource:
    url: jdbc:h2:mem:restaurant;DB_CLOSE_DELAY=-1
  jpa:
    hibernate:
      ddl-auto: update     # 根据实体自动建表/加列
    open-in-view: false    # 关闭 OSIV，强迫我们在 Service 中把数据准备好
```

**Step 3 — 启动类 `RestaurantApplication`**

`@SpringBootApplication` = 配置类 + 自动配置 + 组件扫描（扫描当前包及子包），所以所有代码都要放在 `com.example.restaurant` 下。

**Step 4 — 实体 `DishCategory`、`Dish`**

```java
@Entity
public class Dish {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @Column(nullable = false) public Long categoryId;   // 只存外键 ID
    @Column(nullable = false) public String name;
    @Column(nullable = false) public BigDecimal price;  // 金额用 BigDecimal
    public boolean onSale = true;
}
```

Hibernate 会把驼峰字段名映射为下划线列名（`categoryId` → `category_id`）。

**Step 5 — Repository**

```java
public interface DishRepository extends JpaRepository<Dish, Long> {
    boolean existsByCategoryId(Long categoryId);   // 自动生成 SQL
    List<Dish> findByOnSaleTrue();
    Optional<Dish> findByName(String name);
}
```

只写接口不写实现：Spring Data 会**根据方法名**生成查询。`JpaRepository` 自带 `save / findById / findAll / deleteById / count` 等方法。

**Step 6 — 请求 DTO `DishRequests`**

```java
public record DishRequest(@NotNull Long categoryId,
                          @NotBlank String name,
                          @NotNull @Positive BigDecimal price,
                          Boolean onSale) {}
```

为什么不直接用实体接收参数？客户端可能偷偷传 `id` 覆盖别的数据；而且实体字段和接口字段往往不一样。**入参用 DTO，是一个好习惯。**

**Step 7 — 统一异常 `ApiException` + `GlobalExceptionHandler`**

业务代码里只需 `throw ApiException.badRequest("该分类下还有菜品，不能删除")`，`@RestControllerAdvice` 会把它统一转成：

```json
HTTP 400
{"error": "该分类下还有菜品，不能删除"}
```

`@Valid` 校验失败抛出的 `MethodArgumentNotValidException` 也在这里转成 400。前端只要读 `error` 字段即可。

**Step 8 — `DishAdminController`**

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/admin/categories` | 分类列表（按 sort 排序） |
| POST / PUT / DELETE | `/api/admin/categories[/{id}]` | 新增 / 修改 / 删除（有菜品时禁止删除） |
| GET | `/api/admin/dishes` | 菜品列表 |
| POST / PUT / DELETE | `/api/admin/dishes[/{id}]` | 新增 / 修改 / 删除 |
| PATCH | `/api/admin/dishes/{id}/on-sale?value=false` | 上架 / 下架 |

> 为什么上下架用 `PATCH`？它只修改资源的一部分字段，语义比 `PUT`（整体替换）更准确。

**Step 9 — 示例数据 `DishSeeder`**

实现 `CommandLineRunner`，应用启动完成后执行。用 `@Order(1)` 指定顺序（后面几课还会有 Seeder）。先判断 `count() > 0`，避免重复插入。

### ▶️ 运行与验证

```bash
cd lesson01-skeleton-dish && mvn spring-boot:run
```

```bash
curl http://localhost:8080/api/admin/categories
curl http://localhost:8080/api/admin/dishes

# 新增菜品
curl -X POST http://localhost:8080/api/admin/dishes -H "Content-Type: application/json" \
     -d '{"categoryId":1,"name":"红烧肉","price":48}'

# 校验失败 → 400 {"error":"price ..."}（提示语随 JVM 语言环境变化）
curl -X POST http://localhost:8080/api/admin/dishes -H "Content-Type: application/json" \
     -d '{"categoryId":1,"name":"红烧肉","price":-1}'

# 下架
curl -X PATCH "http://localhost:8080/api/admin/dishes/1/on-sale?value=false"
```

打开 http://localhost:8080/h2-console 看看自动建好的表。

### ✍️ 练习

1. 给 `Dish` 加一个 `description`（描述）字段，体会 `ddl-auto: update` 自动加列。
2. 新增接口 `GET /api/admin/dishes?categoryId=1`，只返回某个分类的菜品（提示：在 Repository 写 `findByCategoryId`）。
3. 思考：已经有订单的菜品被删除会怎样？（第 3 课的订单明细保存了菜名快照，所以历史订单仍能正常显示，但更推荐"下架"。）

---

## 第 2 课：进销存（采购入库 · 盘点 · 流水 · 预警）

📁 `lesson02-inventory/`（新增 `inventory` 包）

### 🎯 本课目标

- 理解"**当前库存 + 库存流水**"的经典设计
- 实现采购入库并用**加权平均法**计算成本
- 学会 `@Transactional` 事务
- 写出**防超卖**的原子扣减 SQL（下一课下单时使用）
- 学会用**领域事件**解耦模块

### 📚 知识点

`@Transactional`、JPQL `@Query`、`@Modifying`、条件更新实现乐观并发控制、加权平均成本、`ApplicationEventPublisher`、嵌套 record 校验 `List<@Valid Item>`。

### 🛠 步骤

**Step 1 — 实体**

- `Ingredient` 食材：`stockQty` 当前库存、`avgCost` 平均成本、`safetyQty` 安全库存
- `StockMovement` 库存流水：`type` 取值 `IN / OUT / RETURN / ADJUST`，`refType + refId` 记录来源单据，`unitCost` 记录当时的成本快照
- `Purchase` + `PurchaseItem`：采购单头 + 明细（经典"主从表"）

数量字段指定了 `precision = 14, scale = 3`，可以表示 0.05 kg 这样的用量。

**Step 2 — 原子扣减（本课最重要的一段代码）**

```java
@Modifying(flushAutomatically = true, clearAutomatically = true)
@Query("update Ingredient i set i.stockQty = i.stockQty - :qty " +
       "where i.id = :id and i.stockQty >= :qty")
int deduct(@Param("id") Long id, @Param("qty") BigDecimal qty);
```

❌ 错误写法：先查出库存 → Java 中判断够不够 → 再保存。两个客人同时点最后一份宫保鸡丁时，两个线程都会读到"还剩 1 份"，结果超卖。

✅ 正确写法：把"判断"和"扣减"放进**一条 SQL**，由数据库保证原子性。返回值是影响行数：`1` 表示扣减成功，`0` 表示库存不足。

- `flushAutomatically`：执行前先把当前事务中未写入的修改刷到数据库
- `clearAutomatically`：执行后清空一级缓存，防止后续读到旧的实体

**Step 3 — `InventoryService`**

所有修改库存的操作**必须**经过这个 Service，保证"改库存"和"写流水"总是同时发生。

```java
@Transactional
public Purchase purchase(PurchaseRequest req) {
    ...
    // 加权平均成本 = (原库存 × 原成本 + 本次金额) / (原库存 + 本次数量)
    ing.avgCost = oldQty.multiply(ing.avgCost).add(amount)
                        .divide(newQty, 2, RoundingMode.HALF_UP);
    ...
    record(ing.id, StockMovement.IN, item.qty(), item.unitPrice(), "PURCHASE", p.id);
    ...
    publisher.publishEvent(new PurchaseCreatedEvent(p.id, p.totalAmount));
}
```

举例：库存 10 kg 番茄，成本 8 元；再买 10 kg，单价 10 元 → 新成本 = (80 + 100) / 20 = **9 元/kg**。

> `BigDecimal.divide` 一定要指定精度和舍入方式，否则遇到除不尽时会抛 `ArithmeticException`。

`@Transactional` 的作用：方法里的多次数据库写入要么全部成功，要么全部回滚。比如采购单有 3 行，第 3 行食材不存在 → 前 2 行的库存修改也会撤销。

| 方法 | 做什么 | 流水类型 |
|---|---|---|
| `purchase` | 采购入库，重算成本，发布事件 | IN |
| `adjust` | 盘点：库存改为实际数，差额入流水（可负） | ADJUST |
| `deduct` | 消耗出库（下一课下单时调用） | OUT |
| `restore` | 退回库存（下一课取消订单时调用） | RETURN |

**Step 4 — 领域事件 `PurchaseCreatedEvent`**

```java
public record PurchaseCreatedEvent(Long purchaseId, BigDecimal totalAmount) {}
```

采购会产生一笔支出，但库存模块**不应该直接调用财务模块**（否则两个模块会互相依赖）。我们只"广播"一个事件。本课没有人监听它，什么都不会发生；第 4 课的财务模块会监听它并自动记账。

**Step 5 — `InventoryController`**

| 方法 | 路径 | 说明 |
|---|---|---|
| GET / POST / PUT | `/api/admin/ingredients[/{id}]` | 食材档案（新建时库存为 0） |
| POST | `/api/admin/purchases` | 采购入库 |
| GET | `/api/admin/purchases[/{id}]` | 采购单列表 / 明细 |
| POST | `/api/admin/stock/adjust` | 盘点调整 |
| GET | `/api/admin/stock/alerts` | 低于安全库存的食材 |
| GET | `/api/admin/stock/movements[?ingredientId=]` | 库存流水 |

**Step 6 — `InventorySeeder`（`@Order(2)`）**

先建 9 种食材（库存 0），再通过 `inventoryService.purchase(...)` 做一次"开业首批采购"。**库存是通过业务操作产生的，而不是直接写数字**，所以从一开始就有完整的流水。

### ▶️ 运行与验证

```bash
curl http://localhost:8080/api/admin/ingredients        # 鸡蛋库存 100，成本 1.20

# 再买 50 个鸡蛋，单价 1.5 → 新平均成本 (100×1.2 + 50×1.5)/150 = 1.30
curl -X POST http://localhost:8080/api/admin/purchases -H "Content-Type: application/json" \
     -d '{"remark":"早市","items":[{"ingredientId":1,"qty":50,"unitPrice":1.5}]}'

# 盘点：实际只有 140 个（打碎了 10 个）
curl -X POST http://localhost:8080/api/admin/stock/adjust -H "Content-Type: application/json" \
     -d '{"ingredientId":1,"actualQty":140}'

curl "http://localhost:8080/api/admin/stock/movements?ingredientId=1"   # IN, IN, ADJUST(-10)

# 把番茄盘点到 1kg（安全库存 3kg），触发预警
curl -X POST http://localhost:8080/api/admin/stock/adjust -H "Content-Type: application/json" \
     -d '{"ingredientId":2,"actualQty":1}'
curl http://localhost:8080/api/admin/stock/alerts
```

### ✍️ 练习

1. 采购明细里传一个不存在的 `ingredientId`，确认整张采购单都没有入库（事务回滚）。
2. 思考：如果去掉 `deduct` SQL 中的 `and i.stockQty >= :qty`，会出现什么问题？
3. 进阶：增加"报损出库"（食材坏掉了），新增流水类型 `LOSS`。

---

## 第 3 课：配方 + 点菜下单（核心流程）

📁 `lesson03-order/`（新增 `order` 包和单元测试）

### 🎯 本课目标

- 用"**配方**"把菜品和库存连接起来
- 实现下单 → 出餐 → 结账 / 取消的**状态机**
- 下单时在一个事务内按配方**扣库存**，库存不足则**整单回滚**
- 客人菜单自动显示"**售罄**"
- 写第一组**集成测试**

### 📚 知识点

状态机、事务回滚、价格快照、`Map.merge` 汇总、Stream 分组、`@Validated` 校验集合参数、`@SpringBootTest` + `@Transactional` 测试自动回滚。

### 🛠 步骤

**Step 1 — 配方 `DishRecipe`**

| 菜品 | 食材 | 每份用量 |
|---|---|---|
| 番茄炒蛋 | 鸡蛋 | 3 个 |
| 番茄炒蛋 | 番茄 | 0.3 kg |
| 宫保鸡丁 | 鸡胸肉 | 0.3 kg |
| … | … | … |

点 2 份番茄炒蛋 → 扣 6 个鸡蛋 + 0.6 kg 番茄。

**Step 2 — 订单实体**

- `DiningTable` 餐桌（A1~A6）
- `CustomerOrder`：`@Table(name = "orders")`，因为 `order` 是 SQL 关键字，直接用会报语法错误
- `OrderItem`：保存 `dishName`、`unitPrice` **快照**，菜品以后改价不影响历史订单

**Step 3 — 订单状态机**

```
            serve            pay
PENDING ───────────▶ SERVED ─────────▶ PAID
   │
   │ cancel（退回库存）
   ▼
CANCELLED
```

每个动作先检查当前状态（`requireStatus`），不合法就抛 400。例如不能对"待出餐"的订单结账，也不能取消"已出餐"的订单（菜已经做了，食材无法退回）。

**Step 4 — `OrderService.placeOrder`（本课核心）**

```java
@Transactional
public OrderView placeOrder(PlaceOrderRequest req) {
    // 1. 校验餐桌、菜品存在且在售
    // 2. 计算金额，生成订单明细（价格快照）
    // 3. 汇总所需食材：同一食材可能被多道菜使用
    need.merge(r.ingredientId, r.qty.multiply(qty), BigDecimal::add);
    // 4. 保存订单和明细
    // 5. 最后扣库存：任何一种不够 → 抛异常 → 整个事务回滚（订单也不会保存）
    need.forEach((id, qty) -> inventoryService.deduct(id, qty, "ORDER", order.id));
}
```

为什么先汇总再扣？客人同时点了"番茄炒蛋（3 个蛋）"和"扬州炒饭（1 个蛋）"，合并为扣 4 个蛋，流水更清晰，数据库更新次数也更少。

为什么扣库存放在最后？它最可能失败。失败时抛出的 `RuntimeException` 会让 Spring 回滚整个事务，前面保存的订单也一并撤销，不会留下"有订单却没扣库存"的脏数据。

**Step 5 — 取消订单退库存**

```java
for (StockMovement m : movementRepo.findByRefTypeAndRefIdAndType("ORDER", id, "OUT")) {
    inventoryService.restore(m.ingredientId, m.qty, m.unitCost, "ORDER", id);
}
```

不重新按配方计算，而是**按当初的出库流水原样退回**。即使配方后来改了，退回的数量仍然准确。这就是记录流水的价值。

**Step 6 — 结账发布事件**

`pay()` 发布 `OrderPaidEvent(orderId, amount)`。和第 2 课一样，本课暂时没有人监听。

**Step 7 — `MenuController`：客人菜单 + 配方设置**

售罄判断：只要配方里**任意一种**食材不够做**一份**，就标记 `soldOut = true`。

```java
recipes.getOrDefault(d.id, List.of()).stream()
       .anyMatch(r -> stock.getOrDefault(r.ingredientId, ZERO).compareTo(r.qty) < 0)
```

> 比较 `BigDecimal` 要用 `compareTo`，不能用 `equals`（`equals` 会比较精度，`2.0` 不等于 `2.00`）。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/tables` | 餐桌列表 |
| GET | `/api/menu` | 客人菜单（只含上架菜品，带售罄标记） |
| POST | `/api/orders` | 客人下单 |
| GET | `/api/orders/{id}` | 查看订单 |
| GET | `/api/admin/orders[?status=]` | 后台订单列表 |
| POST | `/api/admin/orders/{id}/serve\|pay\|cancel` | 出餐 / 结账 / 取消 |
| GET / PUT | `/api/admin/dishes/{id}/recipe` | 查看 / 整体替换配方 |

**Step 8 — 集成测试 `OrderServiceTest`**

```java
@SpringBootTest     // 启动完整的 Spring 容器（含 Seeder 示例数据）
@Transactional      // 每个测试方法结束后自动回滚，互不干扰
class OrderServiceTest {
    @Test void placeOrderDeductsStockByRecipe()   // 2 份番茄炒蛋 = ¥56，鸡蛋 -6
    @Test void insufficientStockRejectsWholeOrder()// 点 99 份 → 抛异常，库存不变
    @Test void cancelRestoresStock()               // 下单再取消 → 库存复原
    @Test void cannotPayBeforeServe()              // 未出餐不能结账
}
```

```bash
mvn test
```

### ▶️ 运行与验证

```bash
curl http://localhost:8080/api/menu

# A1 桌点 2 份番茄炒蛋（dishId=1）+ 1 份宫保鸡丁（dishId=2）
curl -X POST http://localhost:8080/api/orders -H "Content-Type: application/json" \
     -d '{"tableId":1,"items":[{"dishId":1,"qty":2},{"dishId":2,"qty":1}]}'
# → totalAmount = 98

curl http://localhost:8080/api/admin/stock/movements      # 看到 OUT 流水

curl -X POST http://localhost:8080/api/admin/orders/1/serve
curl -X POST http://localhost:8080/api/admin/orders/1/pay

# 库存不足：点 50 份番茄炒蛋 → 400 食材【鸡蛋】库存不足…
curl -X POST http://localhost:8080/api/orders -H "Content-Type: application/json" \
     -d '{"tableId":1,"items":[{"dishId":1,"qty":50}]}'
```

**观察售罄**：把豆腐盘点为 0，再查菜单，麻婆豆腐和酸辣汤都会变成 `soldOut: true`。

### ✍️ 练习

1. 增加"加菜"：向 PENDING 状态的订单追加菜品（同样要扣库存）。
2. 增加"桌台状态"：有未结账订单的桌子显示为"用餐中"。
3. 思考：下单扣库存和出餐时扣库存，各有什么优缺点？（本课选择下单时扣，可以立刻显示售罄。）

---

## 第 4 课：财务管理（事件驱动记账 + 经营报表）

📁 `lesson04-finance/`（新增 `finance` 包，**没有修改任何已有文件**）

### 🎯 本课目标

- 用 `@EventListener` 监听前两课发布的事件，**自动记账**
- 支持手工记支出（房租、人工、水电）
- 输出经营报表：**营业额、食材成本、毛利、毛利率、净现金流、每日汇总**

### 📚 知识点

观察者模式 / 领域事件、`@EventListener` 与 `@TransactionalEventListener` 的区别、`@DateTimeFormat`、`LocalDate` 时间区间、两种财务口径（毛利 vs 现金流）。

### 🛠 步骤

**Step 1 — `FinanceRecord` 财务流水**

`type` = `INCOME / EXPENSE`，`amount` 始终为正数，`category` 为科目（销售收入、食材采购、房租、人工…），`refType + refId` 关联来源单据。

**Step 2 — `FinanceEventListener`：自动记账**

```java
@EventListener
public void onOrderPaid(OrderPaidEvent e) {
    financeService.record(INCOME, "销售收入", e.amount(), "ORDER", e.orderId(), ...);
}

@EventListener
public void onPurchase(PurchaseCreatedEvent e) {
    financeService.record(EXPENSE, "食材采购", e.totalAmount(), "PURCHASE", e.purchaseId(), ...);
}
```

🌟 **这一课的亮点**：我们没有改动 `OrderService` 或 `InventoryService` 中的任何一行代码，只是新增了一个监听器，财务功能就"插"进来了。这就是**开闭原则**（对扩展开放，对修改关闭）。

**`@EventListener` 还是 `@TransactionalEventListener`？**

| | `@EventListener`（本课选用） | `@TransactionalEventListener(AFTER_COMMIT)` |
|---|---|---|
| 执行时机 | 发布时立即同步执行 | 发布方事务提交成功后 |
| 事务 | 与结账/采购**同一个事务** | 不在原事务中 |
| 记账失败时 | 结账也会回滚 → 账实一致 | 结账成功但没记账 → 需要补偿 |
| 适用场景 | 必须强一致的操作（记账） | 发短信、推送等"失败也无所谓"的通知 |

**Step 3 — `FinanceService.report`：经营报表**

| 指标 | 计算方法 | 含义 |
|---|---|---|
| 营业额 | 来源为 ORDER 的收入之和 | 卖了多少钱 |
| 食材成本 | Σ(OUT 流水数量 × 成本价) − Σ(RETURN 流水数量 × 成本价) | 实际**吃掉**的食材值多少钱 |
| 毛利 / 毛利率 | 营业额 − 食材成本；毛利 ÷ 营业额 | 菜品本身赚不赚钱 |
| 总支出 | 所有 EXPENSE 之和，并按科目分组 | 花出去多少钱 |
| 净现金流 | 总收入 − 总支出 | 口袋里的钱是多了还是少了 |

⚠️ **两种口径要分清**：开业第一天采购了 1103 元食材，只卖了 98 元，"净现金流"是 −1005 元，但"毛利"是正的，因为大部分食材还在仓库里。这正是节目里常见的困惑："今天亏了吗？" —— 现金流是负的，但生意本身是赚钱的。

**Step 4 — `FinanceController`**

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/admin/finance/records?from=&to=` | 财务流水（默认今天） |
| POST | `/api/admin/finance/expenses` | 手工记支出 |
| GET | `/api/admin/finance/report?from=2026-10-01&to=2026-10-31` | 经营报表（月报） |

### ▶️ 运行与验证

```bash
# 启动后已有"开业首批采购"的支出记录（Seeder 调用了 purchase，事件被监听）
curl http://localhost:8080/api/admin/finance/records

# 走一遍下单 → 出餐 → 结账
curl -X POST http://localhost:8080/api/orders -H "Content-Type: application/json" \
     -d '{"tableId":1,"items":[{"dishId":1,"qty":2},{"dishId":2,"qty":1}]}'
curl -X POST http://localhost:8080/api/admin/orders/1/serve
curl -X POST http://localhost:8080/api/admin/orders/1/pay

# 记一笔房租
curl -X POST http://localhost:8080/api/admin/finance/expenses -H "Content-Type: application/json" \
     -d '{"category":"房租","amount":500,"remark":"日租"}'

curl http://localhost:8080/api/admin/finance/report
# salesIncome 98, foodCost 20.70, grossProfit 77.30, grossMargin 78.9% ...
```

食材成本 20.70 的计算过程：鸡蛋 6 × 1.2 + 番茄 0.6 × 8 + 鸡胸肉 0.3 × 26 + 花生 0.05 × 18 = 7.2 + 4.8 + 7.8 + 0.9 = **20.70**。

### ✍️ 练习

1. 把 `onOrderPaid` 改成 `@TransactionalEventListener`，并在监听器里故意抛一个异常，对比两种方式下订单状态和账目的结果。
2. 增加"菜品销量排行"报表（提示：统计 PAID 订单的 `order_item`）。
3. 增加"退款"：已结账订单退款时记一笔负向收入，或者新增 `REFUND` 类型。

---

## 第 5 课：前端页面 + 后台登录

📁 `lesson05-frontend-auth/`（新增 `auth` 包和 `static/index.html`）

### 🎯 本课目标

- 写一个单文件前端：客人点菜页 + 后台四个管理页
- 用**拦截器**保护所有 `/api/admin/**` 接口
- 理解前后端分离的接口调用方式

### 📚 知识点

Spring Boot 静态资源托管、`HandlerInterceptor`、`WebMvcConfigurer`、Token 认证、`@Value` 读取配置、`fetch` API、`sessionStorage` / `localStorage`。

### 🛠 步骤

**Step 1 — 静态页面**

放在 `src/main/resources/static/index.html` 中的文件，Spring Boot 会直接对外提供，访问 http://localhost:8080 即可打开。不需要 Node、Vue 或任何构建工具。

页面结构：

| 区域 | 功能 |
|---|---|
| 客人点菜 | 选桌（支持 `?table=1` 参数，方便做二维码）、菜单卡片、加减数量、购物车、下单、我的订单 |
| 后台·订单 | 按状态筛选，出餐 / 结账 / 取消，每 5 秒自动刷新（模拟厨房屏） |
| 后台·菜品 | 新增、上下架、配方编辑器 |
| 后台·进销存 | 库存表（低库存标红）、预警横幅、采购入库（多行）、盘点、新建食材、流水 |
| 后台·财务 | 日期区间、5 个指标卡、记支出、每日汇总、财务流水 |

**Step 2 — 统一的 `api()` 函数**

```js
async function api(method, path, body) {
  const resp = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Token': token || '' },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error);   // 对应第 1 课的统一错误格式
  return data;
}
```

第 1 课设计的 `{"error": "..."}` 在这里发挥作用：前端只需一行代码就能提示所有错误。

**Step 3 — 登录 `AuthController` + `TokenStore`**

- `POST /api/admin/login` 校验 `application.yml` 中 `app.admin.username/password`，成功后返回随机 UUID token
- token 存在内存中的 `Set` 里（重启即失效）

**Step 4 — 拦截器 `AuthInterceptor` + `WebConfig`**

```java
registry.addInterceptor(authInterceptor)
        .addPathPatterns("/api/admin/**")       // 保护后台接口
        .excludePathPatterns("/api/admin/login"); // 登录接口本身放行
```

拦截器在 Controller 执行**之前**检查请求头 `X-Token`，无效则直接返回 401。客人端接口 `/api/menu`、`/api/orders` 不受影响。

**Step 5 — 离线演示模式（拓展阅读）**

`index.html` 末尾附带一个用 JS 写的"模拟后端"，实现了和 Java 版本相同的业务规则。当页面以 `file://` 方式打开（或 URL 带 `?mock`）时自动启用，这就是 `final/直接打开看效果.html` 不需要启动后端就能运行的原因。对照阅读 JS 版和 Java 版的 `placeOrder`，可以加深对业务规则的理解。

### ▶️ 运行与验证

```bash
mvn spring-boot:run
# 浏览器打开 http://localhost:8080
```

```bash
# 未登录访问后台 → 401
curl -i http://localhost:8080/api/admin/orders

# 登录拿 token
curl -X POST http://localhost:8080/api/admin/login -H "Content-Type: application/json" \
     -d '{"username":"admin","password":"admin123"}'
# → {"token":"xxxx-..."}

curl http://localhost:8080/api/admin/orders -H "X-Token: xxxx-..."
```

**完整演练《中餐厅》的一天：**

1. 后台 → 进销存：看到开业首批采购的库存
2. 客人点菜：A1 桌点番茄炒蛋 ×2、宫保鸡丁 ×1，下单
3. 后台 → 订单：出餐 → 结账
4. 再用 A2 桌疯狂点番茄炒蛋，直到菜单显示"已售罄"
5. 后台 → 进销存：出现鸡蛋库存预警 → 采购 60 个鸡蛋 → 菜单恢复
6. 后台 → 财务：记一笔房租 500，查看今天的营业额、毛利和净现金流

### ✍️ 练习

1. 把 token 改为 JWT（引入 `jjwt` 依赖），实现重启后仍然有效。
2. 增加"厨师"角色：只能看订单和出餐，不能看财务。
3. 用 Vue 3 重写前端，后端接口无需改动。

---

## 🏁 Final：完整项目

📁 `final/` = 第 5 课的完整代码 + `直接打开看效果.html`。

### 完整接口清单

| 模块 | 方法 | 路径 | 鉴权 |
|---|---|---|---|
| 客人 | GET | `/api/tables` | 否 |
| 客人 | GET | `/api/menu` | 否 |
| 客人 | POST | `/api/orders` | 否 |
| 客人 | GET | `/api/orders/{id}` | 否 |
| 登录 | POST | `/api/admin/login`、`/api/admin/logout` | 否 / 是 |
| 菜品 | GET/POST/PUT/DELETE | `/api/admin/categories[/{id}]` | 是 |
| 菜品 | GET/POST/PUT/DELETE | `/api/admin/dishes[/{id}]` | 是 |
| 菜品 | PATCH | `/api/admin/dishes/{id}/on-sale?value=` | 是 |
| 配方 | GET/PUT | `/api/admin/dishes/{id}/recipe` | 是 |
| 订单 | GET | `/api/admin/orders[?status=]` | 是 |
| 订单 | POST | `/api/admin/orders/{id}/serve\|pay\|cancel` | 是 |
| 库存 | GET/POST/PUT | `/api/admin/ingredients[/{id}]` | 是 |
| 库存 | GET/POST | `/api/admin/purchases[/{id}]` | 是 |
| 库存 | POST | `/api/admin/stock/adjust` | 是 |
| 库存 | GET | `/api/admin/stock/alerts`、`/api/admin/stock/movements` | 是 |
| 财务 | GET | `/api/admin/finance/records`、`/api/admin/finance/report` | 是 |
| 财务 | POST | `/api/admin/finance/expenses` | 是 |

### 从"最小实现"走向生产，还差什么

| 方向 | 建议 |
|---|---|
| 数据库 | 换 MySQL，`ddl-auto` 改为 `validate`，用 Flyway 管理表结构 |
| 认证 | JWT + Spring Security，区分老板 / 厨师 / 服务员角色 |
| 支付 | 对接微信 / 支付宝，结账改为支付回调触发 |
| 库存 | 供应商、批次与保质期、多仓库 |
| 财务 | 会计科目、凭证、发票 |
| 工程 | 分页、接口文档（springdoc-openapi）、Docker 部署、更多测试 |
