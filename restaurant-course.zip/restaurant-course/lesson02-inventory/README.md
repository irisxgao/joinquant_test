# 第 2 课：进销存

运行：`mvn spring-boot:run`（本课只有接口，用 curl / Postman 测试）

## 本课新增的文件

- `src/main/java/com/example/restaurant/inventory/Ingredient.java`
- `src/main/java/com/example/restaurant/inventory/IngredientRepository.java`
- `src/main/java/com/example/restaurant/inventory/InventoryController.java`
- `src/main/java/com/example/restaurant/inventory/InventoryRequests.java`
- `src/main/java/com/example/restaurant/inventory/InventorySeeder.java`
- `src/main/java/com/example/restaurant/inventory/InventoryService.java`
- `src/main/java/com/example/restaurant/inventory/Purchase.java`
- `src/main/java/com/example/restaurant/inventory/PurchaseCreatedEvent.java`
- `src/main/java/com/example/restaurant/inventory/PurchaseItem.java`
- `src/main/java/com/example/restaurant/inventory/PurchaseItemRepository.java`
- `src/main/java/com/example/restaurant/inventory/PurchaseRepository.java`
- `src/main/java/com/example/restaurant/inventory/StockMovement.java`
- `src/main/java/com/example/restaurant/inventory/StockMovementRepository.java`

详细教学内容见上级目录 `README.md` 的「第 2 课：进销存」一节。
