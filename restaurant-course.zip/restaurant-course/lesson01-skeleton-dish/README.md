# 第 1 课：项目骨架 + 菜品管理

运行：`mvn spring-boot:run`（本课只有接口，用 curl / Postman 测试）

## 本课新增的文件

- `pom.xml`
- `src/main/java/com/example/restaurant/RestaurantApplication.java`
- `src/main/java/com/example/restaurant/common/ApiException.java`
- `src/main/java/com/example/restaurant/common/GlobalExceptionHandler.java`
- `src/main/java/com/example/restaurant/dish/Dish.java`
- `src/main/java/com/example/restaurant/dish/DishAdminController.java`
- `src/main/java/com/example/restaurant/dish/DishCategory.java`
- `src/main/java/com/example/restaurant/dish/DishCategoryRepository.java`
- `src/main/java/com/example/restaurant/dish/DishRepository.java`
- `src/main/java/com/example/restaurant/dish/DishRequests.java`
- `src/main/java/com/example/restaurant/dish/DishSeeder.java`
- `src/main/resources/application.yml`

详细教学内容见上级目录 `README.md` 的「第 1 课：项目骨架 + 菜品管理」一节。
