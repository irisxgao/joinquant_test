# 第 4 课：财务管理

运行：`mvn spring-boot:run`（本课只有接口，用 curl / Postman 测试）

## 本课新增的文件

- `src/main/java/com/example/restaurant/finance/FinanceController.java`
- `src/main/java/com/example/restaurant/finance/FinanceDtos.java`
- `src/main/java/com/example/restaurant/finance/FinanceEventListener.java`
- `src/main/java/com/example/restaurant/finance/FinanceRecord.java`
- `src/main/java/com/example/restaurant/finance/FinanceRecordRepository.java`
- `src/main/java/com/example/restaurant/finance/FinanceService.java`

详细教学内容见上级目录 `README.md` 的「第 4 课：财务管理」一节。
