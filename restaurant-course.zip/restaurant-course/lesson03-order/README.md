# 第 3 课：配方 + 点菜下单

运行：`mvn spring-boot:run`（本课只有接口，用 curl / Postman 测试）

## 本课新增的文件

- `src/main/java/com/example/restaurant/order/CustomerOrder.java`
- `src/main/java/com/example/restaurant/order/CustomerOrderRepository.java`
- `src/main/java/com/example/restaurant/order/DiningTable.java`
- `src/main/java/com/example/restaurant/order/DiningTableRepository.java`
- `src/main/java/com/example/restaurant/order/DishRecipe.java`
- `src/main/java/com/example/restaurant/order/DishRecipeRepository.java`
- `src/main/java/com/example/restaurant/order/MenuController.java`
- `src/main/java/com/example/restaurant/order/OrderController.java`
- `src/main/java/com/example/restaurant/order/OrderDtos.java`
- `src/main/java/com/example/restaurant/order/OrderItem.java`
- `src/main/java/com/example/restaurant/order/OrderItemRepository.java`
- `src/main/java/com/example/restaurant/order/OrderPaidEvent.java`
- `src/main/java/com/example/restaurant/order/OrderSeeder.java`
- `src/main/java/com/example/restaurant/order/OrderService.java`
- `src/test/java/com/example/restaurant/order/OrderServiceTest.java`

详细教学内容见上级目录 `README.md` 的「第 3 课：配方 + 点菜下单」一节。
