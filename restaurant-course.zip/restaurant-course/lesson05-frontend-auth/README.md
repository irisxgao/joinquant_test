# 第 5 课：前端页面 + 后台登录

运行：`mvn spring-boot:run`，然后打开 http://localhost:8080

## 本课新增的文件

- `src/main/java/com/example/restaurant/auth/AuthController.java`
- `src/main/java/com/example/restaurant/auth/AuthInterceptor.java`
- `src/main/java/com/example/restaurant/auth/TokenStore.java`
- `src/main/java/com/example/restaurant/auth/WebConfig.java`
- `src/main/resources/static/index.html`

详细教学内容见上级目录 `README.md` 的「第 5 课：前端页面 + 后台登录」一节。
