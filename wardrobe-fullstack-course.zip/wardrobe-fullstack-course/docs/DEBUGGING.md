# 调试指南

## 后端

观察启动终端中的请求状态码和 Python 异常。先定位失败路由，再检查参数、SQL 和模板上下文。

## 浏览器

- Network：查看请求方法、URL、状态码、表单数据和响应。
- Console：查看 JavaScript 错误。
- Elements：确认 `data-*` 属性和 CSS 类是否存在。

## SQLite

可以使用 SQLite 命令行或图形工具查看表。不要在服务运行时随意删除数据库文件。
