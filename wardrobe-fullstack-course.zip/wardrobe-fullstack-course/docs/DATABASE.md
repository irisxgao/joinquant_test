# 数据模型

```text
families 1 ── n members
members 1 ── n clothes
members 1 ── n outfits
outfits 1 ── n outfit_items n ── 1 clothes
outfits 1 ── n wear_records
```

`Member` 是现实中的成员档案，不等同于未来的登录账号。
