// 通用前端交互：本课程从第 4 课开始逐步讲解这些代码。
document.addEventListener("DOMContentLoaded", () => {
  const imageInput = document.querySelector("[data-image-input]");
  const imagePreview = document.querySelector("[data-image-preview]");
  const fileInfo = document.querySelector("[data-file-info]");
  if (imageInput && imagePreview) {
    imageInput.addEventListener("change", () => {
      const file = imageInput.files[0];
      if (!file) return;
      if (!file.type.startsWith("image/")) {
        fileInfo.textContent = "请选择图片文件";
        imageInput.value = "";
        return;
      }
      imagePreview.src = URL.createObjectURL(file);
      imagePreview.hidden = false;
      fileInfo.textContent = `${file.name} · ${(file.size / 1024 / 1024).toFixed(2)} MB`;
    });
  }

  const outfitForm = document.querySelector("[data-outfit-form]");
  if (outfitForm) {
    const refreshSlot = (select) => {
      const slot = document.querySelector(`[data-preview-slot="${select.name}"]`);
      if (!slot) return;
      const option = select.selectedOptions[0];
      const imageUrl = option?.dataset.image;
      const image = slot.querySelector("img");
      const empty = slot.querySelector("span");
      if (imageUrl) {
        image.src = imageUrl;
        image.alt = option.textContent.trim();
        image.hidden = false;
        empty.hidden = true;
        slot.classList.add("has-item");
      } else {
        image.removeAttribute("src");
        image.hidden = true;
        empty.hidden = false;
        slot.classList.remove("has-item");
      }
    };
    outfitForm.querySelectorAll("select[data-outfit-select]").forEach((select) => {
      select.addEventListener("change", () => refreshSlot(select));
      refreshSlot(select);
    });
  }

  document.querySelectorAll("[data-auto-submit]").forEach((control) => {
    control.addEventListener("change", () => control.form.submit());
  });
});
