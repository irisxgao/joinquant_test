from contextlib import asynccontextmanager
from datetime import date, datetime
from pathlib import Path
from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from . import db
from .image_service import save_clothing_image, ImageValidationError

BASE_DIR = Path(__file__).resolve().parent.parent
UPLOAD_ROOT = BASE_DIR / "data" / "uploads"
TEMPLATES = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))

@asynccontextmanager
async def lifespan(app: FastAPI):
    UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    db.init_db()
    yield

app = FastAPI(title="家庭衣橱", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static")

def context(request, **kwargs):
    family = db.row("SELECT * FROM families ORDER BY id LIMIT 1")
    members = db.rows("SELECT * FROM members WHERE family_id=? ORDER BY id", (family["id"],)) if family else []
    return {"request": request, "family": family, "members": members, **kwargs}

def require_member(member_id: int):
    member = db.row("SELECT * FROM members WHERE id=?", (member_id,))
    if not member: raise HTTPException(404, "家庭成员不存在")
    return member

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    family = db.row("SELECT * FROM families ORDER BY id LIMIT 1")
    stats = {"members": 0, "clothes": 0, "outfits": 0, "wears": 0}
    recent = []
    if family:
        fid = family["id"]
        stats = {
          "members": db.row("SELECT COUNT(*) n FROM members WHERE family_id=?", (fid,))["n"],
          "clothes": db.row("SELECT COUNT(*) n FROM clothes WHERE family_id=?", (fid,))["n"],
          "outfits": db.row("SELECT COUNT(*) n FROM outfits WHERE family_id=?", (fid,))["n"],
          "wears": db.row("SELECT COUNT(*) n FROM wear_records WHERE family_id=?", (fid,))["n"],
        }
        recent = db.rows("SELECT o.*, m.name member_name FROM outfits o JOIN members m ON m.id=o.member_id WHERE o.family_id=? ORDER BY o.id DESC LIMIT 4", (fid,))
    return TEMPLATES.TemplateResponse("home.html", context(request, stats=stats, recent=recent))

@app.get("/members", response_class=HTMLResponse)
def members_page(request: Request):
    return TEMPLATES.TemplateResponse("members.html", context(request))

@app.post("/members")
def create_member(name: str = Form(...)):
    family = db.row("SELECT * FROM families ORDER BY id LIMIT 1")
    db.execute("INSERT INTO members(family_id,name,created_at) VALUES(?,?,?)", (family["id"], name.strip(), datetime.now().isoformat(timespec="seconds")))
    return RedirectResponse("/members", 303)

@app.post("/members/{member_id}/delete")
def delete_member(member_id: int):
    if db.row("SELECT COUNT(*) n FROM members", ())["n"] <= 1:
        return RedirectResponse("/members?error=至少保留一位成员", 303)
    db.execute("DELETE FROM members WHERE id=?", (member_id,))
    return RedirectResponse("/members", 303)

@app.get("/wardrobe", response_class=HTMLResponse)
def wardrobe(request: Request, member_id: int|None=None, category: str="", color: str=""):
    family = db.row("SELECT * FROM families ORDER BY id LIMIT 1")
    sql = "SELECT c.*, m.name member_name FROM clothes c JOIN members m ON m.id=c.owner_member_id WHERE c.family_id=?"
    params=[family["id"]]
    if member_id: sql += " AND c.owner_member_id=?"; params.append(member_id)
    if category: sql += " AND c.category=?"; params.append(category)
    if color: sql += " AND c.color LIKE ?"; params.append(f"%{color}%")
    sql += " ORDER BY c.id DESC"
    clothes=db.rows(sql, tuple(params))
    return TEMPLATES.TemplateResponse("wardrobe.html", context(request, clothes=clothes, selected_member=member_id, category=category, color=color))

@app.get("/clothes/new", response_class=HTMLResponse)
def new_clothing(request: Request):
    return TEMPLATES.TemplateResponse("clothing_form.html", context(request, error=""))

@app.post("/clothes")
async def create_clothing(request: Request, member_id: int=Form(...), name: str=Form(...), category: str=Form(...), color: str=Form(""), season: str=Form(""), image: UploadFile=File(...)):
    member=require_member(member_id)
    raw=await image.read()
    try:
        image_path, thumbnail_path=save_clothing_image(raw, UPLOAD_ROOT, member["family_id"], member_id)
    except ImageValidationError as exc:
        return TEMPLATES.TemplateResponse("clothing_form.html", context(request, error=str(exc)), status_code=400)
    db.execute("INSERT INTO clothes(family_id,owner_member_id,name,category,color,season,image_path,thumbnail_path,created_at) VALUES(?,?,?,?,?,?,?,?,?)", (member["family_id"],member_id,name.strip(),category,color.strip(),season.strip(),image_path,thumbnail_path,datetime.now().isoformat(timespec="seconds")))
    return RedirectResponse("/wardrobe",303)

@app.post("/clothes/{clothing_id}/delete")
def delete_clothing(clothing_id: int):
    db.execute("DELETE FROM clothes WHERE id=?", (clothing_id,))
    return RedirectResponse("/wardrobe",303)

@app.get("/media/clothes/{clothing_id}/{kind}")
def clothing_media(clothing_id: int, kind: str):
    clothing=db.row("SELECT * FROM clothes WHERE id=?",(clothing_id,))
    if not clothing or kind not in {"display","thumbnail"}: raise HTTPException(404)
    rel=clothing["image_path"] if kind=="display" else clothing["thumbnail_path"]
    path=(UPLOAD_ROOT/rel).resolve()
    if UPLOAD_ROOT.resolve() not in path.parents or not path.exists(): raise HTTPException(404)
    return FileResponse(path)

@app.get("/outfits", response_class=HTMLResponse)
def outfits_page(request: Request, member_id: int|None=None):
    family=db.row("SELECT * FROM families ORDER BY id LIMIT 1")
    sql="SELECT o.*,m.name member_name FROM outfits o JOIN members m ON m.id=o.member_id WHERE o.family_id=?"; params=[family["id"]]
    if member_id: sql+=" AND o.member_id=?"; params.append(member_id)
    sql+=" ORDER BY o.id DESC"
    outfits=db.rows(sql,tuple(params))
    cards=[]
    for o in outfits:
        items=db.rows("SELECT oi.slot,c.id,c.name,c.thumbnail_path FROM outfit_items oi JOIN clothes c ON c.id=oi.clothing_id WHERE oi.outfit_id=? ORDER BY oi.sort_order",(o["id"],))
        cards.append((o,items))
    return TEMPLATES.TemplateResponse("outfits.html",context(request,cards=cards,selected_member=member_id))

@app.get("/outfits/new", response_class=HTMLResponse)
def new_outfit(request: Request, member_id: int|None=None):
    selected=member_id or db.row("SELECT id FROM members ORDER BY id LIMIT 1")["id"]
    clothes=db.rows("SELECT * FROM clothes WHERE owner_member_id=? AND status='available' ORDER BY category,name",(selected,))
    return TEMPLATES.TemplateResponse("outfit_form.html",context(request,clothes=clothes,selected_member=selected))

@app.post("/outfits")
async def create_outfit(request: Request, member_id:int=Form(...), name:str=Form(...), occasion:str=Form(""), note:str=Form("")):
    member=require_member(member_id)
    form=await request.form()
    outfit_id=db.execute("INSERT INTO outfits(family_id,member_id,name,occasion,note,created_at) VALUES(?,?,?,?,?,?)",(member["family_id"],member_id,name.strip(),occasion.strip(),note.strip(),datetime.now().isoformat(timespec="seconds")))
    order=0
    for slot in ["outerwear","top","bottom","dress","shoes","accessory"]:
        value=form.get(slot)
        if value:
            clothing=db.row("SELECT * FROM clothes WHERE id=? AND owner_member_id=?",(int(value),member_id))
            if clothing:
                db.execute("INSERT INTO outfit_items(outfit_id,clothing_id,slot,sort_order) VALUES(?,?,?,?)",(outfit_id,int(value),slot,order)); order+=1
    if order==0:
        db.execute("DELETE FROM outfits WHERE id=?",(outfit_id,))
        return RedirectResponse(f"/outfits/new?member_id={member_id}&error=请至少选择一件衣物",303)
    return RedirectResponse("/outfits",303)

@app.post("/outfits/{outfit_id}/delete")
def delete_outfit(outfit_id:int):
    db.execute("DELETE FROM outfits WHERE id=?",(outfit_id,))
    return RedirectResponse("/outfits",303)

@app.get("/today", response_class=HTMLResponse)
def today_page(request:Request, member_id:int|None=None):
    selected=member_id or db.row("SELECT id FROM members ORDER BY id LIMIT 1")["id"]
    outfits=db.rows("SELECT * FROM outfits WHERE member_id=? ORDER BY id DESC",(selected,))
    return TEMPLATES.TemplateResponse("today.html",context(request,outfits=outfits,selected_member=selected,today=date.today().isoformat()))

@app.post("/wear-records")
def create_wear_record(member_id:int=Form(...), outfit_id:int=Form(...), wear_date:str=Form(...), note:str=Form("")):
    member=require_member(member_id)
    outfit=db.row("SELECT * FROM outfits WHERE id=? AND member_id=?",(outfit_id,member_id))
    if not outfit: raise HTTPException(400,"搭配与成员不匹配")
    db.execute("INSERT INTO wear_records(family_id,member_id,outfit_id,wear_date,note,created_at) VALUES(?,?,?,?,?,?)",(member["family_id"],member_id,outfit_id,wear_date,note.strip(),datetime.now().isoformat(timespec="seconds")))
    return RedirectResponse("/history",303)

@app.get("/history", response_class=HTMLResponse)
def history(request:Request):
    records=db.rows("SELECT w.*,m.name member_name,o.name outfit_name FROM wear_records w JOIN members m ON m.id=w.member_id JOIN outfits o ON o.id=w.outfit_id ORDER BY w.wear_date DESC,w.id DESC")
    return TEMPLATES.TemplateResponse("history.html",context(request,records=records))
