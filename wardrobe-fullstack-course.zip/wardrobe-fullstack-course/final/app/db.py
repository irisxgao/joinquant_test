from pathlib import Path
import sqlite3
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "wardrobe.db"

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS families (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS members (
 id INTEGER PRIMARY KEY AUTOINCREMENT, family_id INTEGER NOT NULL, name TEXT NOT NULL,
 avatar_path TEXT, created_at TEXT NOT NULL,
 FOREIGN KEY(family_id) REFERENCES families(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS clothes (
 id INTEGER PRIMARY KEY AUTOINCREMENT, family_id INTEGER NOT NULL, owner_member_id INTEGER NOT NULL,
 name TEXT NOT NULL, category TEXT NOT NULL, color TEXT DEFAULT '', season TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'available', image_path TEXT NOT NULL, thumbnail_path TEXT NOT NULL,
 created_at TEXT NOT NULL,
 FOREIGN KEY(family_id) REFERENCES families(id) ON DELETE CASCADE,
 FOREIGN KEY(owner_member_id) REFERENCES members(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS outfits (
 id INTEGER PRIMARY KEY AUTOINCREMENT, family_id INTEGER NOT NULL, member_id INTEGER NOT NULL,
 name TEXT NOT NULL, occasion TEXT DEFAULT '', note TEXT DEFAULT '', created_at TEXT NOT NULL,
 FOREIGN KEY(family_id) REFERENCES families(id) ON DELETE CASCADE,
 FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS outfit_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, outfit_id INTEGER NOT NULL, clothing_id INTEGER NOT NULL,
 slot TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0,
 FOREIGN KEY(outfit_id) REFERENCES outfits(id) ON DELETE CASCADE,
 FOREIGN KEY(clothing_id) REFERENCES clothes(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS wear_records (
 id INTEGER PRIMARY KEY AUTOINCREMENT, family_id INTEGER NOT NULL, member_id INTEGER NOT NULL,
 outfit_id INTEGER NOT NULL, wear_date TEXT NOT NULL, note TEXT DEFAULT '', created_at TEXT NOT NULL,
 FOREIGN KEY(family_id) REFERENCES families(id) ON DELETE CASCADE,
 FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE CASCADE,
 FOREIGN KEY(outfit_id) REFERENCES outfits(id) ON DELETE CASCADE
);
"""

def connect():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn

def init_db():
    with connect() as conn:
        conn.executescript(SCHEMA)
        count = conn.execute("SELECT COUNT(*) FROM families").fetchone()[0]
        if count == 0:
            now = datetime.now().isoformat(timespec="seconds")
            cur = conn.execute("INSERT INTO families(name, created_at) VALUES (?, ?)", ("我的家庭", now))
            conn.execute("INSERT INTO members(family_id, name, created_at) VALUES (?, ?, ?)", (cur.lastrowid, "我", now))

def rows(sql, params=()):
    with connect() as conn:
        return conn.execute(sql, params).fetchall()

def row(sql, params=()):
    with connect() as conn:
        return conn.execute(sql, params).fetchone()

def execute(sql, params=()):
    with connect() as conn:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid
