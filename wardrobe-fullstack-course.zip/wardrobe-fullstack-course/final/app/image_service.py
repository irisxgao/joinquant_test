from pathlib import Path
from uuid import uuid4
from PIL import Image, ImageOps

ALLOWED_FORMATS = {"JPEG": ".jpg", "PNG": ".png", "WEBP": ".webp"}
MAX_BYTES = 10 * 1024 * 1024

class ImageValidationError(ValueError):
    pass

def save_clothing_image(raw: bytes, upload_root: Path, family_id: int, member_id: int):
    if not raw or len(raw) > MAX_BYTES:
        raise ImageValidationError("图片不能为空，且大小不能超过 10 MB")
    folder = Path(f"family_{family_id}/member_{member_id}/clothes/{uuid4().hex}")
    target = (upload_root / folder).resolve()
    root = upload_root.resolve()
    if root not in target.parents:
        raise ImageValidationError("非法图片路径")
    target.mkdir(parents=True, exist_ok=False)
    temp = target / "source.tmp"
    temp.write_bytes(raw)
    try:
        with Image.open(temp) as image:
            image.verify()
        with Image.open(temp) as image:
            image = ImageOps.exif_transpose(image).convert("RGB")
            display = image.copy()
            display.thumbnail((1600, 1600))
            display.save(target / "display.webp", "WEBP", quality=88)
            thumb = ImageOps.fit(image, (420, 420), method=Image.Resampling.LANCZOS)
            thumb.save(target / "thumbnail.webp", "WEBP", quality=82)
    except Exception as exc:
        raise ImageValidationError("无法识别该图片，请上传 JPEG、PNG 或 WebP") from exc
    finally:
        temp.unlink(missing_ok=True)
    return (folder / "display.webp").as_posix(), (folder / "thumbnail.webp").as_posix()
