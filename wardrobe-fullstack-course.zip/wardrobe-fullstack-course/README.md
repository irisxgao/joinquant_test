# 家庭衣橱全栈实战课程

面向已经掌握 Python、HTML、CSS 基础，并有少量 JavaScript 经验的学习者。项目采用 **FastAPI + Jinja2 + SQLite + Pillow + 原生 JavaScript**，不依赖 Node.js/npm。

## 先看最终效果

```bash
cd final
python -m venv .venv
```

Windows PowerShell：

```powershell
.venv\Scripts\Activate.ps1
```

macOS / Linux：

```bash
source .venv/bin/activate
```

安装并启动：

```bash
python -m pip install -r requirements.txt
python run.py
```

浏览器打开 <http://127.0.0.1:8000>。

### 最终版演示顺序

1. “家庭成员”添加两位成员。
2. “衣橱”分别为成员上传衣物，选择图片后可立即预览。
3. 使用成员、分类和颜色筛选衣橱。
4. “搭配”创建新搭配，选择衣物时右侧实时更新预览。
5. “今天穿什么”保存今日穿着。
6. “穿着历史”查看记录。

## 课程路线

1. 动态首页与请求链路
2. SQLite 与家庭成员
3. 模板继承与完整布局
4. 衣物图片上传
5. 数字衣橱
6. 筛选与 URL 状态
7. 搭配数据模型
8. JavaScript 实时搭配预览
9. 视觉衣物选择器
10. 今天穿什么与历史
11. 安全与可靠性
12. 最终整合与演进

每课目录都有详细 `README.md` 和可独立运行的 `checkpoint/`。建议先操作，再对照路由、Jinja2 模板、CSS 和 JavaScript 阅读。

## 重要数据约定

SQLite 只保存图片相对路径，例如：

```text
family_1/member_2/clothes/9fe.../thumbnail.webp
```

图片实际位于 `data/uploads/`。备份必须同时包含：

```text
data/wardrobe.db
data/uploads/
```

## 课程边界

这是本地优先教学项目。最终版包含文件校验和路径保护，但没有登录、CSRF 防护和限流，因此不要直接公开到互联网。
