# 第 9 课：视觉衣物选择器

## 本课定位

你已经具备 Python、HTML 和 CSS 基础，也接触过一点 JavaScript。本课不会重复变量、循环或盒模型，而是围绕真实项目解释 **事件委托、卡片选择、隐藏字段、移动端衣物面板**。

## 本课完成后能看到什么

运行 `checkpoint` 后，可以在浏览器中观察本节涉及的页面和功能。课程仓库中的检查点保持可独立运行，便于你随时回退、比较和实验。

## 这一课的数据流

```text
浏览器操作
  → HTTP 请求
  → FastAPI 路由
  → SQLite 查询或文件处理
  → Jinja2 生成 HTML
  → CSS 布局 / JavaScript 交互
  → 浏览器显示结果
```

## 建议学习方式

1. 先运行检查点，亲手操作本课功能。
2. 打开浏览器开发者工具的 Network 和 Console。
3. 按 README 指引找到对应路由、模板和样式。
4. 修改一个小地方并刷新，不要只阅读代码。
5. 完成课后练习，再进入下一课。

## 从下拉框到视觉选择器

当前检查点保留下拉框，课后练习要求把衣物渲染为可点击缩略图。建议结构：

```html
<button type="button" class="clothing-choice" data-clothing-id="12">
  <img src="/media/clothes/12/thumbnail" alt="白色衬衫">
  <span>白色衬衫</span>
</button>
```

点击后更新隐藏字段，并给当前卡片添加 `.selected`。使用父容器上的一个点击监听器实现事件委托，而不是给每张卡片分别绑定监听器。

## JavaScript 重点拆解

本课重点阅读 `app/static/app.js`。例如：

```javascript
select.addEventListener("change", () => refreshSlot(select));
```

- `select` 是通过 DOM 查询得到的 `<select>` 对象。
- `change` 会在选择项变化后触发。
- 第二个参数是回调函数。这里使用箭头函数，是因为还要把当前 `select` 传给 `refreshSlot`。
- 不能写成 `refreshSlot(select)` 直接作为第二个参数，否则页面初始化时就会执行，并把返回值当成监听器。

读取图片地址：

```javascript
const option = select.selectedOptions[0];
const imageUrl = option?.dataset.image;
```

HTML 中的 `data-image` 会映射为 JavaScript 的 `dataset.image`。`?.` 是可选链，找不到选中项时不会立即报错。

## 运行本课检查点

```bash
cd checkpoint
python -m venv .venv
```

Windows PowerShell：

```powershell
.venv\Scripts\Activate.ps1
```

macOS / Linux：

```bash
source .venv/bin/activate
```

然后执行：

```bash
python -m pip install -r requirements.txt
python run.py
```

浏览器打开 <http://127.0.0.1:8000>。按 `Ctrl+C` 停止服务器。

## 常见错误

- `ModuleNotFoundError`：通常是虚拟环境未激活，或依赖安装到了另一个 Python。使用 `python -m pip --version` 检查。
- 端口被占用：先停止旧服务器，或修改 `run.py` 中的端口。
- 图片不显示：检查 Network 中媒体请求的状态码，以及 `data/uploads` 是否存在文件。
- 修改代码未生效：确认终端正在当前课的 `checkpoint` 目录运行。

## 本课完成检查

- [ ] 我能说清浏览器请求经过了哪些模块。
- [ ] 我能在 Network 中找到对应请求。
- [ ] 我修改过至少一处代码并验证结果。
- [ ] 我完成了本课练习或记录了疑问。
