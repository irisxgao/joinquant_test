# 第 2 课：SQLite 与家庭成员

## 本课定位

你已经具备 Python、HTML 和 CSS 基础，也接触过一点 JavaScript。本课不会重复变量、循环或盒模型，而是围绕真实项目解释 **数据库连接、建表、参数化 SQL、GET/POST、POST-Redirect-GET**。

## 本课完成后能看到什么

运行 `checkpoint` 后，可以在浏览器中观察本节涉及的页面和功能。课程仓库中的检查点保持可独立运行，便于你随时回退、比较和实验。

## 这一课的数据流

```text
浏览器操作
  → HTTP 请求
  → FastAPI 路由
  → SQLite 查询或文件处理
  → Jinja2 生成 HTML
  → CSS 布局 / JavaScript 交互
  → 浏览器显示结果
```

## 建议学习方式

1. 先运行检查点，亲手操作本课功能。
2. 打开浏览器开发者工具的 Network 和 Console。
3. 按 README 指引找到对应路由、模板和样式。
4. 修改一个小地方并刷新，不要只阅读代码。
5. 完成课后练习，再进入下一课。

## 数据库重点

查看 `app/db.py`。`connect()` 每次创建连接时同时设置：

```python
conn.row_factory = sqlite3.Row
conn.execute("PRAGMA foreign_keys = ON")
```

`sqlite3.Row` 让查询结果既能按位置，也能按字段名读取。外键设置在 SQLite 中是按连接启用的，因此不能只在建库时调用一次。

成员表中的 `family_id` 表示一位成员属于哪个家庭。家庭成员是现实人物档案，未来的登录账号应当单独建模。

表单提交完成后返回 303 重定向，避免用户刷新页面时重复提交 POST。

## 运行本课检查点

```bash
cd checkpoint
python -m venv .venv
```

Windows PowerShell：

```powershell
.venv\Scripts\Activate.ps1
```

macOS / Linux：

```bash
source .venv/bin/activate
```

然后执行：

```bash
python -m pip install -r requirements.txt
python run.py
```

浏览器打开 <http://127.0.0.1:8000>。按 `Ctrl+C` 停止服务器。

## 常见错误

- `ModuleNotFoundError`：通常是虚拟环境未激活，或依赖安装到了另一个 Python。使用 `python -m pip --version` 检查。
- 端口被占用：先停止旧服务器，或修改 `run.py` 中的端口。
- 图片不显示：检查 Network 中媒体请求的状态码，以及 `data/uploads` 是否存在文件。
- 修改代码未生效：确认终端正在当前课的 `checkpoint` 目录运行。

## 本课完成检查

- [ ] 我能说清浏览器请求经过了哪些模块。
- [ ] 我能在 Network 中找到对应请求。
- [ ] 我修改过至少一处代码并验证结果。
- [ ] 我完成了本课练习或记录了疑问。
