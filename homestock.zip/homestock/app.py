#!/usr/bin/env python3
"""
HomeStock - 极简家庭物品管理系统
单文件后端: FastAPI + SQLite。照片存磁盘, 数据库只存文件名。
启动: uvicorn app:app --host 0.0.0.0 --port 8000
"""
import io
import os
import re
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from PIL import Image, ImageOps

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("HOMESTOCK_DATA", BASE_DIR / "data"))
PHOTO_DIR = DATA_DIR / "photos"
DB_PATH = DATA_DIR / "homestock.db"
MAX_PHOTO_BYTES = 12 * 1024 * 1024      # 单张上传上限 12MB
PHOTO_MAX_EDGE = 1280                   # 落盘前压缩到最长边 1280px
THUMB_MAX_EDGE = 320

DATA_DIR.mkdir(parents=True, exist_ok=True)
PHOTO_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_MEMBERS = ["公共", "爸爸", "妈妈", "宝宝"]
COLORS = ["#4f8cff", "#ff8a5c", "#38c793", "#a86bf0", "#f05c6b", "#2bb3c0"]


# --------------------------------------------------------------------------
# 数据库
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS members (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL UNIQUE,
    color   TEXT NOT NULL DEFAULT '#4f8cff'
);

CREATE TABLE IF NOT EXISTS items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    barcode     TEXT,
    quantity    INTEGER NOT NULL DEFAULT 1,
    location    TEXT,
    owner_id    INTEGER REFERENCES members(id) ON DELETE SET NULL,
    photo       TEXT,
    note        TEXT,
    expires_on  TEXT,
    created_at  INTEGER NOT NULL,
    updated_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS barcodes (
    code        TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    hits        INTEGER NOT NULL DEFAULT 1,
    updated_at  INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_items_owner   ON items(owner_id);
CREATE INDEX IF NOT EXISTS idx_items_barcode ON items(barcode);
CREATE INDEX IF NOT EXISTS idx_items_created ON items(created_at DESC);
"""


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")      # 多人同时写不互相阻塞
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


@contextmanager
def db():
    conn = connect()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with db() as conn:
        conn.executescript(SCHEMA)
        n = conn.execute("SELECT COUNT(*) AS c FROM members").fetchone()["c"]
        if n == 0:
            for i, name in enumerate(DEFAULT_MEMBERS):
                conn.execute(
                    "INSERT INTO members (name, color) VALUES (?, ?)",
                    (name, COLORS[i % len(COLORS)]),
                )


def now() -> int:
    return int(time.time())


# --------------------------------------------------------------------------
# 应用
# --------------------------------------------------------------------------
app = FastAPI(title="HomeStock", docs_url=None, redoc_url=None)
init_db()


def row_to_item(r: sqlite3.Row) -> dict:
    return {
        "id": r["id"],
        "name": r["name"],
        "barcode": r["barcode"],
        "quantity": r["quantity"],
        "location": r["location"],
        "owner_id": r["owner_id"],
        "owner_name": r["owner_name"] if "owner_name" in r.keys() else None,
        "owner_color": r["owner_color"] if "owner_color" in r.keys() else None,
        "photo": r["photo"],
        "note": r["note"],
        "expires_on": r["expires_on"],
        "created_at": r["created_at"],
        "updated_at": r["updated_at"],
    }


# ---------------------------- 成员 ----------------------------
@app.get("/api/members")
def list_members():
    with db() as conn:
        rows = conn.execute(
            """SELECT m.*, (SELECT COUNT(*) FROM items i WHERE i.owner_id = m.id) AS item_count
               FROM members m ORDER BY m.id"""
        ).fetchall()
    return [dict(r) for r in rows]


@app.post("/api/members")
def create_member(name: str = Form(...), color: str = Form("")):
    name = name.strip()
    if not name:
        raise HTTPException(400, "成员名不能为空")
    with db() as conn:
        n = conn.execute("SELECT COUNT(*) AS c FROM members").fetchone()["c"]
        c = color.strip() or COLORS[n % len(COLORS)]
        try:
            cur = conn.execute(
                "INSERT INTO members (name, color) VALUES (?, ?)", (name, c)
            )
        except sqlite3.IntegrityError:
            raise HTTPException(409, "该成员已存在")
        return {"id": cur.lastrowid, "name": name, "color": c, "item_count": 0}


@app.delete("/api/members/{member_id}")
def delete_member(member_id: int):
    """删除成员, 其名下物品转为未分配(不会删物品)。"""
    with db() as conn:
        conn.execute("UPDATE items SET owner_id = NULL WHERE owner_id = ?", (member_id,))
        conn.execute("DELETE FROM members WHERE id = ?", (member_id,))
    return {"ok": True}


# ---------------------------- 条码字典 ----------------------------
@app.get("/api/barcode/{code}")
def lookup_barcode(code: str):
    """扫过一次的条码会被记住, 第二次自动带出名字。"""
    with db() as conn:
        r = conn.execute("SELECT * FROM barcodes WHERE code = ?", (code.strip(),)).fetchone()
        if r:
            return {"found": True, "name": r["name"], "hits": r["hits"]}
        # 退一步: 同条码是否已有物品记录
        r2 = conn.execute(
            "SELECT name FROM items WHERE barcode = ? ORDER BY id DESC LIMIT 1", (code.strip(),)
        ).fetchone()
        if r2:
            return {"found": True, "name": r2["name"], "hits": 0}
    return {"found": False}


def remember_barcode(conn: sqlite3.Connection, code: Optional[str], name: str) -> None:
    code = (code or "").strip()
    if not code or not name.strip():
        return
    conn.execute(
        """INSERT INTO barcodes (code, name, hits, updated_at) VALUES (?, ?, 1, ?)
           ON CONFLICT(code) DO UPDATE SET name = excluded.name,
                                           hits = hits + 1,
                                           updated_at = excluded.updated_at""",
        (code, name.strip(), now()),
    )


# ---------------------------- 照片 ----------------------------
def save_photo(upload: UploadFile) -> str:
    raw = upload.file.read(MAX_PHOTO_BYTES + 1)
    if len(raw) > MAX_PHOTO_BYTES:
        raise HTTPException(413, "照片太大了(上限 12MB)")
    if not raw:
        raise HTTPException(400, "照片是空的")
    try:
        img = Image.open(io.BytesIO(raw))
        img = ImageOps.exif_transpose(img)        # 修正手机竖拍方向
        img = img.convert("RGB")
    except Exception:
        raise HTTPException(400, "无法识别的图片格式")

    img.thumbnail((PHOTO_MAX_EDGE, PHOTO_MAX_EDGE))
    fname = f"{int(time.time())}-{uuid.uuid4().hex[:8]}.jpg"
    img.save(PHOTO_DIR / fname, "JPEG", quality=82, optimize=True)

    thumb = img.copy()
    thumb.thumbnail((THUMB_MAX_EDGE, THUMB_MAX_EDGE))
    thumb.save(PHOTO_DIR / f"thumb-{fname}", "JPEG", quality=75, optimize=True)
    return fname


@app.get("/photos/{fname}")
def get_photo(fname: str):
    if not re.fullmatch(r"[A-Za-z0-9._-]+", fname):   # 防目录穿越
        raise HTTPException(400, "非法文件名")
    p = PHOTO_DIR / fname
    if not p.exists():
        raise HTTPException(404, "照片不存在")
    return FileResponse(p, media_type="image/jpeg",
                        headers={"Cache-Control": "public, max-age=604800"})


def drop_photo(fname: Optional[str]) -> None:
    if not fname:
        return
    for p in (PHOTO_DIR / fname, PHOTO_DIR / f"thumb-{fname}"):
        try:
            p.unlink(missing_ok=True)
        except OSError:
            pass


# ---------------------------- 物品 ----------------------------
@app.get("/api/items")
def list_items(q: str = "", owner_id: str = "", sort: str = "new", limit: int = 500):
    sql = """SELECT i.*, m.name AS owner_name, m.color AS owner_color
             FROM items i LEFT JOIN members m ON m.id = i.owner_id WHERE 1=1"""
    args: list = []
    if q.strip():
        kw = f"%{q.strip()}%"
        sql += " AND (i.name LIKE ? OR i.location LIKE ? OR i.note LIKE ? OR i.barcode LIKE ?)"
        args += [kw, kw, kw, kw]
    if owner_id.strip():
        if owner_id == "none":
            sql += " AND i.owner_id IS NULL"
        else:
            sql += " AND i.owner_id = ?"
            args.append(int(owner_id))
    order = {
        "new": " ORDER BY i.created_at DESC",
        "name": " ORDER BY i.name COLLATE NOCASE ASC",
        "expiry": " ORDER BY (i.expires_on IS NULL OR i.expires_on = ''), i.expires_on ASC",
    }.get(sort, " ORDER BY i.created_at DESC")
    sql += order + " LIMIT ?"
    args.append(max(1, min(limit, 2000)))
    with db() as conn:
        rows = conn.execute(sql, args).fetchall()
    return [row_to_item(r) for r in rows]


@app.post("/api/items")
def create_item(
    name: str = Form(...),
    barcode: str = Form(""),
    quantity: int = Form(1),
    location: str = Form(""),
    owner_id: str = Form(""),
    note: str = Form(""),
    expires_on: str = Form(""),
    photo: UploadFile = File(None),
):
    name = name.strip()
    if not name:
        raise HTTPException(400, "物品名称不能为空")
    fname = save_photo(photo) if photo and photo.filename else None
    oid = int(owner_id) if owner_id.strip() else None
    ts = now()
    with db() as conn:
        cur = conn.execute(
            """INSERT INTO items (name, barcode, quantity, location, owner_id,
                                  photo, note, expires_on, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (name, barcode.strip() or None, max(0, quantity), location.strip() or None,
             oid, fname, note.strip() or None, expires_on.strip() or None, ts, ts),
        )
        remember_barcode(conn, barcode, name)
        r = conn.execute(
            """SELECT i.*, m.name AS owner_name, m.color AS owner_color
               FROM items i LEFT JOIN members m ON m.id = i.owner_id WHERE i.id = ?""",
            (cur.lastrowid,),
        ).fetchone()
    return row_to_item(r)


@app.post("/api/items/{item_id}")
def update_item(
    item_id: int,
    name: str = Form(...),
    barcode: str = Form(""),
    quantity: int = Form(1),
    location: str = Form(""),
    owner_id: str = Form(""),
    note: str = Form(""),
    expires_on: str = Form(""),
    photo: UploadFile = File(None),
):
    with db() as conn:
        old = conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
        if not old:
            raise HTTPException(404, "物品不存在")
        fname = old["photo"]
        if photo and photo.filename:
            fname = save_photo(photo)
            drop_photo(old["photo"])
        oid = int(owner_id) if owner_id.strip() else None
        conn.execute(
            """UPDATE items SET name=?, barcode=?, quantity=?, location=?, owner_id=?,
                                photo=?, note=?, expires_on=?, updated_at=? WHERE id=?""",
            (name.strip(), barcode.strip() or None, max(0, quantity),
             location.strip() or None, oid, fname, note.strip() or None,
             expires_on.strip() or None, now(), item_id),
        )
        remember_barcode(conn, barcode, name)
        r = conn.execute(
            """SELECT i.*, m.name AS owner_name, m.color AS owner_color
               FROM items i LEFT JOIN members m ON m.id = i.owner_id WHERE i.id = ?""",
            (item_id,),
        ).fetchone()
    return row_to_item(r)


@app.post("/api/items/{item_id}/quantity")
def bump_quantity(item_id: int, delta: int = Form(...)):
    """列表页 +/- 快捷改数量。"""
    with db() as conn:
        r = conn.execute("SELECT quantity FROM items WHERE id = ?", (item_id,)).fetchone()
        if not r:
            raise HTTPException(404, "物品不存在")
        q = max(0, r["quantity"] + delta)
        conn.execute("UPDATE items SET quantity=?, updated_at=? WHERE id=?", (q, now(), item_id))
    return {"id": item_id, "quantity": q}


@app.delete("/api/items/{item_id}")
def delete_item(item_id: int):
    with db() as conn:
        r = conn.execute("SELECT photo FROM items WHERE id = ?", (item_id,)).fetchone()
        if not r:
            raise HTTPException(404, "物品不存在")
        conn.execute("DELETE FROM items WHERE id = ?", (item_id,))
    drop_photo(r["photo"])
    return {"ok": True}


@app.get("/api/stats")
def stats():
    with db() as conn:
        total = conn.execute("SELECT COUNT(*) AS c FROM items").fetchone()["c"]
        qty = conn.execute("SELECT COALESCE(SUM(quantity),0) AS s FROM items").fetchone()["s"]
        codes = conn.execute("SELECT COUNT(*) AS c FROM barcodes").fetchone()["c"]
    return {"items": total, "quantity": qty, "barcodes": codes}


@app.get("/api/export")
def export_csv():
    import csv
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "名称", "条码", "数量", "位置", "归属", "备注", "过期日", "创建时间"])
    with db() as conn:
        rows = conn.execute(
            """SELECT i.*, m.name AS owner_name FROM items i
               LEFT JOIN members m ON m.id = i.owner_id ORDER BY i.id"""
        ).fetchall()
    for r in rows:
        w.writerow([r["id"], r["name"], r["barcode"] or "", r["quantity"],
                    r["location"] or "", r["owner_name"] or "", r["note"] or "",
                    r["expires_on"] or "",
                    time.strftime("%Y-%m-%d %H:%M", time.localtime(r["created_at"]))])
    return Response(
        content=("\ufeff" + buf.getvalue()).encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="homestock.csv"'},
    )


# ---------------------------- 前端 ----------------------------
app.mount("/", StaticFiles(directory=BASE_DIR / "static", html=True), name="static")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
