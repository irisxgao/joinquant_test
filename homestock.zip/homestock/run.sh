#!/usr/bin/env bash
# 一键启动 (Linux / macOS)
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install -q -r requirements.txt
IP=$(hostname -I 2>/dev/null | awk '{print $1}' || ipconfig getifaddr en0 2>/dev/null || echo 127.0.0.1)
echo "启动中… 家里人用手机浏览器打开:  http://${IP}:8000"
exec uvicorn app:app --host 0.0.0.0 --port 8000
