/* 家庭物品管理 - 前端逻辑 (原生 JS, 无构建步骤) */
const $ = (s) => document.querySelector(s);
const api = (p, o) => fetch(p, o).then(async (r) => {
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || "请求失败");
  return r.json();
});

let members = [];
let ownerFilter = "";     // "" 全部 | "none" 未分配 | "3" 成员id
let photoFile = null;

/* ---------------- 提示 ---------------- */
let toastTimer;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add("hidden"), 2200);
}

/* ---------------- 成员 ---------------- */
async function loadMembers() {
  members = await api("/api/members");
  // 筛选条
  const chips = $("#chips");
  chips.innerHTML = "";
  const mk = (label, val) => {
    const b = document.createElement("button");
    b.className = "chip" + (ownerFilter === val ? " on" : "");
    b.textContent = label;
    b.onclick = () => { ownerFilter = val; loadMembers(); loadItems(); };
    chips.appendChild(b);
  };
  mk("全部", "");
  members.forEach((m) => mk(`${m.name} (${m.item_count})`, String(m.id)));
  mk("未分配", "none");

  // 表单下拉
  const sel = $("#f-owner");
  const keep = sel.value;
  sel.innerHTML = `<option value="">— 未分配 —</option>` +
    members.map((m) => `<option value="${m.id}">${esc(m.name)}</option>`).join("");
  if (keep) sel.value = keep;

  // 成员管理列表
  $("#mlist").innerHTML = members.map((m) => `
    <li>
      <i class="dot" style="background:${m.color}"></i>
      <span class="nm">${esc(m.name)}</span>
      <span class="tip">${m.item_count} 件</span>
      <button class="ghost" data-del="${m.id}">🗑</button>
    </li>`).join("");
  $("#mlist").querySelectorAll("[data-del]").forEach((b) => {
    b.onclick = async () => {
      if (!confirm("删除该成员?名下物品会变成「未分配」。")) return;
      await api("/api/members/" + b.dataset.del, { method: "DELETE" });
      if (ownerFilter === b.dataset.del) ownerFilter = "";
      await loadMembers(); loadItems();
    };
  });
}

/* ---------------- 物品列表 ---------------- */
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function expiryHTML(d) {
  if (!d) return "";
  const days = Math.ceil((new Date(d + "T00:00:00") - new Date()) / 86400000);
  if (days < 0) return `<span class="exp-over">已过期</span> · `;
  if (days <= 30) return `<span class="exp-soon">${days} 天后过期</span> · `;
  return `${d} 过期 · `;
}

async function loadItems() {
  const q = $("#search").value.trim();
  const sort = $("#sort").value;
  const items = await api(`/api/items?q=${encodeURIComponent(q)}&owner_id=${ownerFilter}&sort=${sort}`);
  const list = $("#list");
  list.innerHTML = "";
  $("#empty").classList.toggle("hidden", items.length > 0);

  items.forEach((it) => {
    const el = document.createElement("div");
    el.className = "card";
    const thumb = it.photo
      ? `<img class="thumb" src="/photos/thumb-${encodeURIComponent(it.photo)}" loading="lazy" alt="">`
      : `<div class="thumb">📦</div>`;
    const owner = it.owner_name
      ? `<i class="owner" style="background:${it.owner_color}">${esc(it.owner_name)}</i>` : "";
    const meta = [it.location, it.barcode ? "条码 " + it.barcode : "", it.note]
      .filter(Boolean).map(esc).join(" · ");
    el.innerHTML = `
      ${thumb}
      <div class="card-body">
        <div class="card-title">${esc(it.name)}</div>
        <div class="card-meta">${owner}${expiryHTML(it.expires_on)}${meta || "—"}</div>
      </div>
      <div class="qty">
        <button data-d="-1">−</button><span>${it.quantity}</span><button data-d="1">＋</button>
      </div>`;
    el.querySelector(".card-body").onclick = () => openSheet(it);
    el.querySelectorAll("[data-d]").forEach((b) => {
      b.onclick = async (e) => {
        e.stopPropagation();
        const fd = new FormData(); fd.append("delta", b.dataset.d);
        const r = await api(`/api/items/${it.id}/quantity`, { method: "POST", body: fd });
        el.querySelector(".qty span").textContent = r.quantity;
      };
    });
    list.appendChild(el);
  });
}

/* ---------------- 编辑弹层 ---------------- */
function openSheet(item) {
  photoFile = null;
  $("#form").reset();
  $("#scan-msg").textContent = "";
  $("#photo-preview").classList.add("hidden");
  $("#photo-hint").classList.remove("hidden");

  if (item) {
    $("#sheet-title").textContent = "编辑物品";
    $("#f-id").value = item.id;
    $("#f-name").value = item.name || "";
    $("#f-barcode").value = item.barcode || "";
    $("#f-qty").value = item.quantity;
    $("#f-location").value = item.location || "";
    $("#f-owner").value = item.owner_id || "";
    $("#f-note").value = item.note || "";
    $("#f-expires").value = item.expires_on || "";
    if (item.photo) {
      $("#photo-preview").src = "/photos/" + encodeURIComponent(item.photo);
      $("#photo-preview").classList.remove("hidden");
      $("#photo-hint").classList.add("hidden");
    }
    $("#btn-delete").classList.remove("hidden");
  } else {
    $("#sheet-title").textContent = "添加物品";
    $("#f-id").value = "";
    $("#f-qty").value = 1;
    if (ownerFilter && ownerFilter !== "none") $("#f-owner").value = ownerFilter;
    $("#btn-delete").classList.add("hidden");
  }
  $("#sheet").classList.remove("hidden");
}
const closeSheet = () => $("#sheet").classList.add("hidden");

$("#fab").onclick = () => openSheet(null);
$("#sheet-close").onclick = closeSheet;
$("#sheet").onclick = (e) => { if (e.target.id === "sheet") closeSheet(); };
$("#btn-members").onclick = () => $("#msheet").classList.remove("hidden");
$("#msheet-close").onclick = () => $("#msheet").classList.add("hidden");
$("#msheet").onclick = (e) => { if (e.target.id === "msheet") $("#msheet").classList.add("hidden"); };

/* 物品照片选择 */
$("#f-photo").onchange = (e) => {
  const f = e.target.files[0];
  if (!f) return;
  photoFile = f;
  const url = URL.createObjectURL(f);
  $("#photo-preview").src = url;
  $("#photo-preview").classList.remove("hidden");
  $("#photo-hint").classList.add("hidden");
};

/* ---------------- 条码识别 ----------------
   走 <input capture> 拍照 + 图片解码, 不申请摄像头权限,
   因此在纯 HTTP 的局域网地址下也能正常工作。            */
$("#f-scan").onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const msg = $("#scan-msg");
  if (window.__noScanLib || typeof Html5Qrcode === "undefined") {
    msg.textContent = "未加载识别库,请手动输入条码(见 README)";
    return;
  }
  msg.textContent = "识别中…";
  try {
    const scanner = new Html5Qrcode("scan-holder", false);
    const code = await scanner.scanFile(f, false);
    $("#f-barcode").value = code;
    msg.textContent = "识别成功:" + code;
    await afterBarcode(code);
  } catch (err) {
    msg.textContent = "没认出来,换个角度再拍或手动输入";
  } finally {
    e.target.value = "";
  }
};

$("#f-barcode").onchange = () => {
  const c = $("#f-barcode").value.trim();
  if (c) afterBarcode(c);
};

/* 条码字典:扫过一次的商品自动带出名字 */
async function afterBarcode(code) {
  try {
    const r = await api("/api/barcode/" + encodeURIComponent(code));
    if (r.found && !$("#f-name").value.trim()) {
      $("#f-name").value = r.name;
      $("#scan-msg").textContent = `认识这个:${r.name}`;
    }
  } catch (_) { /* 忽略 */ }
}

/* ---------------- 保存 / 删除 ---------------- */
$("#form").onsubmit = async (e) => {
  e.preventDefault();
  const btn = $("#btn-save");
  btn.disabled = true; btn.textContent = "保存中…";
  try {
    const fd = new FormData();
    fd.append("name", $("#f-name").value);
    fd.append("barcode", $("#f-barcode").value);
    fd.append("quantity", $("#f-qty").value || "1");
    fd.append("location", $("#f-location").value);
    fd.append("owner_id", $("#f-owner").value);
    fd.append("note", $("#f-note").value);
    fd.append("expires_on", $("#f-expires").value);
    if (photoFile) fd.append("photo", photoFile);

    const id = $("#f-id").value;
    await api(id ? "/api/items/" + id : "/api/items", { method: "POST", body: fd });
    closeSheet();
    toast(id ? "已更新" : "已添加");
    await loadMembers(); loadItems();
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false; btn.textContent = "保存";
  }
};

$("#btn-delete").onclick = async () => {
  if (!confirm("确定删除这件物品?")) return;
  await api("/api/items/" + $("#f-id").value, { method: "DELETE" });
  closeSheet(); toast("已删除");
  await loadMembers(); loadItems();
};

/* ---------------- 成员添加 ---------------- */
$("#mform").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const fd = new FormData();
    fd.append("name", $("#m-name").value);
    await api("/api/members", { method: "POST", body: fd });
    $("#m-name").value = "";
    await loadMembers();
  } catch (err) { toast(err.message); }
};

/* ---------------- 搜索 ---------------- */
let searchTimer;
$("#search").oninput = () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadItems, 250);
};
$("#sort").onchange = loadItems;

/* ---------------- 启动 ---------------- */
(async () => { await loadMembers(); await loadItems(); })();
