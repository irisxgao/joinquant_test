@echo off
REM 一键启动 (Windows)
cd /d %~dp0
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -q -r requirements.txt
echo.
echo 启动中… 先用 ipconfig 查本机 IP,家里人访问 http://本机IP:8000
echo.
uvicorn app:app --host 0.0.0.0 --port 8000
pause
