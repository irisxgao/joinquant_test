# HomeStock · 家庭物品管理系统

局域网自用的极简物品台账:**扫条码 / 拍照录入,按家庭成员分类**。
后端单文件 Python(FastAPI + SQLite),前端一个网页,家里人用手机浏览器打开就能用,不装 App。

---

## 一、功能

| 功能 | 说明 |
|---|---|
| 拍条码识别 | 手机拍一张条码照片,前端本地解码,自动填进条码框 |
| 条码记忆 | 同一个条码扫第二次,自动带出上次录的商品名,不用重复打字 |
| 拍照记录 | 调用系统相机拍实物照,服务端自动压缩 + 生成缩略图 |
| 成员分类 | 默认「公共 / 爸爸 / 妈妈 / 宝宝」,可自行增删 |
| 搜索筛选 | 按名称、位置、备注、条码搜索;按成员筛选;按名称或过期日排序 |
| 快捷增减 | 列表页 ＋/− 直接改数量,不用进编辑页 |
| 过期提醒 | 30 天内到期标黄,已过期标红 |
| CSV 导出 | 右上角 ⬇️ 一键导出全部数据(Excel 打开不乱码) |

---

## 二、目录结构

```
homestock/
├── app.py                  # 后端全部逻辑(约 380 行)
├── requirements.txt
├── static/
│   ├── index.html
│   ├── style.css
│   ├── app.js
│   └── vendor/             # 放 html5-qrcode.min.js(可选,见第五节)
├── data/                   # 自动创建:homestock.db + photos/
├── run.sh / run.bat        # 一键启动脚本
├── Dockerfile
├── docker-compose.yml
└── homestock.service       # systemd 开机自启配置
```

---

## 三、最快启动方式

### 方式 A:一键脚本(推荐先用这个跑通)

**Linux / macOS**
```bash
unzip homestock.zip && cd homestock
./run.sh
```

**Windows**
```
解压后双击 run.bat
```

脚本会自动建虚拟环境、装依赖、启动服务。看到 `Uvicorn running on http://0.0.0.0:8000` 就成功了。

### 方式 B:手动三条命令

```bash
cd homestock
python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

> `--host 0.0.0.0` 必须要有,否则只有服务器本机能访问。

### 方式 C:Docker

```bash
cd homestock
docker compose up -d
```

数据挂载在 `./data`,升级重建容器不会丢数据。

---

## 四、家里人怎么访问

1. **查服务器 IP**
   - Linux/macOS:`hostname -I` 或 `ifconfig | grep inet`
   - Windows:`ipconfig`,找「IPv4 地址」,一般是 `192.168.x.x`

2. **手机连同一个 WiFi**,浏览器打开 `http://192.168.x.x:8000`

3. **建议做两件事**,否则用起来会别扭:
   - **给服务器设固定 IP**:在路由器后台把这台机器的 MAC 地址绑定一个固定 IP(俗称 DHCP 静态分配),否则重启后 IP 变了,收藏的链接就失效了。
   - **让家人存到手机桌面**:iOS Safari「分享 → 添加到主屏幕」,Android Chrome「⋮ → 添加到主屏幕」。之后点图标直接打开,跟 App 一样。

---

## 五、关于条码识别(重要,请读完)

### 为什么不做"摄像头实时扫码"

浏览器规定,只有在 **HTTPS 或 localhost** 下才允许网页调用摄像头。你通过 `http://192.168.x.x:8000` 访问时是普通 HTTP,实时扫码会被浏览器直接拒绝,而在局域网里配 HTTPS 又要自签证书、每台手机手动信任,非常折腾。

所以这里用的是**拍照识别**:点「🔍 拍条码识别」调起系统相机,拍一张条码照片,前端在本地解码。
走的是文件上传控件,不需要摄像头权限,**纯 HTTP 下完全正常工作**,零配置。体验是"拍一下"而不是"对准自动识别",家用足够。

### 启用识别库(一步)

识别功能依赖一个 380KB 的 JS 库。因为离线打包的关系,压缩包里没有附带,**请下载后放进 `static/vendor/`**:

```bash
cd homestock/static/vendor
curl -L -O https://cdn.jsdelivr.net/npm/html5-qrcode.min.js
# 或指定版本
curl -L -o html5-qrcode.min.js https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js
```

Windows 没有 curl 就直接用浏览器打开上面的网址,另存为到 `static/vendor/html5-qrcode.min.js`。

> **不放也能用**:条码框支持手动输入,其它所有功能不受任何影响。

### 拍不出来怎么办

光线充足、条码占画面一半以上、镜头拍正别歪斜。实在不行手动敲一次,系统会记住,下次同款商品扫到就自动带名字了。

---

## 六、开机自启(Linux 常驻)

```bash
sudo mkdir -p /opt/homestock
sudo cp -r app.py static requirements.txt /opt/homestock/
cd /opt/homestock
sudo python3 -m venv .venv
sudo .venv/bin/pip install -r requirements.txt

# 改一下 homestock.service 里的 User= 为你的用户名
sudo cp homestock.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now homestock
sudo systemctl status homestock          # 看是否 running
```

日志:`journalctl -u homestock -f`

---

## 七、数据与备份

- **数据库**:`data/homestock.db`(SQLite 单文件,开了 WAL 模式,多人同时录入不冲突)
- **照片**:`data/photos/`,数据库里只存文件名,不存二进制
- **备份**:把整个 `data/` 目录拷走就完事了。建议加条 crontab:

```bash
0 3 * * * tar czf ~/backup/homestock-$(date +\%F).tar.gz -C /opt/homestock data
```

- **换机器**:装好依赖,把 `data/` 拷过去,启动即可,数据原样。

---

## 八、数据表设计

三张表,够用且不臃肿:

- `members` — 家庭成员(id、姓名、标签色)
- `items` — 物品主表(名称、条码、数量、位置、归属成员、照片、备注、过期日、时间戳)
- `barcodes` — 条码字典(条码 → 商品名、扫描次数)。这张表是「扫第二次自动带名字」的来源

---

## 九、常见问题

**手机打不开页面**
① 确认手机和服务器在同一 WiFi(不是访客网络);② 确认启动时带了 `--host 0.0.0.0`;③ 关防火墙端口限制:
```bash
sudo ufw allow 8000/tcp                        # Ubuntu/Debian
sudo firewall-cmd --add-port=8000/tcp --permanent && sudo firewall-cmd --reload   # CentOS
```
Windows 首次启动时,防火墙弹窗要选「允许专用网络访问」。

**端口 8000 被占用**
换一个:`uvicorn app:app --host 0.0.0.0 --port 8080`

**照片上传失败**
单张上限 12MB。服务端会自动压到最长边 1280px 再存盘,不用担心占空间。

**想在外网访问**
别直接做端口转发暴露到公网(这套没有登录认证)。装 [Tailscale](https://tailscale.com/) 组个虚拟局域网,手机在外面也能像在家一样访问,顺带还有 HTTPS。

**需要密码保护吗**
家庭局域网内一般不需要。真要加,最简单是在 `app.py` 里挂一个 HTTP Basic Auth 依赖,或者前面套一层 Caddy/Nginx 做认证。

---

## 十、技术栈

Python 3.9+ · FastAPI · SQLite(WAL)· Pillow · 原生 JS(无构建步骤,改完刷新即生效)
