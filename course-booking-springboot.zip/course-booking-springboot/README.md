# Spring Boot 多学生选课与课次管理：最小可运行版本

## 已实现

### 完全分离的登录和页面

- 公共入口：`http://localhost:8080/`
- 学生登录：`http://localhost:8080/student/login`
- 学生中心：`/student/dashboard`，只有 `ROLE_STUDENT` 可访问
- 管理员登录：`http://localhost:8080/admin/login`
- 管理后台：`/admin/dashboard`，只有 `ROLE_ADMIN` 可访问

学生页面不会显示管理员功能，管理员页面也不会显示学生预约页面。后端仍会检查角色，不只是前端隐藏。

### 课次规则

- 学生显示剩余次数。
- 预约成功在事务中扣除1次。
- 开课至少还有2小时，学生可以自行取消，并退回1次。
- 开课前2小时内禁止自行取消。
- 后台定时任务每分钟检查未来2小时内即将开课的课程。
- 有效预约少于3人时，课程自动取消，并为所有已预约学生退回1次。
- 管理员可为学生增加次数，并写入次数流水。

## 环境

本项目使用 Spring Boot 4.1.1、Java 17、Spring Security、Thymeleaf、Spring Data JPA 和 H2 文件数据库。

先检查：

```bash
java -version
mvn -version
```

## 启动

```bash
mvn spring-boot:run
```

也可以在 IntelliJ IDEA 中运行 `CourseBookingApplication`。

首次启动会在项目根目录生成：

```text
data/course-booking.mv.db
```

不需要安装 MySQL、PostgreSQL，也不需要管理员权限。

## 演示账号

学生：

```text
zhangsan / 123456    剩余10次
lisi / 123456        剩余5次
```

管理员：

```text
admin / admin123
```

## 快速验证业务流程

1. 用 `zhangsan` 登录学生端，记录剩余10次。
2. 预约一节课，余额应变为9。
3. 如果距离开课超过2小时，取消预约，余额恢复10。
4. 用管理员账号登录管理端，为张三增加5次。
5. 重新登录学生端，余额应增加5。
6. 创建一节两小时内开课的课程，确保预约人数少于3。
7. 定时任务最多约一分钟后取消课程并退回已扣次数。

## 数据库说明

核心表：

- `APP_USERS`：登录账号与角色
- `STUDENT`：学生资料及剩余次数
- `COURSE_SESSIONS`：课程场次
- `BOOKINGS`：预约和取消状态
- `CREDIT_LOG`：次数增减流水

H2 控制台：`http://localhost:8080/h2-console`

连接参数：

```text
JDBC URL: jdbc:h2:file:./data/course-booking
User Name: sa
Password: 留空
```

## 关键代码

- 两套登录与权限：`config/SecurityConfig.java`
- 预约、扣次、取消退次：`service/BookingService.java`
- 人数不足自动取消与退款：`service/SessionCancellationJob.java`
- 管理员加次数：`service/AdminService.java`
- 学生页面：`templates/student/*`
- 管理员页面：`templates/admin/*`

## 当前最小版本的取舍

- 一个学生账号只对应一个学生档案。
- 暂不支持候补、支付、签到、短信通知、家长管理多个孩子。
- 学生取消后暂不允许重新预约同一个场次。
- 人数不足判定固定在开课前2小时窗口内。
- 管理端暂未提供手工取消课程和人工退次按钮。
- 课程页面先使用列表，不是最终七天日历。
- H2 适合本地演示和小规模试用，正式上线建议 PostgreSQL。

## 下一阶段建议

1. 加入一周七天日历和课程时长定位。
2. 将 User 与 Student 改为多对多家长关系，支持一个家长管理多个孩子。
3. 加入候补队列、签到和缺席处理。
4. 管理员手工取消课程、改期、批量退款。
5. CreditPackage、Purchase、Payment、Refund 表，保留购买和退款审计。
6. 使用数据库锁处理高并发最后名额。
7. 增加邮件或短信提醒，开课和取消时通知学生。
8. 增加审计日志、登录限流、密码重置和二次验证。
9. 增加 Testcontainers/PostgreSQL 集成测试。
10. 分离开发、测试和生产配置，并使用 Flyway 管理数据库迁移。

## 安全说明

演示账号会自动初始化，密码使用 BCrypt 保存。正式上线仍应删除固定演示账号、使用 HTTPS、秘密配置、备份、审计、限流和隐私政策。
