package com.example.coursebooking.domain;
import jakarta.persistence.*;
@Entity @Table(name="app_users")
public class AppUser {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,unique=true) private String username;
 @Column(nullable=false) private String password;
 @Column(nullable=false) private String displayName;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private Role role;
 protected AppUser(){} public AppUser(String u,String p,String d,Role r){username=u;password=p;displayName=d;role=r;}
 public Long getId(){return id;} public String getUsername(){return username;} public String getPassword(){return password;} public String getDisplayName(){return displayName;} public Role getRole(){return role;}
}
