package com.example.coursebooking.domain;
import jakarta.persistence.*;
@Entity
public class Student {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @OneToOne(optional=false) @JoinColumn(name="user_id",unique=true) private AppUser user;
 @Column(nullable=false) private String studentName;
 private String grade;
 @Column(nullable=false) private int remainingCredits;
 @Version private long version;
 protected Student(){} public Student(AppUser u,String n,String g,int c){user=u;studentName=n;grade=g;remainingCredits=c;}
 public Long getId(){return id;} public AppUser getUser(){return user;} public String getStudentName(){return studentName;} public String getGrade(){return grade;} public int getRemainingCredits(){return remainingCredits;}
 public void addCredits(int amount){if(amount<=0)throw new IllegalArgumentException("增加次数必须大于0");remainingCredits+=amount;}
 public void consumeCredit(){if(remainingCredits<=0)throw new IllegalStateException("剩余次数不足");remainingCredits--;}
 public void refundCredit(){remainingCredits++;}
}
