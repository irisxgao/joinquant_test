package com.example.coursebooking;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
@SpringBootApplication @EnableScheduling
public class CourseBookingApplication { public static void main(String[] args){ SpringApplication.run(CourseBookingApplication.class,args); } }
