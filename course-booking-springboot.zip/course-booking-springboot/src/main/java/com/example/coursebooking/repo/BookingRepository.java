package com.example.coursebooking.repo;
import com.example.coursebooking.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import java.util.*;
public interface BookingRepository extends JpaRepository<Booking,Long>{
 Optional<Booking> findByStudentIdAndSessionId(Long studentId,Long sessionId);
 long countBySessionIdAndStatus(Long sessionId,BookingStatus status);
 @EntityGraph(attributePaths={"session","student"}) List<Booking> findByStudentIdOrderByCreatedAtDesc(Long studentId);
 @EntityGraph(attributePaths={"session","student"}) List<Booking> findBySessionIdAndStatus(Long sessionId,BookingStatus status);
 @Override @EntityGraph(attributePaths={"session","student"}) List<Booking> findAll();
}
