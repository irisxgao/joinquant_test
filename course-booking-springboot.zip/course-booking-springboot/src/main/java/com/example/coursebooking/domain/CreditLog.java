package com.example.coursebooking.domain;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity
public class CreditLog {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private Student student; @Column(nullable=false) private int delta; @Column(nullable=false) private String reason; @Column(nullable=false) private LocalDateTime createdAt;
 protected CreditLog(){} public CreditLog(Student s,int d,String r){student=s;delta=d;reason=r;createdAt=LocalDateTime.now();}
 public Long getId(){return id;} public Student getStudent(){return student;} public int getDelta(){return delta;} public String getReason(){return reason;} public LocalDateTime getCreatedAt(){return createdAt;}
}
