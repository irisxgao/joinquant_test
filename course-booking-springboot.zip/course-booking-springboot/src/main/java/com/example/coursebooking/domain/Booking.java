package com.example.coursebooking.domain;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="bookings",uniqueConstraints=@UniqueConstraint(columnNames={"student_id","session_id"}))
public class Booking {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private Student student; @ManyToOne(optional=false) private CourseSession session;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private BookingStatus status;
 @Column(nullable=false) private LocalDateTime createdAt;
 private LocalDateTime cancelledAt;
 protected Booking(){} public Booking(Student st,CourseSession se){student=st;session=se;status=BookingStatus.BOOKED;createdAt=LocalDateTime.now();}
 public Long getId(){return id;} public Student getStudent(){return student;} public CourseSession getSession(){return session;} public BookingStatus getStatus(){return status;}
 public boolean isActive(){return status==BookingStatus.BOOKED;} public void studentCancel(){status=BookingStatus.STUDENT_CANCELLED;cancelledAt=LocalDateTime.now();} public void sessionCancel(){status=BookingStatus.SESSION_CANCELLED;cancelledAt=LocalDateTime.now();}
}
