package com.example.coursebooking.domain;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="course_sessions")
public class CourseSession {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String courseName; @Column(nullable=false) private String teacher; @Column(nullable=false) private String room;
 @Column(nullable=false) private LocalDateTime startAt; @Column(nullable=false) private LocalDateTime endAt; @Column(nullable=false) private int capacity;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private SessionStatus status=SessionStatus.OPEN;
 protected CourseSession(){} public CourseSession(String n,String t,String r,LocalDateTime s,LocalDateTime e,int c){courseName=n;teacher=t;room=r;startAt=s;endAt=e;capacity=c;}
 public Long getId(){return id;} public String getCourseName(){return courseName;} public String getTeacher(){return teacher;} public String getRoom(){return room;} public LocalDateTime getStartAt(){return startAt;} public LocalDateTime getEndAt(){return endAt;} public int getCapacity(){return capacity;} public SessionStatus getStatus(){return status;} public void cancel(){status=SessionStatus.CANCELLED;}
}
