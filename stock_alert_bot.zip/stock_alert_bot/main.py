import time
import logging
from datetime import datetime
from typing import List, Dict, Any

from utils.config import load_config
from utils.logger import setup_logger
from storage.sqlite_store import SQLiteStore
from data_sources.akshare_client import AKShareClient
from filters.rules import build_concept_map, filter_stocks
from llm.analyzer import LLMAnalyzer
from notify.feishu import FeishuNotifier
from notify.dingtalk import DingTalkNotifier

logger = logging.getLogger(__name__)


def yuan_to_yi(v: float) -> str:
    try:
        return f"{v / 100000000:.2f}亿"
    except Exception:
        return "-"


def build_markdown(title: str, provider: str, model: str, results: List[Dict[str, Any]]) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        f"# {title}",
        "",
        f"**更新时间**：{now}",
        f"**模型**：{provider} / {model}",
        f"**数量**：{len(results)}",
        "",
        "> 仅为公开行情异动信息整理，不构成投资建议。",
        "",
    ]

    for idx, item in enumerate(results, start=1):
        stock = item["stock"]
        a = item["analysis"]
        risks = a.get("risks", [])
        if isinstance(risks, list):
            risks_text = "；".join(str(x) for x in risks[:3])
        else:
            risks_text = str(risks)

        lines.extend([
            f"## {idx}. {stock.get('code')} {stock.get('name')}",
            "",
            f"- **涨跌幅**：{stock.get('change_pct', 0):.2f}%",
            f"- **最新价**：{stock.get('price', 0):.2f}",
            f"- **成交额**：{yuan_to_yi(stock.get('turnover_amount', 0))}",
            f"- **换手率**：{stock.get('turnover_rate', 0):.2f}%",
            f"- **量比**：{stock.get('volume_ratio', 0):.2f}",
            f"- **10分钟涨幅变化**：{stock.get('speed_change_pct') if stock.get('speed_change_pct') is not None else '暂无历史快照'}",
            f"- **触发条件**：{', '.join(stock.get('triggers', []))}",
            f"- **异动原因**：{a.get('abnormal_reason', '')}",
            f"- **资金/量价**：{a.get('volume_price', '')}",
            f"- **相关板块**：{a.get('related_sectors', '')}",
            f"- **风险点**：{risks_text}",
            f"- **观察价值**：{a.get('watch_value', '中')}",
            "",
        ])
    return "\n".join(lines)


def send_message(cfg: dict, title: str, markdown: str):
    target = cfg.get("notify", {}).get("target", "none").lower()
    secrets = cfg.get("secrets", {})
    responses = []
    if target in ("feishu", "both"):
        notifier = FeishuNotifier(secrets.get("feishu_webhook", ""), secrets.get("feishu_secret", ""))
        responses.append(("feishu", notifier.send_markdown(title, markdown)))
    if target in ("dingtalk", "both"):
        notifier = DingTalkNotifier(secrets.get("dingtalk_webhook", ""), secrets.get("dingtalk_secret", ""))
        responses.append(("dingtalk", notifier.send_markdown(title, markdown)))
    if target == "none":
        logger.info("notify.target=none，消息不推送。\n%s", markdown)
    return responses


def run_once(cfg: dict, store: SQLiteStore, ak_client: AKShareClient):
    logger.info("开始拉取 A 股实时行情...")
    rows = ak_client.fetch_a_stock_spot()
    logger.info("拉取行情数量：%s", len(rows))

    store.save_snapshot(rows)

    concept_keywords = cfg.get("filters", {}).get("concept_keywords", [])
    concept_map = build_concept_map(ak_client, store, concept_keywords)

    candidates = filter_stocks(rows, cfg, store, concept_map)
    logger.info("命中筛选股票数量：%s", len(candidates))
    if not candidates:
        return

    analyzer = LLMAnalyzer(cfg)
    analyzed = []
    for stock in candidates:
        logger.info("调用模型分析：%s %s", stock.get("code"), stock.get("name"))
        analysis = analyzer.analyze_stock(stock)
        analyzed.append({"stock": stock, "analysis": analysis})

    provider = cfg["llm"]["provider"]
    model = cfg["llm"].get("qwen_model") if provider == "qwen" else cfg["llm"].get("deepseek_model")
    title = cfg.get("notify", {}).get("title", "A股实时异动分析")
    markdown = build_markdown(title, provider, model, analyzed)
    responses = send_message(cfg, title, markdown)
    logger.info("推送结果：%s", responses)

    for item in analyzed:
        stock = item["stock"]
        store.mark_sent(stock["code"], stock["trigger_key"])


def main():
    cfg = load_config()
    setup_logger(cfg.get("logging", {}).get("level", "INFO"))
    store = SQLiteStore()
    ak_client = AKShareClient()

    loop = bool(cfg.get("run", {}).get("loop", True))
    interval = int(cfg.get("run", {}).get("interval_seconds", 60))

    if not loop:
        run_once(cfg, store, ak_client)
        return

    logger.info("启动循环运行，每 %s 秒执行一次。按 Ctrl+C 停止。", interval)
    while True:
        start = time.time()
        try:
            run_once(cfg, store, ak_client)
        except KeyboardInterrupt:
            logger.info("收到停止信号，退出。")
            break
        except Exception as e:
            logger.exception("本轮执行失败：%s", e)
        elapsed = time.time() - start
        sleep_seconds = max(1, interval - elapsed)
        time.sleep(sleep_seconds)


if __name__ == "__main__":
    main()
