import logging
from typing import List, Dict, Any, Set
import pandas as pd
import akshare as ak

logger = logging.getLogger(__name__)


def _num(v, default=0.0):
    try:
        if pd.isna(v):
            return default
        return float(v)
    except Exception:
        return default


class AKShareClient:
    def fetch_a_stock_spot(self) -> List[Dict[str, Any]]:
        """拉取 A 股实时行情。字段来自 AKShare 的 stock_zh_a_spot_em。"""
        df = ak.stock_zh_a_spot_em()
        rows = []
        for _, row in df.iterrows():
            code = str(row.get("代码", "")).zfill(6)
            item = {
                "code": code,
                "name": str(row.get("名称", "")),
                "price": _num(row.get("最新价")),
                "change_pct": _num(row.get("涨跌幅")),
                "change_amount": _num(row.get("涨跌额")),
                "volume": _num(row.get("成交量")),
                "turnover_amount": _num(row.get("成交额")),
                "amplitude": _num(row.get("振幅")),
                "high": _num(row.get("最高")),
                "low": _num(row.get("最低")),
                "open": _num(row.get("今开")),
                "prev_close": _num(row.get("昨收")),
                "volume_ratio": _num(row.get("量比")),
                "turnover_rate": _num(row.get("换手率")),
                "pe": _num(row.get("市盈率-动态")),
                "pb": _num(row.get("市净率")),
            }
            # 过滤明显异常或无代码
            if code and item["price"] > 0:
                rows.append(item)
        return rows

    def fetch_concept_members(self, concept: str) -> Set[str]:
        """拉取某概念板块成分股代码。"""
        try:
            df = ak.stock_board_concept_cons_em(symbol=concept)
            codes = set(str(x).zfill(6) for x in df.get("代码", []).tolist())
            return codes
        except Exception as e:
            logger.warning("拉取概念板块失败 concept=%s error=%s", concept, e)
            return set()
