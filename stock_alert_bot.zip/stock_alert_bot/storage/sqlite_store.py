import sqlite3
import time
import json
from typing import Optional, Dict, Any, List


class SQLiteStore:
    def __init__(self, db_path: str = "stock_alert_bot.db"):
        self.db_path = db_path
        self._init_db()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
            CREATE TABLE IF NOT EXISTS market_snapshots (
                ts INTEGER NOT NULL,
                code TEXT NOT NULL,
                name TEXT,
                price REAL,
                change_pct REAL,
                turnover_amount REAL,
                turnover_rate REAL,
                raw_json TEXT,
                PRIMARY KEY (ts, code)
            )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_snap_code_ts ON market_snapshots(code, ts)")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS sent_records (
                code TEXT NOT NULL,
                trigger_key TEXT NOT NULL,
                sent_ts INTEGER NOT NULL,
                PRIMARY KEY (code, trigger_key)
            )
            """)
            conn.execute("""
            CREATE TABLE IF NOT EXISTS concept_cache (
                concept TEXT PRIMARY KEY,
                updated_ts INTEGER NOT NULL,
                members_json TEXT NOT NULL
            )
            """)

    def save_snapshot(self, rows: List[Dict[str, Any]]):
        ts = int(time.time())
        with self._conn() as conn:
            for r in rows:
                conn.execute(
                    """
                    INSERT OR REPLACE INTO market_snapshots
                    (ts, code, name, price, change_pct, turnover_amount, turnover_rate, raw_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ts, r.get("code"), r.get("name"), r.get("price"),
                        r.get("change_pct"), r.get("turnover_amount"),
                        r.get("turnover_rate"), json.dumps(r, ensure_ascii=False)
                    )
                )
        return ts

    def get_snapshot_before(self, code: str, before_ts: int) -> Optional[Dict[str, Any]]:
        with self._conn() as conn:
            cur = conn.execute(
                """
                SELECT raw_json FROM market_snapshots
                WHERE code=? AND ts<=?
                ORDER BY ts DESC LIMIT 1
                """,
                (code, before_ts)
            )
            row = cur.fetchone()
            if not row:
                return None
            return json.loads(row[0])

    def recently_sent(self, code: str, trigger_key: str, window_minutes: int) -> bool:
        now_ts = int(time.time())
        with self._conn() as conn:
            cur = conn.execute(
                "SELECT sent_ts FROM sent_records WHERE code=? AND trigger_key=?",
                (code, trigger_key)
            )
            row = cur.fetchone()
            return bool(row and now_ts - row[0] < window_minutes * 60)

    def mark_sent(self, code: str, trigger_key: str):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO sent_records(code, trigger_key, sent_ts) VALUES (?, ?, ?)",
                (code, trigger_key, int(time.time()))
            )

    def get_concept_cache(self, concept: str, max_age_seconds: int = 86400):
        now_ts = int(time.time())
        with self._conn() as conn:
            cur = conn.execute("SELECT updated_ts, members_json FROM concept_cache WHERE concept=?", (concept,))
            row = cur.fetchone()
            if not row:
                return None
            updated_ts, members_json = row
            if now_ts - updated_ts > max_age_seconds:
                return None
            return json.loads(members_json)

    def set_concept_cache(self, concept: str, members: list):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO concept_cache(concept, updated_ts, members_json) VALUES (?, ?, ?)",
                (concept, int(time.time()), json.dumps(members, ensure_ascii=False))
            )
