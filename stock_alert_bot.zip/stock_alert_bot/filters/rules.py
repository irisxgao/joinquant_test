import time
import logging
from typing import List, Dict, Any, Tuple, Set

logger = logging.getLogger(__name__)


def build_concept_map(ak_client, store, concept_keywords: List[str]) -> Dict[str, Set[str]]:
    concept_map = {}
    for concept in concept_keywords or []:
        cached = store.get_concept_cache(concept)
        if cached is not None:
            concept_map[concept] = set(cached)
            continue
        members = ak_client.fetch_concept_members(concept)
        concept_map[concept] = members
        store.set_concept_cache(concept, list(members))
    return concept_map


def filter_stocks(rows: List[Dict[str, Any]], cfg: dict, store, concept_map: Dict[str, Set[str]]) -> List[Dict[str, Any]]:
    filters_cfg = cfg["filters"]
    market_cfg = cfg["market"]

    min_change_pct = float(filters_cfg.get("min_change_pct", 5))
    min_turnover_amount = float(filters_cfg.get("min_turnover_amount", 500000000))
    min_turnover_rate = float(filters_cfg.get("min_turnover_rate", 8))
    min_speed_change_pct = float(filters_cfg.get("min_speed_change_pct", 2))
    speed_window_minutes = int(market_cfg.get("speed_window_minutes", 10))
    max_stocks = int(market_cfg.get("max_stocks_per_round", 5))
    dedup_minutes = int(market_cfg.get("deduplicate_minutes", 10))

    now_ts = int(time.time())
    before_ts = now_ts - speed_window_minutes * 60

    candidates = []
    for r in rows:
        triggers = []
        matched_concepts = []

        if r.get("change_pct", 0) > min_change_pct:
            triggers.append(f"涨幅>{min_change_pct:g}%")
        if r.get("turnover_amount", 0) > min_turnover_amount:
            triggers.append(f"成交额>{min_turnover_amount/100000000:g}亿")
        if r.get("turnover_rate", 0) > min_turnover_rate:
            triggers.append(f"换手率>{min_turnover_rate:g}%")

        old = store.get_snapshot_before(r["code"], before_ts)
        speed_change = None
        if old:
            speed_change = r.get("change_pct", 0) - old.get("change_pct", 0)
            if speed_change > min_speed_change_pct:
                triggers.append(f"{speed_window_minutes}分钟涨速>{min_speed_change_pct:g}pct")
        r["speed_change_pct"] = speed_change

        for concept, codes in concept_map.items():
            if r["code"] in codes:
                matched_concepts.append(concept)
        if matched_concepts:
            triggers.append("命中概念:" + ",".join(matched_concepts))

        if not triggers:
            continue

        trigger_key = "|".join(sorted(triggers))
        if store.recently_sent(r["code"], trigger_key, dedup_minutes):
            continue

        enriched = dict(r)
        enriched["triggers"] = triggers
        enriched["trigger_key"] = trigger_key
        enriched["matched_concepts"] = matched_concepts
        score = 0
        score += max(0, enriched.get("change_pct", 0)) * 2
        score += min(enriched.get("turnover_amount", 0) / 100000000, 50) * 0.5
        score += max(0, enriched.get("turnover_rate", 0))
        if speed_change:
            score += speed_change * 5
        score += len(matched_concepts) * 10
        enriched["score"] = score
        candidates.append(enriched)

    candidates.sort(key=lambda x: x.get("score", 0), reverse=True)
    return candidates[:max_stocks]
