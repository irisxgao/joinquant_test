import os
import json
import logging
from typing import Dict, Any
from openai import OpenAI
from .prompts import build_stock_prompt

logger = logging.getLogger(__name__)


class LLMAnalyzer:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        llm_cfg = cfg["llm"]
        secrets = cfg.get("secrets", {})
        self.provider = llm_cfg.get("provider", "qwen").lower()
        self.temperature = float(llm_cfg.get("temperature", 0.2))
        self.max_tokens = int(llm_cfg.get("max_tokens", 900))
        self.timeout = int(llm_cfg.get("timeout_seconds", 60))

        if self.provider == "qwen":
            api_key = secrets.get("dashscope_api_key")
            base_url = llm_cfg.get("qwen_base_url")
            self.model = llm_cfg.get("qwen_model")
        elif self.provider == "deepseek":
            api_key = secrets.get("deepseek_api_key")
            base_url = llm_cfg.get("deepseek_base_url")
            self.model = llm_cfg.get("deepseek_model")
        else:
            raise ValueError(f"不支持的 LLM provider: {self.provider}")

        if not api_key:
            raise ValueError(f"缺少 {self.provider} API Key，请检查 .env")
        self.client = OpenAI(api_key=api_key, base_url=base_url, timeout=self.timeout)

    def analyze_stock(self, stock: Dict[str, Any]) -> Dict[str, Any]:
        prompt = build_stock_prompt(stock)
        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是一个谨慎、客观、拒绝编造事实的金融资讯分析助手。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            text = resp.choices[0].message.content or ""
            return self._parse_json(text)
        except Exception as e:
            logger.exception("LLM 分析失败 code=%s error=%s", stock.get("code"), e)
            return {
                "abnormal_reason": "模型分析失败，请查看程序日志。",
                "volume_price": "暂无",
                "related_sectors": ",".join(stock.get("matched_concepts", [])) or "未命中特定概念",
                "risks": ["模型调用失败", "需人工核验行情与公告"],
                "watch_value": "低",
                "summary": "模型分析失败"
            }

    def _parse_json(self, text: str) -> Dict[str, Any]:
        clean = text.strip()
        if clean.startswith("```"):
            clean = clean.strip("`")
            if clean.lower().startswith("json"):
                clean = clean[4:].strip()
        try:
            data = json.loads(clean)
        except Exception:
            start = clean.find("{")
            end = clean.rfind("}")
            if start >= 0 and end > start:
                data = json.loads(clean[start:end+1])
            else:
                data = {"summary": clean}
        data.setdefault("abnormal_reason", data.get("summary", ""))
        data.setdefault("volume_price", "暂无")
        data.setdefault("related_sectors", "暂无")
        data.setdefault("risks", [])
        data.setdefault("watch_value", "中")
        data.setdefault("summary", data.get("abnormal_reason", ""))
        return data
