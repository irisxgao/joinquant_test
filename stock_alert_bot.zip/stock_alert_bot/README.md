# A股实时异动分析机器人

这是一个可直接运行的 Python 项目，用于：

```text
1 分钟运行一次
    ↓
拉取 A 股实时行情
    ↓
按规则筛选：涨幅、成交额、换手率、10 分钟涨速、概念板块
    ↓
最多取前 5 支
    ↓
每支股票调用一次大模型 API：Qwen 或 DeepSeek
    ↓
输出异动原因、资金/量价、相关板块、风险点、观察价值
    ↓
合并成一条 Markdown
    ↓
发送到飞书 / 钉钉群
```

> 重要提示：本项目只做公开信息整理和异动提醒，不构成任何投资建议。模型输出可能有误，请自行核验数据和公告。

---

## 1. 项目结构

```text
stock_alert_bot/
├── main.py                    # 程序入口
├── config.yaml                # 配置文件
├── requirements.txt           # Python 依赖
├── .env.example               # 环境变量示例
├── README.md                  # 使用说明
├── data_sources/
│   └── akshare_client.py      # A股行情与概念数据
├── filters/
│   └── rules.py               # 筛选规则
├── llm/
│   ├── analyzer.py            # Qwen / DeepSeek 调用
│   └── prompts.py             # Prompt 模板
├── notify/
│   ├── dingtalk.py            # 钉钉机器人
│   └── feishu.py              # 飞书机器人
├── storage/
│   └── sqlite_store.py        # 快照、去重、缓存
└── utils/
    ├── config.py              # 配置加载
    └── logger.py              # 日志
```

---

## 2. 安装环境

建议使用 Python 3.10+。

```bash
cd stock_alert_bot
python -m venv .venv
```

### macOS / Linux

```bash
source .venv/bin/activate
```

### Windows PowerShell

```powershell
.venv\Scripts\Activate.ps1
```

安装依赖：

```bash
pip install -r requirements.txt
```

如果在国内网络环境安装较慢，可以使用镜像：

```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

---

## 3. 配置 API Key

复制环境变量文件：

```bash
cp .env.example .env
```

Windows PowerShell：

```powershell
Copy-Item .env.example .env
```

然后编辑 `.env`。

### 使用 Qwen / 阿里云百炼

```bash
LLM_PROVIDER=qwen
DASHSCOPE_API_KEY=你的阿里云百炼APIKey
```

默认国内百炼 OpenAI-compatible 地址：

```text
https://dashscope.aliyuncs.com/compatible-mode/v1
```

你可以在 `config.yaml` 里修改：

```yaml
llm:
  provider: qwen
  qwen_model: qwen-plus
```

常用模型：

```text
qwen-plus
qwen-max
qwen3-max
qwen3.5-plus
qwen3.5-flash
```

### 使用 DeepSeek

```bash
LLM_PROVIDER=deepseek
DEEPSEEK_API_KEY=你的DeepSeekAPIKey
```

`config.yaml` 中：

```yaml
llm:
  provider: deepseek
  deepseek_model: deepseek-v4-flash
```

常用模型：

```text
deepseek-v4-flash
deepseek-v4-pro
```

---

## 4. 配置飞书群机器人

1. 在飞书群里添加「自定义机器人」。
2. 复制 Webhook 地址。
3. 如果开启了签名校验，复制签名密钥。
4. 写入 `.env`：

```bash
FEISHU_WEBHOOK=https://open.feishu.cn/open-apis/bot/v2/hook/xxxx
FEISHU_SECRET=可选，如果开启签名则填写
```

`config.yaml`：

```yaml
notify:
  target: feishu
```

---

## 5. 配置钉钉群机器人

1. 在钉钉群里添加「自定义机器人」。
2. 安全设置建议选择「加签」。
3. 复制 Webhook 和 Secret。
4. 写入 `.env`：

```bash
DINGTALK_WEBHOOK=https://oapi.dingtalk.com/robot/send?access_token=xxxx
DINGTALK_SECRET=SECxxxxxxxxxxxxxxxx
```

`config.yaml`：

```yaml
notify:
  target: dingtalk
```

如果两个群都想发：

```yaml
notify:
  target: both
```

---

## 6. 修改筛选规则

在 `config.yaml` 中修改：

```yaml
filters:
  min_change_pct: 5
  min_turnover_amount: 500000000
  min_turnover_rate: 8
  min_speed_change_pct: 2
  concept_keywords:
    - 人工智能
    - 算力
    - 机器人
    - 半导体
    - 低空经济
```

含义：

- `min_change_pct: 5`：涨幅大于 5%。
- `min_turnover_amount: 500000000`：成交额大于 5 亿。
- `min_turnover_rate: 8`：换手率大于 8%。
- `min_speed_change_pct: 2`：最近 10 分钟涨幅扩大超过 2 个百分点。
- `concept_keywords`：命中特定概念板块。

注意：

- 概念板块数据需要额外拉取，第一次运行会慢一些。
- 如果你不想启用概念筛选，把 `concept_keywords` 改成空列表：

```yaml
concept_keywords: []
```

---

## 7. 运行

### 只运行一次

修改 `config.yaml`：

```yaml
run:
  loop: false
```

然后：

```bash
python main.py
```

### 每 1 分钟循环运行

修改：

```yaml
run:
  loop: true
  interval_seconds: 60
```

运行：

```bash
python main.py
```

停止：按 `Ctrl + C`。

---

## 8. 输出示例

程序会把多支股票合并成一条消息，类似：

```markdown
# A股实时异动分析

更新时间：2026-06-25 10:30:00
模型：qwen / qwen-plus

## 1. 000001 平安银行

- 涨跌幅：5.82%
- 成交额：12.3 亿
- 换手率：8.5%
- 触发条件：涨幅>5%、成交额>5亿、换手率>8%
- 异动原因：……
- 资金/量价：……
- 相关板块：……
- 风险点：……
- 观察价值：中
```

---

## 9. 数据与去重逻辑

程序使用 SQLite 文件 `stock_alert_bot.db` 保存：

- 每轮行情快照；
- 10 分钟前涨幅，用于计算涨速异常；
- 已推送记录，用于去重；
- 概念板块缓存。

默认同一股票同一触发类型 10 分钟内不重复推送。

---

## 10. 常见问题

### Q1：为什么第一次运行没有“最近 10 分钟涨速异常”？

因为程序需要先保存行情快照。运行超过 10 分钟后，才有历史快照可以比较。

### Q2：为什么概念板块很慢？

概念板块需要遍历配置中的概念关键词，并拉取成分股。建议关键词不要太多。

### Q3：为什么没有消息推送？

请检查：

1. `.env` 有没有配置 Webhook；
2. `config.yaml` 的 `notify.target` 是否是 `feishu` / `dingtalk` / `both`；
3. 群机器人是否开启了签名校验但没有填写 Secret；
4. 当前行情是否有股票命中规则；
5. 是否被 SQLite 去重过滤。

### Q4：如何节省模型费用？

建议：

1. `max_stocks_per_round` 设置为 3～5；
2. 普通异动用 `qwen-plus` 或 `deepseek-v4-flash`；
3. 重大公告再切换强模型；
4. 缩短新闻和上下文长度；
5. 控制 `max_tokens`。

---

## 11. 免责声明

本项目仅用于技术研究和信息提醒，不提供任何买入、卖出、持有、目标价等投资建议。股票市场有风险，模型分析可能存在错误、遗漏和延迟，请务必结合官方公告、交易所披露、券商行情和个人风险承受能力独立判断。
