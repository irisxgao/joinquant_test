import os
from pathlib import Path
from dotenv import load_dotenv
import yaml


def load_config(path: str = "config.yaml") -> dict:
    load_dotenv()
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    provider = os.getenv("LLM_PROVIDER") or cfg.get("llm", {}).get("provider", "qwen")
    cfg["llm"]["provider"] = provider

    cfg.setdefault("secrets", {})
    cfg["secrets"]["dashscope_api_key"] = os.getenv("DASHSCOPE_API_KEY", "")
    cfg["secrets"]["deepseek_api_key"] = os.getenv("DEEPSEEK_API_KEY", "")
    cfg["secrets"]["feishu_webhook"] = os.getenv("FEISHU_WEBHOOK", "")
    cfg["secrets"]["feishu_secret"] = os.getenv("FEISHU_SECRET", "")
    cfg["secrets"]["dingtalk_webhook"] = os.getenv("DINGTALK_WEBHOOK", "")
    cfg["secrets"]["dingtalk_secret"] = os.getenv("DINGTALK_SECRET", "")
    return cfg
