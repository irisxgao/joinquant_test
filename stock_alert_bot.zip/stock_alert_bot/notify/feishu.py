import time
import hmac
import hashlib
import base64
import requests


class FeishuNotifier:
    def __init__(self, webhook: str, secret: str = ""):
        self.webhook = webhook
        self.secret = secret

    def _sign(self, timestamp: int) -> str:
        string_to_sign = f"{timestamp}\n{self.secret}"
        hmac_code = hmac.new(
            string_to_sign.encode("utf-8"),
            b"",
            digestmod=hashlib.sha256,
        ).digest()
        return base64.b64encode(hmac_code).decode("utf-8")

    def send_markdown(self, title: str, markdown: str):
        if not self.webhook:
            return {"skipped": True, "reason": "empty feishu webhook"}

        payload = {
            "msg_type": "interactive",
            "card": {
                "config": {"wide_screen_mode": True},
                "header": {
                    "title": {"tag": "plain_text", "content": title},
                    "template": "blue"
                },
                "elements": [
                    {"tag": "markdown", "content": markdown}
                ]
            }
        }
        if self.secret:
            ts = int(time.time())
            payload["timestamp"] = str(ts)
            payload["sign"] = self._sign(ts)

        resp = requests.post(self.webhook, json=payload, timeout=15)
        resp.raise_for_status()
        return resp.json()
