// Service Worker：让页面断网也能打开
// 改了 index.html 之后，把版本号 v1 改成 v2，手机上才会更新缓存
const C = 'shop-v1';
const FILES = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];

// 安装：把文件存进缓存
self.addEventListener('install', e => {
  e.waitUntil(caches.open(C).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

// 激活：删掉旧版本的缓存
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== C).map(k => caches.delete(k)))));
});

// 请求：网络优先，成功就顺便更新缓存；断网时用缓存
self.addEventListener('fetch', e => {
  e.respondWith(
    fetch(e.request)
      .then(r => { const copy = r.clone(); caches.open(C).then(c => c.put(e.request, copy)); return r; })
      .catch(() => caches.match(e.request))
  );
});
